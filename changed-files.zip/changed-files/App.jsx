import { useState, useEffect, useCallback } from "react";

// ─── SUPABASE CONFIG ──────────────────────────────────────────────────────────
const SUPABASE_URL = "https://mjmwxxvqcsptrocwucis.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1qbXd4eHZxY3NwdHJvY3d1Y2lzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg4Njk2MjAsImV4cCI6MjA5NDQ0NTYyMH0.YLwGKFvrAn3F8viFgP0oZ6hzqSSq7w8FrNT1y3sy_Sc";

async function sb(path, opts = {}) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    headers: {
      "apikey": SUPABASE_ANON_KEY,
      "Authorization": `Bearer ${SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
      "Prefer": opts.prefer || "return=representation",
      ...opts.headers,
    },
    ...opts,
  });
  if (!res.ok) { const err = await res.text(); throw new Error(err); }
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

// Supabase/PostgREST caps a single request at 1000 rows regardless of any
// `limit` in the query string — tables that grow past that (like `jobs`)
// silently lose their oldest rows unless paginated explicitly.
async function sbAll(path, pageSize = 1000) {
  let all = [];
  let offset = 0;
  while (true) {
    const sep = path.includes("?") ? "&" : "?";
    const page = await sb(`${path}${sep}limit=${pageSize}&offset=${offset}`);
    if (!page || page.length === 0) break;
    all = all.concat(page);
    if (page.length < pageSize) break;
    offset += pageSize;
  }
  return all;
}

// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
const C = {
  blue:    "#2b9cf0",
  blueDk:  "#0077cc",
  blueLt:  "#e8f4ff",
  blueXlt: "#f0f8ff",
  black:   "#0d2240",
  dark:    "#f5f9ff",
  card:    "#ffffff",
  cardLt:  "#f0f7ff",
  border:  "#c5dff8",
  white:   "#ffffff",
  offWhite:"#0d2240",
  muted:   "#6b93bb",
  green:   "#00c853",
  gold:    "#f59e0b",
  orange:  "#ff6b35",
  purple:  "#7c3aed",
  red:     "#ef4444",
};

const ADMIN_PIN = "0000";
const PP_ANCHOR_END = "2026-06-13"; // known period end: pay date Jun 19, submit Jun 17
const UPSELL_PTS_PER_DOLLAR = 0.5; // $2 = 1 pt
const REVIEW_PTS = 5;
const REVIEW_BONUS_PTS = 20; // bonus at 10+ reviews in a month
const CALLBACK_PTS = -300; // deducted per callback — nearly a full week of work

// ─── QUOTA CONFIG (set by whoever holds Head of Operations) ────────────────────
const DEFAULT_QUOTA = {
  upsells: 175,      // $ per month — mid between $150 floor and $200 avg
  reviews: 6,        // count per month — mid between 5 floor and 7 avg
  switchovers: 2,    // count per month — floor for now, team is still developing
};
// Operations bonus: triggered when X% of active techs hit all 3 quotas in the month
const OPS_BONUS_THRESHOLD = 0.75; // 75% of active techs must hit quota
const OPS_BONUS_PCT = 0.05;       // 5% of total team upsell revenue that month

const LOGO_SRC = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 160 45'%3E%3Ctext x='80' y='34' font-family='Arial Black,sans-serif' font-size='30' font-weight='900' font-style='italic' fill='%232b9cf0' text-anchor='middle'%3ESkylo%3C/text%3E%3C/svg%3E";

// ─── BADGE DEFS ───────────────────────────────────────────────────────────────
// Rotating trophies: passed to current leader each month, no points
const ROTATING_TROPHIES = [
  { id:"audit_legend",    name:"Audit Legend",     icon:"📋", desc:"100% on audits for the month — passed to the current holder" },
  { id:"upsell_king",     name:"Upsell King",      icon:"👑", desc:"Highest upsells for the month — passed to the current holder" },
  { id:"review_champ",   name:"Review Champion",  icon:"⭐", desc:"Most reviews in the month — passed to the current holder" },
];

// Permanent point badges
// Scale reference: ~800 pts = solid month of work (upsells + reviews + switchovers)
const BADGE_DEFS = [
  // Tenure (show up, stay loyal — meaningful but modest)
  { id:"three_month",    cat:"Tenure",      name:"3-Month Mark",       icon:"📅", pts:40,   desc:"3 months on the team" },
  { id:"six_month",      cat:"Tenure",      name:"Half Year Hustle",   icon:"📆", pts:80,   desc:"6 months of consistency" },
  { id:"one_year",       cat:"Tenure",      name:"One Year Strong",    icon:"🏅", pts:150,  desc:"First full year with Skylo" },
  { id:"two_year",       cat:"Tenure",      name:"Two Year Vet",       icon:"🎖️", pts:225,  desc:"Two years of excellence" },
  { id:"three_year",     cat:"Tenure",      name:"Three Year Elite",   icon:"💎", pts:325,  desc:"Three years — rare commitment" },
  { id:"five_year",      cat:"Tenure",      name:"Five Year Legend",   icon:"👑", pts:500,  desc:"Five years — one of the best" },

  // Revenue (directly tied to company revenue — high value)
  { id:"rev_10k",        cat:"Revenue",     name:"$10K Serviced",      icon:"💵", pts:200,  desc:"First $10,000 in serviced revenue" },
  { id:"rev_25k",        cat:"Revenue",     name:"$25K Serviced",      icon:"💰", pts:400,  desc:"$25,000 in lifetime serviced revenue" },
  { id:"rev_50k",        cat:"Revenue",     name:"$50K Milestone",     icon:"🤑", pts:700,  desc:"$50,000 serviced — elite territory" },
  { id:"rev_100k",       cat:"Revenue",     name:"$100K Club",         icon:"🏦", pts:1200, desc:"$100,000 serviced — hall of fame" },

  // Clean Streaks (quality = retention = revenue)
  { id:"streak_1mo",     cat:"Clean Streak","name":"1-Month Clean",    icon:"✅", pts:150,  desc:"One full month with zero callbacks" },
  { id:"streak_2mo",     cat:"Clean Streak","name":"2-Month Clean",    icon:"🔵", pts:250,  desc:"Two months straight, no callbacks" },
  { id:"streak_3mo",     cat:"Clean Streak","name":"3-Month Clean",    icon:"🔥", pts:375,  desc:"Three months with zero callbacks" },
  { id:"streak_6mo",     cat:"Clean Streak","name":"6-Month Streak",   icon:"⚡", pts:600,  desc:"Six months clean — top tier quality" },
  { id:"streak_1yr",     cat:"Clean Streak","name":"Year of Zero",     icon:"🌟", pts:900,  desc:"A full year with zero callbacks" },

  // Shift Coverage (team first mentality)
  { id:"shift_cover",    cat:"Character",   name:"Shift Hero",         icon:"🫂", pts:175,  desc:"Covered 4+ extra shifts in a month outside normal schedule" },

  // The Prestige Badge
  { id:"perfect_detail", cat:"Prestige",    name:"The Perfect Detail", icon:"💎", pts:1000, desc:"On time every appt, 100% audit, zero callbacks, 1 review/day for a full week, all HCP pics + flyers + satisfaction cards attached" },

  // Performance
  { id:"switchover_5",   cat:"Performance", name:"Converter",          icon:"🔄", pts:150,  desc:"Converted 5 customers to service plans" },
  { id:"switchover_20",  cat:"Performance", name:"Subscription King",  icon:"📈", pts:400,  desc:"Converted 20 customers to service plans" },
  { id:"early_bird",     cat:"Character",   name:"Early Bird",         icon:"⏰", pts:100,  desc:"On time or early to every job for a full month" },
  { id:"customer_whisperer", cat:"Performance", name:"Customer Whisperer", icon:"🤝", pts:250, desc:"3 months straight of 5-star reviews with no gaps" },
];
const ALL_BADGE_DEFS = [...BADGE_DEFS, ...ROTATING_TROPHIES.map(t=>({...t,cat:"Trophy",pts:0}))];
const BADGE_MAP = Object.fromEntries(ALL_BADGE_DEFS.map(b => [b.id, b]));


const SERVICE_PLANS = [
  { id:"biannual",  label:"Bi-Annual",  freq:"2x/yr",   pts:15,  ltv:635  },
  { id:"quarterly", label:"Quarterly",  freq:"4x/yr",   pts:30,  ltv:1030 },
  { id:"bimonthly", label:"Bi-Monthly", freq:"6x/yr",   pts:50,  ltv:1425 },
  { id:"monthly",   label:"Monthly",    freq:"12x/yr",  pts:65,  ltv:2610 },
  { id:"biweekly",  label:"Bi-Weekly",  freq:"26x/yr",  pts:90,  ltv:3900 },
  { id:"weekly",    label:"Weekly",     freq:"52x/yr",  pts:120, ltv:5850 },
];
const PLAN_MAP = Object.fromEntries(SERVICE_PLANS.map(p => [p.id, p]));
const PLAN_COLORS = { biannual:C.green, quarterly:C.blue, bimonthly:C.purple, monthly:C.blue, biweekly:C.gold, weekly:C.orange };

const JOURNEY_TIERS = [
  { id:"bronze",   name:"BRONZE",   icon:"🥉", minPts:0,    maxPts:2499,   color:"#cd7f32", bg:"#1a1000", reward:"Tier 1 — $150",   perks:["$150 Skylo Cash","Badge tracking","Weekly upsells"] },
  { id:"silver",   name:"SILVER",   icon:"🥈", minPts:2500, maxPts:4499,   color:"#a8c0d6", bg:"#0e1520", reward:"Tier 2 — $300",   perks:["$300 Skylo Cash","Switchover bonuses","Monthly spotlight"] },
  { id:"gold",     name:"GOLD",     icon:"🥇", minPts:4500, maxPts:5999,   color:"#ffd600", bg:"#1a1400", reward:"Tier 3 — $600",   perks:["$600 Skylo Cash","Featured on board","Priority scheduling"] },
  { id:"platinum", name:"PLATINUM", icon:"💎", minPts:6000, maxPts:Infinity,color:"#c4b5fd", bg:"#0d0520", reward:"Tier 4 — $1,200", perks:["$1,200 Skylo Cash","Legend nomination","Annual award"] },
];
function getTier(pts) { return [...JOURNEY_TIERS].reverse().find(t => pts >= t.minPts) || JOURNEY_TIERS[0]; }

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const calcBadgePts = (badges) => (badges||[]).reduce((s,id) => s+(BADGE_MAP[id]?.pts||0), 0);
const medal = (i) => i===0?"🥇":i===1?"🥈":i===2?"🥉":`#${i+1}`;

function getWeekKey() {
  // Week runs Mon–Sun, resets at Monday 12:00am MT (UTC-6 MDT)
  const mtOffset = 6 * 60 * 60 * 1000;
  const mt = new Date(Date.now() - mtOffset);
  const day = mt.getDay(); // 0=Sun,1=Mon,2=Tue...6=Sat
  // Days since last Monday (Sunday counts as 6 days after Monday)
  const daysBack = day === 0 ? 6 : day - 1;
  const monday = new Date(mt);
  monday.setDate(mt.getDate() - daysBack);
  const y = monday.getFullYear();
  const m = String(monday.getMonth()+1).padStart(2,"0");
  const d = String(monday.getDate()).padStart(2,"0");
  return `${y}-${m}-${d}`;
}
// Snaps an arbitrary YYYY-MM-DD date to that week's Monday (same Mon-Sun
// convention as getWeekKey, just for a picked date instead of "now").
function dateToWeekKey(dateStr) {
  const d = new Date(dateStr + "T12:00:00Z");
  const day = d.getUTCDay();
  const back = day === 0 ? 6 : day - 1;
  d.setUTCDate(d.getUTCDate() - back);
  return d.toISOString().split("T")[0];
}
function getMonthKey() {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;
}
// Real upsell $ for a tech (or team-wide if techId is falsy) over a job_date
// range -- the same day-exact method ReportsTab uses (jobs.upsell_amount by
// job_date), so quota/gamification views agree with Reports/personal logins
// instead of the separate upsells table, whose week_key (a week's Monday)
// month-prefix bucketing misattributes any week spanning a month boundary.
function upsellAmountInRange(jobs, techId, start, end) {
  return (jobs||[]).filter(j => (!techId || j.tech_id===techId) && j.job_date && j.job_date>=start && j.job_date<=end).reduce((s,j)=>s+(j.upsell_amount||0),0);
}
function monthBounds(year, month) {
  const y = Number(year), m = Number(month);
  const start = `${y}-${String(m).padStart(2,"0")}-01`;
  const lastDay = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const end = `${y}-${String(m).padStart(2,"0")}-${String(lastDay).padStart(2,"0")}`;
  return { start, end };
}
function weekEndDate(wk) {
  const d = new Date(wk+"T12:00:00Z"); d.setUTCDate(d.getUTCDate()+6);
  return d.toISOString().split("T")[0];
}
function formatWeekLabel(key) {
  const d = new Date(key+"T00:00:00"), end = new Date(d);
  end.setDate(d.getDate()+6);
  const fmt = dt => dt.toLocaleDateString("en-US",{month:"short",day:"numeric"});
  return `${fmt(d)} – ${fmt(end)}`;
}
function formatMonthLabel(key) {
  const [y,m] = key.split("-");
  return new Date(y,m-1).toLocaleDateString("en-US",{month:"long",year:"numeric"});
}
function fmtShortDate(str) {
  return new Date(str+"T12:00:00").toLocaleDateString("en-US",{month:"short",day:"numeric"});
}
function formatLastEntered(isoTimestamp) {
  if (!isoTimestamp) return null;
  return new Date(isoTimestamp).toLocaleString("en-US", { month:"short", day:"numeric", year:"numeric", hour:"numeric", minute:"2-digit" });
}
function mostRecentTimestamp(rows) {
  if (!rows || rows.length === 0) return null;
  return rows.reduce((latest, r) => (!latest || (r.created_at||"") > latest) ? (r.created_at||latest) : latest, null);
}
function getPayPeriods() {
  const anchor = new Date(PP_ANCHOR_END+"T12:00:00");
  const todayMs = Date.now()-6*60*60*1000;
  // Forward bound is relative to today (not a fixed offset from the anchor) so
  // periods keep generating indefinitely instead of silently stopping once
  // real time passes anchor + a hardcoded number of periods.
  const periodsAheadOfToday = Math.ceil((todayMs-anchor.getTime())/(14*24*60*60*1000)) + 4;
  const periods = [];
  for (let i=-52; i<=periodsAheadOfToday; i++) {
    const end = new Date(anchor); end.setDate(anchor.getDate()+i*14);
    const start = new Date(end);  start.setDate(end.getDate()-13);
    const submit= new Date(end);  submit.setDate(end.getDate()+4);
    const payout= new Date(end);  payout.setDate(end.getDate()+6);
    const fmt = d=>d.toISOString().split("T")[0];
    periods.push({ key:fmt(end), start:fmt(start), end:fmt(end), submit:fmt(submit), payout:fmt(payout) });
  }
  return periods.sort((a,b)=>b.key.localeCompare(a.key));
}
function currentPPKey() {
  const today = new Date(Date.now()-6*60*60*1000).toISOString().split("T")[0];
  const p = getPayPeriods().find(p=>today>=p.start&&today<=p.end);
  return p?.key || PP_ANCHOR_END;
}
function formatTenure(startDate) {
  if (!startDate) return null;
  const days = Math.floor((new Date()-new Date(startDate))/(1000*60*60*24));
  if (days < 30) return `${days}d`;
  if (days < 365) return `${Math.floor(days/30)}mo`;
  const yrs = Math.floor(days/365), mos = Math.floor((days%365)/30);
  return mos > 0 ? `${yrs}yr ${mos}mo` : `${yrs}yr`;
}

// ─── TIME TRACKING HELPERS ────────────────────────────────────────────────────
// Fixed -6h convention, matching every other UTC->MT conversion in this app
// (toMTDateStr in the sync/repair functions) -- not DST-aware, intentionally
// consistent with the rest of the codebase rather than more "correct."
function mtDateStr(ms) {
  return new Date(ms - 6*60*60*1000).toISOString().split("T")[0];
}
// End-of-day boundary (next MT midnight) for a given MT calendar date, as a
// UTC ISO timestamp -- MT midnight = UTC 06:00 under the fixed -6h offset.
function mtDayEndUTC(workDate) {
  const d = new Date(workDate + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + 1);
  d.setUTCHours(6, 0, 0, 0);
  return d.toISOString();
}
// Hours for one session. An open session (no clock_out) on a past work_date
// is capped at that day's midnight instead of growing unbounded; an open
// session on today is "elapsed so far" -- which IS the live running total,
// no separate code path needed. nowMs defaults to Date.now() but call sites
// that tick a live display pass a fresh value each render.
function sessionHours(entry, nowMs = Date.now()) {
  const inMs = new Date(entry.clock_in).getTime();
  let outMs;
  if (entry.clock_out) {
    outMs = new Date(entry.clock_out).getTime();
  } else if (entry.work_date < mtDateStr(nowMs)) {
    outMs = new Date(mtDayEndUTC(entry.work_date)).getTime();
  } else {
    outMs = nowMs;
  }
  return Math.max(0, (outMs - inMs) / 3600000);
}
function dayHoursTotal(entries, techId, workDate, nowMs = Date.now()) {
  return entries.filter(e => e.tech_id === techId && e.work_date === workDate).reduce((s,e) => s + sessionHours(e, nowMs), 0);
}
function rangeHoursTotal(entries, techId, start, end, nowMs = Date.now()) {
  return entries.filter(e => e.tech_id === techId && e.work_date >= start && e.work_date <= end).reduce((s,e) => s + sessionHours(e, nowMs), 0);
}
// tip_entries totals -- manual entry only, day-exact (unlike the old
// jobs.tips column this replaces, which was week_key/job_date-derived).
function tipsRangeTotal(tipEntries, techId, start, end) {
  return tipEntries.filter(t => t.tech_id === techId && t.work_date >= start && t.work_date <= end).reduce((s,t) => s+(t.amount||0), 0);
}
function tipsDayTotal(tipEntries, techId, workDate) {
  return tipEntries.filter(t => t.tech_id === techId && t.work_date === workDate).reduce((s,t) => s+(t.amount||0), 0);
}
function formatMTTime(iso) {
  const d = new Date(new Date(iso).getTime() - 6*60*60*1000);
  let h = d.getUTCHours(); const m = String(d.getUTCMinutes()).padStart(2,"0");
  const ampm = h>=12 ? "PM" : "AM"; h = h%12; if (h===0) h=12;
  return `${h}:${m} ${ampm}`;
}
// HH:MM (24h, MT) -> UTC ISO timestamp on the given MT calendar date.
function mtTimeToIso(dateStr, hhmm) {
  const [h,m] = hhmm.split(":").map(Number);
  const d = new Date(dateStr + "T00:00:00Z");
  d.setUTCHours(h + 6, m, 0, 0);
  return d.toISOString();
}
// UTC ISO timestamp -> "HH:MM" (24h, MT) for pre-filling a <input type="time">.
function isoToMtTimeInput(iso) {
  const d = new Date(new Date(iso).getTime() - 6*60*60*1000);
  return `${String(d.getUTCHours()).padStart(2,"0")}:${String(d.getUTCMinutes()).padStart(2,"0")}`;
}

// ─── DATE RANGE HELPER ────────────────────────────────────────────────────────
function getDateRangeBounds(preset, customStart="", customEnd="") {
  const now = new Date();
  const pad = n => String(n).padStart(2,"0");
  const fmt = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  const today = fmt(now);
  if (preset==="today")     return { start:today, end:today };
  if (preset==="yesterday") { const y = new Date(now); y.setDate(now.getDate()-1); const ys = fmt(y); return { start:ys, end:ys }; }
  if (preset==="custom") return { start:customStart||today, end:customEnd||today };
  if (preset==="wtd")    return { start:getWeekKey(), end:today };
  if (preset==="last_week") {
    const wkDate = new Date(getWeekKey()+"T00:00:00");
    const s = new Date(wkDate); s.setDate(wkDate.getDate()-7);
    const e = new Date(s); e.setDate(s.getDate()+6);
    return { start:fmt(s), end:fmt(e) };
  }
  if (preset==="mtd") {
    const [y,m] = getMonthKey().split("-");
    return { start:`${y}-${m}-01`, end:today };
  }
  if (preset==="last_month") {
    const s = new Date(now.getFullYear(), now.getMonth()-1, 1);
    const e = new Date(now.getFullYear(), now.getMonth(), 0);
    return { start:fmt(s), end:fmt(e) };
  }
  if (preset==="ytd") return { start:`${now.getFullYear()}-01-01`, end:today };
  return { start:today, end:today };
}

// ─── SHARED DATE RANGE PICKER ─────────────────────────────────────────────────
// Single implementation for every tab that offers a date-range filter (Reports,
// Upsells, Switchovers, Reviews — admin and tech-facing). Previously each tab
// had its own copy-pasted preset row with small styling drift between them;
// this is the one place to change if a preset is ever added/renamed.
const DATE_RANGE_PRESETS = [["today","Today"],["yesterday","Yesterday"],["wtd","WTD"],["last_week","Last Week"],["mtd","MTD"],["last_month","Last Month"],["ytd","YTD"],["custom","Custom"]];
function DateRangePicker({ label="📊 Time Period", color=C.blue, preset, setPreset, customStart, setCustomStart, customEnd, setCustomEnd, children }) {
  return (
    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${color}`, borderRadius:"12px", padding:"16px 18px" }}>
      <Label color={color}>{label}</Label>
      <div style={{ display:"flex", gap:"6px", flexWrap:"wrap" }}>
        {DATE_RANGE_PRESETS.map(([id,lbl])=>(
          <button key={id} onClick={()=>setPreset(id)} style={{ background:preset===id?color:C.cardLt, border:`1px solid ${preset===id?color:C.border}`, color:preset===id?C.white:C.muted, padding:"6px 14px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px", letterSpacing:"1px" }}>{lbl}</button>
        ))}
      </div>
      {preset==="custom"&&(
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"8px", marginTop:"12px" }}>
          {[["From",customStart,setCustomStart],["To",customEnd,setCustomEnd]].map(([lbl,val,set])=>(
            <div key={lbl}>
              <div style={{ fontSize:"10px", color:C.muted, marginBottom:"4px" }}>{lbl}</div>
              <input type="date" value={val} onChange={e=>set(e.target.value)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"8px", borderRadius:"8px", fontSize:"13px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box" }}/>
            </div>
          ))}
        </div>
      )}
      {children}
    </div>
  );
}
const TEAM_LEAD_OVERRIDE_PCT_PARTIAL = 0.05; // 5% if lead + 2/3 of team hits quota
const TEAM_LEAD_OVERRIDE_PCT_FULL    = 0.10; // 10% if lead + ALL of team hits quota

function calcTeamOverride(tech, allTechs, upsells, switchovers, reviews, callbacks, quota, jobs) {
  const teamMembers = allTechs.filter(t=>t.team_lead_id===tech.id);
  if (teamMembers.length===0) return { overridePts:0, overridePct:0, teamMembers:[], allTeamHit:false, partialHit:false, leadHitsQuota:false, teamMemberStats:[], hittingCount:0 };
  const q = quota || DEFAULT_QUOTA;
  const now = new Date(); const y=now.getFullYear(); const mo=String(now.getMonth()+1).padStart(2,"0");
  const mk = getMonthKey();
  const { start: mStart, end: mEnd } = monthBounds(y, mo);

  const teamMemberStats = teamMembers.map(m=>{
    const monthUpsellAmt   = upsellAmountInRange(jobs, m.id, mStart, mEnd);
    const monthReviewCount = reviews.filter(r=>r.tech_id===m.id&&r.month_key===mk).reduce((s,r)=>s+r.count,0);
    const monthSwitchCount = switchovers.filter(s=>s.tech_id===m.id&&s.week_key?.startsWith(`${y}-${mo}`)).length;
    const upHit=monthUpsellAmt>=q.upsells, revHit=monthReviewCount>=q.reviews, swHit=monthSwitchCount>=q.switchovers;
    const tt = calcTotals(m,upsells,switchovers,reviews,callbacks,jobs);
    return { ...m, monthUpsellAmt, monthReviewCount, monthSwitchCount, upHit, revHit, swHit, allHit:upHit&&revHit&&swHit, total:tt.total };
  });

  // Lead's own quota
  const leadMonthUpsells  = upsellAmountInRange(jobs, tech.id, mStart, mEnd);
  const leadMonthReviews  = reviews.filter(r=>r.tech_id===tech.id&&r.month_key===mk).reduce((s,r)=>s+r.count,0);
  const leadMonthSwitches = switchovers.filter(s=>s.tech_id===tech.id&&s.week_key?.startsWith(`${y}-${mo}`)).length;
  const leadHitsQuota = leadMonthUpsells>=q.upsells && leadMonthReviews>=q.reviews && leadMonthSwitches>=q.switchovers;

  const hittingCount  = teamMemberStats.filter(m=>m.allHit).length;
  const totalMembers  = teamMembers.length;
  const allTeamHit    = leadHitsQuota && hittingCount === totalMembers;
  const twoThirdsHit  = leadHitsQuota && hittingCount >= Math.ceil(totalMembers * (2/3));
  const teamTotalPts  = teamMemberStats.reduce((s,m)=>s+m.total,0); // team members ONLY — lead excluded

  let overridePct = 0;
  if (allTeamHit)       overridePct = TEAM_LEAD_OVERRIDE_PCT_FULL;
  else if (twoThirdsHit) overridePct = TEAM_LEAD_OVERRIDE_PCT_PARTIAL;

  const overridePts = Math.round(teamTotalPts * overridePct);
  return { overridePts, overridePct, teamMembers, teamMemberStats, allTeamHit, partialHit:twoThirdsHit&&!allTeamHit, leadHitsQuota, teamTotalPts, hittingCount, totalMembers };
}

function calcTotals(tech, upsells, switchovers, reviews, callbacks=[], jobs=[]) {
  const badgePts = calcBadgePts(tech.badges);
  const upsellAmt = (jobs||[]).filter(j=>j.tech_id===tech.id).reduce((s,j)=>s+(j.upsell_amount||0),0);
  const upsellPts = Math.round(upsellAmt*UPSELL_PTS_PER_DOLLAR);
  const switchPts = switchovers.filter(s=>s.tech_id===tech.id).reduce((s,sw)=>s+(PLAN_MAP[sw.plan_id]?.pts||0),0);
  const byMonth = {};
  reviews.filter(r=>r.tech_id===tech.id).forEach(r=>{ byMonth[r.month_key]=(byMonth[r.month_key]||0)+r.count; });
  const reviewPts = Object.values(byMonth).reduce((s,cnt)=>s+(cnt*REVIEW_PTS)+(cnt>=10?REVIEW_BONUS_PTS:0),0);
  const callbackCount = callbacks.filter(c=>c.tech_id===tech.id).length;
  const callbackPts = callbackCount * CALLBACK_PTS;
  const total = Math.max(0, badgePts+upsellPts+switchPts+reviewPts+callbackPts);
  return { badgePts, upsellAmt, upsellPts, switchPts, reviewPts, callbackPts, callbackCount, total };
}

// ─── WEEKLY PAY CALCULATOR ────────────────────────────────────────────────────
// Tiers reset each week. First $150 = 15%, then $300 = 20%, then $450 = 25%, then $700 = 30%
const PAY_TIERS = [
  { upTo: 150,  rate: 0.15, label: "0–$150",    color: C.green  },
  { upTo: 300,  rate: 0.20, label: "$150–$300",  color: C.blue   },
  { upTo: 450,  rate: 0.25, label: "$300–$450",  color: C.gold   },
  { upTo: 700,  rate: 0.30, label: "$450–$700",  color: C.orange },
];

function calcWeeklyPay(weeklyUpsellAmt) {
  // Flat rate unlocks and backfills ALL upsells for the week
  let rate;
  if      (weeklyUpsellAmt >= 700) rate = 0.30;
  else if (weeklyUpsellAmt >= 400) rate = 0.25;
  else if (weeklyUpsellAmt >= 150) rate = 0.20;
  else                              rate = 0.15;
  const totalPay = weeklyUpsellAmt * rate;
  return { totalPay, rate };
}

function getNextPayTier(weeklyAmt) {
  if (weeklyAmt < 150) return { amt: 150 - weeklyAmt, rate: 0.20, label: "20% on your whole week" };
  if (weeklyAmt < 400) return { amt: 400 - weeklyAmt, rate: 0.25, label: "25% on your whole week" };
  if (weeklyAmt < 700) return { amt: 700 - weeklyAmt, rate: 0.30, label: "30% on your whole week" };
  return { amt: null, rate: 0.30, label: "MAX RATE — 30% on your whole week 🔥" };
}


const GS = `
  @import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,400;0,600;0,700;0,800;0,900;1,700;1,800;1,900&family=Barlow:wght@400;500;600;700&display=swap');
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#f0f8ff; color:#0d2240; font-family:'Barlow',sans-serif; -webkit-font-smoothing:antialiased; }
  ::-webkit-scrollbar { width:4px; } ::-webkit-scrollbar-track { background:#e8f4ff; } ::-webkit-scrollbar-thumb { background:#c5dff8; border-radius:2px; }
  input,select,button { font-family:'Barlow',sans-serif; }
  input[type=number]::-webkit-inner-spin-button { -webkit-appearance:none; }
  input, select { color-scheme: light; }
`;

// ─── BASE COMPONENTS ──────────────────────────────────────────────────────────
function Logo({ h=40 }) {
  return <img src={LOGO_SRC} alt="Skylo" style={{ height:`${h}px`, objectFit:"contain" }}/>;
}

function Header({ right, left, title, subtitle }) {
  return (
    <div style={{ background:C.white, borderBottom:`3px solid ${C.blue}`, padding:"0 16px", display:"flex", alignItems:"center", justifyContent:"space-between", height:"64px", boxShadow:"0 2px 12px rgba(43,156,240,0.12)", position:"sticky", top:0, zIndex:100 }}>
      <div style={{ display:"flex", alignItems:"center", gap:"12px" }}>
        {left}
        <Logo h={34}/>
        {title && (
          <div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"17px", letterSpacing:"1px", textTransform:"uppercase", color:C.black, lineHeight:1 }}>{title}</div>
            {subtitle && <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", marginTop:"2px" }}>{subtitle}</div>}
          </div>
        )}
      </div>
      {right}
    </div>
  );
}

function HamburgerBtn({ onClick }) {
  return (
    <button onClick={onClick} style={{ background:"none", border:"none", cursor:"pointer", padding:"6px", display:"flex", flexDirection:"column", gap:"5px", flexShrink:0 }}>
      <div style={{ width:"20px", height:"2px", background:C.black, borderRadius:"1px" }}/>
      <div style={{ width:"20px", height:"2px", background:C.black, borderRadius:"1px" }}/>
      <div style={{ width:"20px", height:"2px", background:C.black, borderRadius:"1px" }}/>
    </button>
  );
}

function SideNav({ sections, active, setActive, open, onClose, name, role }) {
  return (
    <>
      {open&&<div onClick={onClose} style={{ position:"fixed", inset:0, background:"rgba(13,34,64,0.55)", zIndex:300 }}/>}
      <div style={{ position:"fixed", top:0, left:0, height:"100%", width:"272px", background:C.white, zIndex:301, transform:open?"translateX(0)":"translateX(-100%)", transition:"transform 0.22s cubic-bezier(.4,0,.2,1)", boxShadow:"6px 0 24px rgba(0,0,0,0.18)", display:"flex", flexDirection:"column", overflowY:"auto" }}>
        {/* Drawer header */}
        <div style={{ background:`linear-gradient(135deg, ${C.blue} 0%, #0077cc 100%)`, padding:"20px 18px 16px", flexShrink:0 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"12px" }}>
            <Logo h={30}/>
            <button onClick={onClose} style={{ background:"rgba(255,255,255,0.15)", border:"none", color:"#fff", width:"28px", height:"28px", borderRadius:"50%", cursor:"pointer", fontSize:"14px", display:"flex", alignItems:"center", justifyContent:"center" }}>✕</button>
          </div>
          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"20px", color:"#fff", lineHeight:1 }}>{name}</div>
          {role&&<div style={{ fontSize:"11px", color:"rgba(255,255,255,0.7)", letterSpacing:"2px", textTransform:"uppercase", marginTop:"3px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"600" }}>{role}</div>}
        </div>
        {/* Nav sections */}
        <div style={{ flex:1, paddingBottom:"24px" }}>
          {sections.map((sec,si)=>(
            <div key={si} style={{ paddingTop:"8px" }}>
              {sec.label&&<div style={{ padding:"10px 18px 4px", fontSize:"9px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{sec.label}</div>}
              {sec.items.map(([id,icon,label])=>(
                <button key={id} onClick={()=>{ setActive(id); onClose(); }} style={{ width:"100%", display:"flex", alignItems:"center", gap:"12px", padding:"11px 18px", background:active===id?`${C.blue}12`:"none", border:"none", borderLeft:active===id?`3px solid ${C.blue}`:"3px solid transparent", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:active===id?"900":"700", fontSize:"14px", color:active===id?C.blue:C.black, textAlign:"left", transition:"background 0.12s" }}>
                  <span style={{ fontSize:"17px", width:"24px", textAlign:"center" }}>{icon}</span>
                  {label}
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function LogoutBtn({ onLogout }) {
  return (
    <button onClick={onLogout} style={{ background:"none", border:`2px solid ${C.border}`, color:C.muted, padding:"6px 16px", borderRadius:"20px", cursor:"pointer", fontSize:"11px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", letterSpacing:"2px", textTransform:"uppercase" }}>
      EXIT
    </button>
  );
}

function TabBar({ tabs, active, setActive, accent }) {
  const ac = accent || C.blue;
  return (
    <div style={{ display:"flex", background:C.white, borderBottom:`1px solid ${C.border}`, overflowX:"auto", WebkitOverflowScrolling:"touch", scrollbarWidth:"none", boxShadow:"0 1px 4px rgba(43,156,240,0.08)" }}>
      {tabs.map(([id,label]) => (
        <button key={id} onClick={()=>setActive(id)} style={{
          background:"none", border:"none", cursor:"pointer", whiteSpace:"nowrap",
          padding:"14px 18px", fontSize:"11px", letterSpacing:"2px", textTransform:"uppercase",
          fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800",
          color:active===id?ac:C.muted, flexShrink:0,
          borderBottom:active===id?`3px solid ${ac}`:"3px solid transparent",
        }}>{label}</button>
      ))}
    </div>
  );
}

function Num({ val, size=32, color=C.white, unit="" }) {
  return (
    <div style={{ display:"flex", alignItems:"baseline", gap:"3px" }}>
      <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:`${size}px`, color, lineHeight:1 }}>{val}</span>
      {unit && <span style={{ fontSize:`${size*0.45}px`, color:C.muted, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{unit}</span>}
    </div>
  );
}

function StatBlock({ label, value, color, sub, accent }) {
  return (
    <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${accent||color||C.blue}`, borderRadius:"12px", padding:"16px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
      <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginBottom:"8px" }}>{label}</div>
      <Num val={value} color={color||C.black} size={28}/>
      {sub && <div style={{ fontSize:"11px", color:C.muted, marginTop:"5px" }}>{sub}</div>}
    </div>
  );
}

function Bar({ pct, color=C.blue, h=5 }) {
  return (
    <div style={{ background:C.border, borderRadius:"4px", height:`${h}px`, overflow:"hidden" }}>
      <div style={{ width:`${Math.min(pct,100)}%`, height:"100%", background:color, borderRadius:"4px" }}/>
    </div>
  );
}

function Label({ children, color=C.blue }) {
  return (
    <div style={{ fontSize:"11px", color, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", marginBottom:"10px" }}>{children}</div>
  );
}

// Marker for archived (is_active=false) techs in historical views — reports,
// payroll, audit history — where their past data must stay visible, just
// clearly labeled so it's not mistaken for a current active tech.
function ArchivedTag() {
  return <span style={{ fontSize:"10px", color:C.muted, fontWeight:"600", fontStyle:"italic", marginLeft:"5px" }}>(Archived)</span>;
}

function Pill({ children, color=C.blue }) {
  return (
    <span style={{ display:"inline-block", background:`${color}22`, border:`1px solid ${color}55`, color, borderRadius:"3px", padding:"2px 8px", fontSize:"10px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", letterSpacing:"1px", textTransform:"uppercase" }}>
      {children}
    </span>
  );
}

// ─── PIN PAD ──────────────────────────────────────────────────────────────────
function PinPad({ onSubmit }) {
  const [pin, setPin] = useState("");
  const [shake, setShake] = useState(false);
  useEffect(() => {
    if (pin.length===4) {
      const ok = onSubmit(pin);
      if (!ok) { setShake(true); setTimeout(()=>{ setShake(false); setPin(""); },500); }
    }
  }, [pin]);
  const press = d => { if (pin.length<4) setPin(p=>p+d); };
  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:"32px" }}>
      <div style={{ display:"flex", gap:"14px", animation:shake?"shake .4s ease":"none" }}>
        {[0,1,2,3].map(i=>(
          <div key={i} style={{ width:"16px", height:"16px", borderRadius:"50%", background:i<pin.length?C.blue:"transparent", border:`2px solid ${i<pin.length?C.blue:C.border}` }}/>
        ))}
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,72px)", gap:"10px" }}>
        {[1,2,3,4,5,6,7,8,9,"",0,"⌫"].map((d,i)=>(
          <button key={i} onClick={()=>d==="⌫"?setPin(p=>p.slice(0,-1)):d!==""?press(String(d)):null}
            disabled={d===""}
            style={{ width:"72px", height:"72px", borderRadius:"12px", background:d===""?"transparent":C.white, border:d===""?"none":`2px solid ${C.border}`, color:d==="⌫"?C.muted:C.black, fontSize:d==="⌫"?"20px":"24px", fontWeight:"700", cursor:d===""?"default":"pointer", fontFamily:"'Barlow Condensed',sans-serif", boxShadow:d===""?"none":"0 2px 8px rgba(43,156,240,0.12)" }}>
            {d}
          </button>
        ))}
      </div>
      <style>{`@keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-6px)}40%,80%{transform:translateX(6px)}}${GS}`}</style>
    </div>
  );
}

// ─── BADGE GRID ───────────────────────────────────────────────────────────────
function BadgeGrid({ earned }) {
  const cats = ["Prestige","Revenue","Clean Streak","Performance","Character","Tenure","Trophy"];
  const catColors = { Prestige:C.gold, Revenue:C.green, "Clean Streak":C.blue, Performance:C.purple, Character:C.orange, Tenure:C.muted, Trophy:"#ff6ef7" };
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"24px" }}>
      {/* Rotating Trophies info */}
      <div style={{ background:"#ff6ef718", border:"1px solid #ff6ef744", borderRadius:"12px", padding:"12px 16px" }}>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:"#ff6ef7", letterSpacing:"2px", marginBottom:"6px" }}>🏆 ROTATING MONTHLY TROPHIES</div>
        <div style={{ fontSize:"12px", color:C.muted }}>These badges are passed to whoever is in the lead each month — no points, pure bragging rights.</div>
        <div style={{ display:"flex", gap:"8px", flexWrap:"wrap", marginTop:"10px" }}>
          {ROTATING_TROPHIES.map(t=>(
            <div key={t.id} style={{ background:earned?.includes(t.id)?"#ff6ef722":"rgba(0,0,0,0.2)", border:`1px solid ${earned?.includes(t.id)?"#ff6ef7":"#333"}`, borderRadius:"4px", padding:"6px 12px", opacity:earned?.includes(t.id)?1:0.5 }}>
              <span style={{ fontSize:"16px" }}>{t.icon}</span>
              <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", color:earned?.includes(t.id)?"#ff6ef7":C.muted, marginLeft:"6px" }}>{t.name}</span>
            </div>
          ))}
        </div>
      </div>
      {cats.filter(c=>c!=="Trophy").map(cat=>{
        const badges = ALL_BADGE_DEFS.filter(b=>b.cat===cat);
        if (!badges.length) return null;
        const col = catColors[cat] || C.blue;
        return (
          <div key={cat}>
            <div style={{ fontSize:"10px", color:col, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", marginBottom:"10px" }}>{cat}</div>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(160px,1fr))", gap:"8px" }}>
              {badges.map(b=>{
                const have = earned?.includes(b.id);
                return (
                  <div key={b.id} style={{ background:have?`${col}18`:"rgba(0,0,0,0.2)", border:`1px solid ${have?col+"55":C.border}`, borderRadius:"12px", padding:"10px 12px", opacity:have?1:0.45 }}>
                    <div style={{ fontSize:"22px", marginBottom:"5px" }}>{b.icon}</div>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"13px", color:have?C.white:C.muted }}>{b.name}</div>
                    <div style={{ fontSize:"10px", color:col, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginTop:"2px" }}>{b.pts>0?`+${b.pts} pts`:"Trophy"}</div>
                    <div style={{ fontSize:"10px", color:C.muted, marginTop:"4px", lineHeight:"1.3" }}>{b.desc}</div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}


// ─── UPSELL LEADERBOARD ───────────────────────────────────────────────────────
function UpsellLeaderboard({ techs, upsells, jobs=[], currentId }) {
  const wk = getWeekKey();
  const byWeek = {};
  upsells.forEach(u=>{ if(!byWeek[u.week_key])byWeek[u.week_key]={}; byWeek[u.week_key][u.tech_id]=(byWeek[u.week_key][u.tech_id]||0)+u.amount; });
  const allWeeks = Object.keys(byWeek).sort((a,b)=>b.localeCompare(a));
  const [selectedWeek, setSelectedWeek] = useState(wk);
  const allTime = {};
  upsells.forEach(u=>{ allTime[u.tech_id]=(allTime[u.tech_id]||0)+u.amount; });

  // Selected week data
  const wkData = byWeek[selectedWeek]||{};
  const ranked = [...techs].map(t=>({...t,amt:wkData[t.id]||0,all:allTime[t.id]||0})).sort((a,b)=>b.amt-a.amt);
  const top = ranked[0]?.amt||1;
  const weekTotal = ranked.reduce((s,t)=>s+t.amt,0);

  // Date range — same WTD/Last Week/MTD/Last Month/YTD/Custom control as
  // Revenue's Time Period panel (getDateRangeBounds). Filters by each entry's
  // real completion date (jobs.job_date, joined via hcp_job_id), not
  // week_key, now that Repair Upsells has been run across full history and
  // populates jobs.upsell_amount with day-level data for ~95% of entries.
  // The remaining entries (manually entered, no hcp_job_id) have no exact
  // date to match against, so they're excluded from range filtering rather
  // than approximated by week — surfaced separately below so nothing is
  // silently dropped.
  const [rangePreset, setRangePreset] = useState("wtd");
  const [cStart, setCStart] = useState("");
  const [cEnd, setCEnd] = useState("");
  const { start: rangeStart, end: rangeEnd } = getDateRangeBounds(rangePreset, cStart, cEnd);
  const jobDateByHcpId = {};
  jobs.forEach(j => { if (j.hcp_job_id && !jobDateByHcpId[j.hcp_job_id]) jobDateByHcpId[j.hcp_job_id] = j.job_date; });
  const upsellsWithDate = upsells.map(u => ({ ...u, resolvedDate: u.hcp_job_id ? (jobDateByHcpId[u.hcp_job_id] || null) : null }));
  const rangeInRange = upsellsWithDate.filter(u => u.resolvedDate && u.resolvedDate >= rangeStart && u.resolvedDate <= rangeEnd);
  const noDateEntries = upsellsWithDate.filter(u => !u.resolvedDate);
  const noDateTotal = noDateEntries.reduce((s,u)=>s+(u.amount||0),0);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"20px" }}>

      {/* Week selector */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"14px 18px" }}>
        <Label color={C.green}>📅 Select Week</Label>
        <select
          value={selectedWeek}
          onChange={e=>setSelectedWeek(e.target.value)}
          style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", width:"100%", cursor:"pointer" }}
        >
          {allWeeks.length === 0 && <option value={wk}>{formatWeekLabel(wk)} — Current Week</option>}
          {allWeeks.map(w=>(
            <option key={w} value={w}>{formatWeekLabel(w)}{w===wk?" — Current":""}</option>
          ))}
        </select>
      </div>

      {/* Selected week breakdown */}
      <div style={{ background:C.card, border:`1px solid ${selectedWeek===wk?C.blue:C.border}`, borderTop:`3px solid ${C.green}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"16px", color:C.black }}>{formatWeekLabel(selectedWeek)}</div>
            {selectedWeek===wk&&<div style={{ fontSize:"10px", color:C.blue, letterSpacing:"1px", textTransform:"uppercase", marginTop:"2px" }}>Current Week</div>}
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"24px", color:C.green }}>${weekTotal.toLocaleString()}</div>
            <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>TEAM TOTAL</div>
          </div>
        </div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"8px" }}>
          {ranked.filter(t=>t.amt>0).map((t,idx)=>{
            const isMe=t.id===currentId; const pct=top>0?Math.round((t.amt/top)*100):0;
            return (
              <div key={t.id} style={{ background:idx===0?`${C.green}12`:isMe?`${C.blue}12`:"transparent", border:`1px solid ${idx===0?C.green:isMe?`${C.blue}44`:C.border}`, borderRadius:"12px", padding:"10px 12px" }}>
                <div style={{ display:"flex", alignItems:"center", gap:"12px", marginBottom:"6px" }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:idx===0?"28px":idx<3?"22px":"16px", color:idx===0?C.green:idx===1?"#a8c0d6":idx===2?"#cd7f32":C.muted, width:"30px", textAlign:"center", lineHeight:1 }}>{medal(idx)}</div>
                  <div style={{ width:"36px", height:"36px", borderRadius:"50%", background:`${C.blue}22`, border:`1px solid ${C.blue}44`, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"12px", fontWeight:"800", color:C.blue, flexShrink:0 }}>{t.avatar}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"16px", color:C.black }}>{t.name}{isMe&&<span style={{ color:C.blue, fontSize:"11px", marginLeft:"6px", fontStyle:"normal" }}>YOU</span>}</div>
                    <div style={{ fontSize:"11px", color:C.muted }}>+{Math.round(t.amt*UPSELL_PTS_PER_DOLLAR)} pts this week</div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"24px", color:idx===0?C.green:C.black }}>${t.amt.toLocaleString()}</div>
                  </div>
                </div>
                <Bar pct={pct} color={idx===0?C.green:C.blue} h={5}/>
              </div>
            );
          })}
          {ranked.filter(t=>t.amt===0).length>0&&(
            <div style={{ borderTop:`1px dashed ${C.border}`, paddingTop:"8px", marginTop:"4px" }}>
              <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", marginBottom:"6px" }}>No upsells logged yet this week</div>
              {ranked.filter(t=>t.amt===0).map(t=>{
                const isMe=t.id===currentId;
                return (
                  <div key={t.id} style={{ display:"flex", alignItems:"center", gap:"10px", padding:"6px 8px", opacity:0.5 }}>
                    <div style={{ width:"36px", height:"36px", borderRadius:"50%", background:C.cardLt, border:`1px solid ${C.border}`, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"12px", fontWeight:"800", color:C.muted }}>{t.avatar}</div>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"14px", color:C.muted }}>{t.name}{isMe&&" — YOU"}</div>
                    <div style={{ marginLeft:"auto", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:C.muted }}>$0</div>
                  </div>
                );
              })}
            </div>
          )}
          {weekTotal===0&&<div style={{ fontSize:"13px", color:C.muted, textAlign:"center", padding:"12px" }}>No upsells logged for this week yet</div>}
        </div>
      </div>

      {/* Running totals pinned at bottom */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.green}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
          <Label color={C.green}>💰 Running Totals — All Time</Label>
        </div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"10px" }}>
          {[...techs].sort((a,b)=>(allTime[b.id]||0)-(allTime[a.id]||0)).map((t,i)=>{
            const amt=allTime[t.id]||0; const topAmt=Math.max(...techs.map(x=>allTime[x.id]||0))||1; const pct=Math.round((amt/topAmt)*100);
            return (
              <div key={t.id}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"5px" }}>
                  <span style={{ fontSize:"13px", fontWeight:"600", color:t.id===currentId?C.blue:C.black }}>{medal(i)} {t.name}{t.id===currentId?" — YOU":""}</span>
                  <div style={{ textAlign:"right" }}>
                    <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:C.black }}>${amt.toLocaleString()}</span>
                    <span style={{ fontSize:"11px", color:C.green, marginLeft:"8px" }}>{Math.round(amt*UPSELL_PTS_PER_DOLLAR).toLocaleString()} pts</span>
                  </div>
                </div>
                <Bar pct={pct} color={C.green}/>
              </div>
            );
          })}
        </div>
      </div>

      {/* Date Range */}
      <DateRangePicker label="📅 Date Range" color={C.green} preset={rangePreset} setPreset={setRangePreset} customStart={cStart} setCustomStart={setCStart} customEnd={cEnd} setCustomEnd={setCEnd}>
        <div style={{ fontSize:"11px", color:C.green, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginTop:"8px" }}>
          {rangeStart} → {rangeEnd} · matched by exact completion date · ${rangeInRange.reduce((s,u)=>s+(u.amount||0),0).toLocaleString()} · {rangeInRange.length} entr{rangeInRange.length!==1?"ies":"y"}
        </div>
        {noDateEntries.length>0&&(
          <div style={{ fontSize:"11px", color:C.muted, marginTop:"6px" }}>
            ⚠ {noDateEntries.length} entr{noDateEntries.length!==1?"ies":"y"} totaling ${noDateTotal.toLocaleString()} {noDateEntries.length!==1?"have":"has"} no matched completion date (manually entered, not tied to an HCP job) — excluded from every range above, not just this one.
          </div>
        )}
      </DateRangePicker>

      {(() => {
        const rangeByTech = {};
        rangeInRange.forEach(u => { rangeByTech[u.tech_id] = (rangeByTech[u.tech_id] || 0) + (u.amount || 0); });
        const rangeRanked = techs
          .map(t => ({ ...t, amt: rangeByTech[t.id] || 0 }))
          .filter(t => t.amt > 0)
          .sort((a, b) => b.amt - a.amt);
        const rangeTop = rangeRanked[0]?.amt || 1;
        return (
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.green}`, borderRadius:"12px", overflow:"hidden" }}>
            <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
              <Label color={C.green}>💰 Upsells · {rangeStart} → {rangeEnd}</Label>
            </div>
            <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"8px" }}>
              {rangeRanked.length===0 && <div style={{ fontSize:"13px", color:C.muted, textAlign:"center", padding:"12px" }}>No upsells logged in this range.</div>}
              {rangeRanked.map((t,i)=>{
                const pct = Math.round((t.amt/rangeTop)*100);
                return (
                  <div key={t.id}>
                    <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"5px" }}>
                      <span style={{ fontSize:"13px", color:t.id===currentId?C.blue:C.black }}>{medal(i)} {t.name}{t.id===currentId?" — YOU":""}</span>
                      <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:C.black }}>${t.amt.toLocaleString()}</span>
                    </div>
                    <Bar pct={pct} color={C.green}/>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })()}
    </div>
  );
}

// ─── SWITCHOVER LEADERBOARD ───────────────────────────────────────────────────
function SwitchoverLeaderboard({ techs, switchovers, currentId }) {
  const [rankBy, setRankBy] = useState("count");
  const wk = getWeekKey();
  const byWeek = {};
  switchovers.forEach(s=>{ if(!byWeek[s.week_key])byWeek[s.week_key]={}; if(!byWeek[s.week_key][s.tech_id])byWeek[s.week_key][s.tech_id]=[]; byWeek[s.week_key][s.tech_id].push({plan:s.plan_id}); });
  const allWeeks = Object.keys(byWeek).sort((a,b)=>b.localeCompare(a));
  const wkData = byWeek[wk]||{};
  const allCount={}, allPts={};
  switchovers.forEach(s=>{ allCount[s.tech_id]=(allCount[s.tech_id]||0)+1; allPts[s.tech_id]=(allPts[s.tech_id]||0)+(PLAN_MAP[s.plan_id]?.pts||0); });
  const ranked = [...techs].map(t=>{ const e=wkData[t.id]||[]; return {...t,count:e.length,pts:e.reduce((s,x)=>s+(PLAN_MAP[x.plan]?.pts||0),0),allCount:allCount[t.id]||0,allPts:allPts[t.id]||0,entries:e}; }).sort((a,b)=>rankBy==="count"?b.count-a.count:b.pts-a.pts);
  const top=ranked[0]?.[rankBy==="count"?"count":"pts"]||1;

  // Date range — same WTD/Last Week/MTD/Last Month/YTD/Custom control as
  // Revenue's Time Period panel (getDateRangeBounds). Entries are only
  // logged with a week_key (Monday of the week), not an exact day, so range
  // filtering matches by week overlap: any switchover whose week starts
  // on/after the Monday of the range start and on/before the range end.
  const [rangePreset, setRangePreset] = useState("wtd");
  const [cStart, setCStart] = useState("");
  const [cEnd, setCEnd] = useState("");
  const { start: rangeStart, end: rangeEnd } = getDateRangeBounds(rangePreset, cStart, cEnd);
  function mondayOf(dateStr) {
    const d = new Date(dateStr + "T12:00:00Z");
    const day = d.getUTCDay();
    const back = day === 0 ? 6 : day - 1;
    d.setUTCDate(d.getUTCDate() - back);
    return d.toISOString().split("T")[0];
  }
  const rangeFromWk = mondayOf(rangeStart);
  const rangeInRange = switchovers.filter(s => s.week_key >= rangeFromWk && s.week_key <= rangeEnd);
  const rangeByTech = {};
  rangeInRange.forEach(s => {
    if (!rangeByTech[s.tech_id]) rangeByTech[s.tech_id] = { total: 0, byPlan: {} };
    rangeByTech[s.tech_id].total++;
    rangeByTech[s.tech_id].byPlan[s.plan_id] = (rangeByTech[s.tech_id].byPlan[s.plan_id] || 0) + 1;
  });
  const rangeRanked = techs
    .map(t => ({ ...t, total: rangeByTech[t.id]?.total || 0, byPlan: rangeByTech[t.id]?.byPlan || {} }))
    .filter(t => t.total > 0)
    .sort((a, b) => b.total - a.total);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"24px" }}>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}` }}><Label color={C.purple}>🔄 All-Time Switchovers</Label></div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"8px" }}>
          {[...techs].sort((a,b)=>(allPts[b.id]||0)-(allPts[a.id]||0)).map((t,i)=>(
            <div key={t.id} style={{ display:"flex", justifyContent:"space-between" }}>
              <span style={{ fontSize:"13px", color:t.id===currentId?C.blue:C.black }}>{medal(i)} {t.name}{t.id===currentId?" — YOU":""}</span>
              <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"13px", color:C.black }}>{allCount[t.id]||0} switchovers · {(allPts[t.id]||0).toLocaleString()} pts</span>
            </div>
          ))}
        </div>
      </div>
      <div>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"12px" }}>
          <Label>This Week · {formatWeekLabel(wk)}</Label>
          <div style={{ display:"flex", gap:"6px" }}>
            {[["count","COUNT"],["pts","POINTS"]].map(([id,label])=>(
              <button key={id} onClick={()=>setRankBy(id)} style={{ background:rankBy===id?C.blue:"none", border:`1px solid ${rankBy===id?C.blue:C.border}`, color:rankBy===id?C.white:C.muted, padding:"4px 10px", borderRadius:"4px", cursor:"pointer", fontSize:"10px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", letterSpacing:"1px" }}>{label}</button>
            ))}
          </div>
        </div>
        <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
          {ranked.map((t,idx)=>{
            const isMe=t.id===currentId; const val=rankBy==="count"?t.count:t.pts; const pct=top>0?Math.round((val/top)*100):0;
            return (
              <div key={t.id} style={{ background:isMe?`${C.blue}18`:C.card, border:`1px solid ${isMe?C.blue:C.border}`, borderRadius:"12px", padding:"14px 18px" }}>
                <div style={{ display:"flex", alignItems:"center", gap:"12px", marginBottom:"10px" }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:idx<3?"22px":"14px", color:C.muted, width:"28px", textAlign:"center" }}>{medal(idx)}</div>
                  <div style={{ width:"38px", height:"38px", borderRadius:"50%", background:`${C.blue}22`, border:`1px solid ${C.blue}44`, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"12px", fontWeight:"800", color:C.blue, flexShrink:0 }}>{t.avatar}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"16px", color:C.black }}>{t.name}{isMe&&<span style={{ color:C.blue, fontSize:"11px", marginLeft:"6px" }}>YOU</span>}</div>
                    <div style={{ fontSize:"11px", color:C.muted }}>All-time: {t.allCount} switchovers · {t.allPts.toLocaleString()} pts</div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"24px", color:t.count>0?C.white:C.border }}>{t.count}</div>
                    <div style={{ fontSize:"11px", color:C.purple }}>+{t.pts} pts</div>
                  </div>
                </div>
                <Bar pct={pct} color={C.purple}/>
                {t.entries.length>0&&(
                  <div style={{ display:"flex", flexWrap:"wrap", gap:"5px", marginTop:"10px" }}>
                    {t.entries.map((e,i)=>{ const plan=PLAN_MAP[e.plan]; const pc=PLAN_COLORS[e.plan]||C.muted; return plan?(<span key={i} style={{ background:`${pc}22`, border:`1px solid ${pc}55`, borderLeft:`3px solid ${pc}`, borderRadius:"3px", padding:"2px 8px", fontSize:"11px", color:C.black, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{plan.label} +{plan.pts}pts</span>):null; })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Date Range */}
      <DateRangePicker label="📅 Date Range" color={C.purple} preset={rangePreset} setPreset={setRangePreset} customStart={cStart} setCustomStart={setCStart} customEnd={cEnd} setCustomEnd={setCEnd}>
        <div style={{ fontSize:"11px", color:C.purple, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginTop:"8px" }}>
          {rangeStart} → {rangeEnd} · matched by week (switchovers are logged by week, not exact day)
        </div>
      </DateRangePicker>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.purple}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
          <Label color={C.purple}>🔄 Switchovers by Plan Type · {rangeStart} → {rangeEnd}</Label>
        </div>
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"13px" }}>
            <thead>
              <tr>
                <th style={{ padding:"8px 18px", textAlign:"left", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"11px", borderBottom:`1px solid ${C.border}`, whiteSpace:"nowrap" }}>TECH</th>
                <th style={{ padding:"8px 18px", textAlign:"left", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"11px", borderBottom:`1px solid ${C.border}` }}>BREAKDOWN</th>
              </tr>
            </thead>
            <tbody>
              {rangeRanked.length===0 && (
                <tr><td colSpan={2} style={{ padding:"16px 18px", color:C.muted, textAlign:"center" }}>No switchovers logged in this range.</td></tr>
              )}
              {rangeRanked.map((t,i)=>{
                const breakdown = Object.entries(t.byPlan).sort((a,b)=>b[1]-a[1]).map(([planId,count])=>`${count} ${PLAN_MAP[planId]?.label||planId}`).join(", ");
                return (
                  <tr key={t.id} style={{ borderBottom:`1px solid ${C.border}` }}>
                    <td style={{ padding:"10px 18px", color:t.id===currentId?C.blue:C.black, fontWeight:"700", fontFamily:"'Barlow Condensed',sans-serif", whiteSpace:"nowrap" }}>{medal(i)} {t.name}{t.id===currentId?" — YOU":""}</td>
                    <td style={{ padding:"10px 18px", color:C.black }}>{breakdown} <span style={{ color:C.muted, fontSize:"11px" }}>({t.total} total)</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"14px 18px" }}>
        <Label color={C.purple}>Plan Values</Label>
        <div style={{ display:"flex", flexWrap:"wrap", gap:"6px" }}>
          {SERVICE_PLANS.map(p=>{ const pc=PLAN_COLORS[p.id]; return (
            <div key={p.id} style={{ background:`${pc}15`, border:`1px solid ${pc}44`, borderLeft:`3px solid ${pc}`, borderRadius:"4px", padding:"4px 10px", fontSize:"12px" }}>
              <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", color:C.black }}>{p.label} </span>
              <span style={{ color:C.muted }}>{p.freq} </span>
              <span style={{ color:pc, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>+{p.pts}pts </span>
              <span style={{ color:C.green, fontFamily:"'Barlow Condensed',sans-serif" }}>${p.ltv.toLocaleString()}/yr LTV</span>
            </div>
          ); })}
        </div>
      </div>
    </div>
  );
}

// ─── REVIEW LEADERBOARD ───────────────────────────────────────────────────────
function ReviewLeaderboard({ techs, reviews, currentId }) {
  const mk = getMonthKey();
  const byMonth = {};
  reviews.forEach(r=>{ if(!byMonth[r.month_key])byMonth[r.month_key]={}; byMonth[r.month_key][r.tech_id]=(byMonth[r.month_key][r.tech_id]||0)+r.count; });
  const allMonths = Object.keys(byMonth).sort((a,b)=>b.localeCompare(a));
  const [selectedMonth, setSelectedMonth] = useState(mk);
  const allTime = {};
  reviews.forEach(r=>{ allTime[r.tech_id]=(allTime[r.tech_id]||0)+r.count; });

  const mData = byMonth[selectedMonth]||{};
  const ranked = [...techs].map(t=>({...t,cnt:mData[t.id]||0})).sort((a,b)=>b.cnt-a.cnt);
  const top = ranked[0]?.cnt||1;
  const monthTotal = ranked.reduce((s,t)=>s+t.cnt,0);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"20px" }}>
      {/* Points info */}
      <div style={{ background:`${C.gold}18`, border:`1px solid ${C.gold}44`, borderRadius:"12px", padding:"12px 18px", display:"flex", gap:"24px", flexWrap:"wrap" }}>
        <div><span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:C.gold }}>+{REVIEW_PTS}</span><span style={{ fontSize:"12px", color:C.muted, marginLeft:"6px" }}>pts per review</span></div>
        <div><span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:C.gold }}>+{REVIEW_BONUS_PTS}</span><span style={{ fontSize:"12px", color:C.muted, marginLeft:"6px" }}>bonus at 10+ in a month</span></div>
      </div>

      {/* Month selector */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"14px 18px" }}>
        <Label color={C.gold}>📅 Select Month</Label>
        <select
          value={selectedMonth}
          onChange={e=>setSelectedMonth(e.target.value)}
          style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", width:"100%", cursor:"pointer" }}
        >
          {allMonths.length === 0 && <option value={mk}>{formatMonthLabel(mk)} — Current Month</option>}
          {allMonths.map(m=>(
            <option key={m} value={m}>{formatMonthLabel(m)}{m===mk?" — Current":""}</option>
          ))}
        </select>
      </div>

      {/* Selected month breakdown */}
      <div style={{ background:C.card, border:`1px solid ${selectedMonth===mk?C.gold:C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"16px", color:C.black }}>{formatMonthLabel(selectedMonth)}</div>
            {selectedMonth===mk&&<div style={{ fontSize:"10px", color:C.gold, letterSpacing:"1px", textTransform:"uppercase", marginTop:"2px" }}>Current Month</div>}
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"24px", color:C.gold }}>{monthTotal} ⭐</div>
            <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>TEAM TOTAL</div>
          </div>
        </div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"10px" }}>
          {ranked.map((t,idx)=>{
            const isMe=t.id===currentId; const pct=top>0?Math.round((t.cnt/top)*100):0; const bonus=t.cnt>=10;
            return (
              <div key={t.id} style={{ background:isMe?`${C.blue}18`:"transparent", border:isMe?`1px solid ${C.blue}44`:"1px solid transparent", borderRadius:"12px", padding:"10px 12px" }}>
                <div style={{ display:"flex", alignItems:"center", gap:"12px", marginBottom:"8px" }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:idx<3?"20px":"13px", color:C.muted, width:"26px", textAlign:"center" }}>{medal(idx)}</div>
                  <div style={{ width:"36px", height:"36px", borderRadius:"50%", background:`${C.blue}22`, border:`1px solid ${C.blue}44`, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"12px", fontWeight:"800", color:C.blue, flexShrink:0 }}>{t.avatar}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"15px", color:C.black }}>{t.name}{isMe&&<span style={{ color:C.blue, fontSize:"11px", marginLeft:"6px" }}>YOU</span>}</div>
                    <div style={{ fontSize:"11px", color:C.muted }}>+{(t.cnt*REVIEW_PTS)+(bonus?REVIEW_BONUS_PTS:0)} pts{bonus?" 🔥":""}</div>
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:t.cnt>0?C.gold:C.border }}>{t.cnt} ⭐</div>
                  </div>
                </div>
                <Bar pct={pct} color={C.gold} h={4}/>
                {bonus&&<div style={{ marginTop:"6px" }}><Pill color={C.gold}>🔥 Bonus unlocked</Pill></div>}
              </div>
            );
          })}
          {monthTotal===0&&<div style={{ fontSize:"13px", color:C.muted, textAlign:"center", padding:"12px" }}>No reviews logged for this month</div>}
        </div>
      </div>

      {/* Running totals pinned at bottom */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
          <Label color={C.gold}>⭐ Running Totals — All Time</Label>
        </div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"10px" }}>
          {[...techs].sort((a,b)=>(allTime[b.id]||0)-(allTime[a.id]||0)).map((t,i)=>{
            const cnt=allTime[t.id]||0; const topCnt=Math.max(...techs.map(x=>allTime[x.id]||0))||1; const pct=Math.round((cnt/topCnt)*100);
            return (
              <div key={t.id}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"5px" }}>
                  <span style={{ fontSize:"13px", color:t.id===currentId?C.blue:C.black }}>{medal(i)} {t.name}{t.id===currentId?" — YOU":""}</span>
                  <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:C.black }}>{cnt} ⭐</span>
                </div>
                <Bar pct={pct} color={C.gold}/>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── TOTAL LEADERBOARD ────────────────────────────────────────────────────────
function TotalLeaderboard({ techs, upsells, switchovers, reviews, callbacks, jobs=[] }) {
  const ranked = [...techs].map(t=>{ const tt=calcTotals(t,upsells,switchovers,reviews,callbacks||[],jobs); return {...t,...tt,tier:getTier(tt.total)}; }).sort((a,b)=>b.total-a.total);
  const top = ranked[0]?.total||1;
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
      {ranked.map((t,idx)=>{
        const pct=Math.round((t.total/top)*100);
        return (
          <div key={t.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px 18px" }}>
            <div style={{ display:"flex", alignItems:"center", gap:"12px", marginBottom:"12px" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:idx<3?"26px":"16px", color:C.muted, width:"32px", textAlign:"center" }}>{medal(idx)}</div>
              <div style={{ width:"42px", height:"42px", borderRadius:"50%", background:`${C.blue}22`, border:`1px solid ${C.blue}44`, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"13px", fontWeight:"800", color:C.blue, flexShrink:0 }}>{t.avatar}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"18px", color:C.black }}>{t.name}</div>
                <Pill color={t.tier.color}>{t.tier.icon} {t.tier.name}</Pill>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"28px", color:C.black }}>{t.total.toLocaleString()}</div>
                <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>TOTAL PTS</div>
              </div>
            </div>
            <Bar pct={pct} color={C.blue} h={4}/>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:"6px", marginTop:"10px" }}>
              {[
                {l:"Badges",    v:t.badgePts,               c:C.purple},
                {l:"Upsells",   v:`$${Math.round(t.upsellAmt).toLocaleString()}`, c:C.green},
                {l:"Switchovers",  v:t.switchPts,              c:C.blue},
                {l:"Reviews",   v:t.reviewPts,              c:C.gold},
              ].map(item=>(
                <div key={item.l} style={{ background:C.cardLt, borderRadius:"4px", padding:"8px", textAlign:"center" }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"15px", color:item.c }}>{item.v}</div>
                  <div style={{ fontSize:"9px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase" }}>{item.l}</div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── REPORTS TAB ─────────────────────────────────────────────────────────────
function ReportsTab({ techs, jobs, upsells=[], timeEntries=[], tipEntries=[], techId=null, refreshAll=async()=>{}, showToast=()=>{} }) {
  const [preset, setPreset] = useState("wtd");
  const [cStart, setCStart] = useState("");
  const [cEnd,   setCEnd]   = useState("");
  const revTodayDefault = new Date(Date.now() - 6*3600000).toISOString().split("T")[0];
  const [repairRevFrom, setRepairRevFrom] = useState("2026-06-01");
  const [repairRevTo,   setRepairRevTo]   = useState(revTodayDefault);
  const [repairRevResult, setRepairRevResult] = useState(null);
  const [repairingRev, setRepairingRev] = useState(false);
  const [revExpanded, setRevExpanded] = useState(false);

  function exportRevenueCSV() {
    const rows = repairRevResult?.jobs || [];
    if (rows.length === 0) return;
    const header = ["Job ID","Tech","Date","Revenue","Invoice"];
    const csvRows = rows.map(r => [r.jobId, r.tech, r.date, r.revenue.toFixed(2), r.invoiceFound ? "Found" : "Fallback"]);
    const csv = [header, ...csvRows].map(row => row.map(cell => `"${String(cell).replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `revenue-repair_${repairRevFrom}_to_${repairRevTo}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  async function repairRevenueFromHCP() {
    setRepairingRev(true);
    setRepairRevResult(null);
    try {
      // Split range into 7-day chunks so each call stays under the 26s Netlify timeout
      const chunks = [];
      let cur = new Date(repairRevFrom + "T12:00:00Z");
      const rangeEnd = new Date(repairRevTo + "T12:00:00Z");
      while (cur <= rangeEnd) {
        const chunkFrom = cur.toISOString().split("T")[0];
        const chunkEnd = new Date(cur);
        chunkEnd.setUTCDate(chunkEnd.getUTCDate() + 6);
        const chunkTo = chunkEnd > rangeEnd ? repairRevTo : chunkEnd.toISOString().split("T")[0];
        chunks.push({ from: chunkFrom, to: chunkTo });
        cur.setUTCDate(cur.getUTCDate() + 7);
      }
      let totalScanned = 0, totalMatched = 0, totalWritten = 0, allJobRows = [];
      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        showToast(`Scanning week ${i+1} of ${chunks.length}...`);
        const endpoint = "/.netlify/functions/hcp-revenue-repair";
        const res = await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(chunk),
        });
        const text = await res.text();
        let data = null;
        try { data = text ? JSON.parse(text) : null; } catch {}
        if (!res.ok || !data || !data.ok) {
          // Report the real status instead of guessing a cause — an empty body
          // could mean a timeout, a platform block, or something else entirely.
          const detail = data?.error || (text ? text.slice(0,200) : `HTTP ${res.status}${res.statusText ? " "+res.statusText : ""} from ${endpoint} (empty response body)`);
          showToast(`Repair failed on week ${chunk.from}: ${detail}`, false);
          setRepairingRev(false);
          return;
        }
        totalScanned += data.jobsScanned || 0;
        totalMatched += data.invoicesMatched || 0;
        totalWritten += data.jobsWritten || 0;
        if (data.jobs) allJobRows.push(...data.jobs);
      }
      await refreshAll();
      setRepairRevResult({ jobsScanned: totalScanned, invoicesMatched: totalMatched, jobsWritten: totalWritten, jobs: allJobRows });
      showToast(`✅ Repaired revenue for ${totalWritten} row${totalWritten===1?"":"s"}`);
    } catch(e) { showToast("Error: "+e.message, false); }
    setRepairingRev(false);
  }
  const { start, end } = getDateRangeBounds(preset, cStart, cEnd);

  const inRange = jobs.filter(j => {
    if (!j.job_date) return false;
    if (techId && j.tech_id !== techId) return false;
    return j.job_date >= start && j.job_date <= end;
  });

  // Upsell totals: day-exact via jobs.upsell_amount over inRange (same
  // filtering as totalRevenue below), NOT the upsells table's week_key
  // bucket — that only resolves to whole-week granularity, so any preset
  // sharing a calendar week (e.g. Today/Yesterday/WTD) collapsed to the
  // same total regardless of which was selected.
  const upsellByTech = {};
  inRange.forEach(j => {
    upsellByTech[j.tech_id] = (upsellByTech[j.tech_id] || 0) + (j.upsell_amount || 0);
  });
  const totalUpsells = inRange.reduce((s,j) => s+(j.upsell_amount||0), 0);

  const totalRevenue   = inRange.reduce((s,j) => s+(j.revenue||0), 0);
  const totalTips      = techId
    ? tipsRangeTotal(tipEntries, techId, start, end)
    : tipEntries.filter(t => t.work_date >= start && t.work_date <= end).reduce((s,t) => s+(t.amount||0), 0);
  const totalHours     = techId
    ? rangeHoursTotal(timeEntries, techId, start, end)
    : timeEntries.filter(e => e.work_date >= start && e.work_date <= end).reduce((s,e) => s+sessionHours(e), 0);
  const commMap        = Object.fromEntries(techs.map(t => [t.id, (t.commission_rate||27)/100]));
  const totalLabor     = inRange.reduce((s,j) => s+(j.revenue||0)*(commMap[j.tech_id]||0.27), 0);
  const revPerHr       = totalHours > 0 ? totalRevenue/totalHours : 0;
  const upsellPct      = totalRevenue > 0 ? (totalUpsells/totalRevenue)*100 : 0;
  const laborPct       = totalRevenue > 0 ? (totalLabor/totalRevenue)*100 : 0;

  const allWkKeys = [...new Set(inRange.map(j=>j.week_key))].filter(Boolean).sort();
  const techRows = techId ? [] : techs.map(t => {
    const tj = inRange.filter(j=>j.tech_id===t.id);
    const rev  = tj.reduce((s,j)=>s+(j.revenue||0),0);
    const hrs  = rangeHoursTotal(timeEntries, t.id, start, end);
    const ups  = upsellByTech[t.id] || 0;
    const tips = tipsRangeTotal(tipEntries, t.id, start, end);
    const wkBreakdown = allWkKeys.map(wk=>{
      const wj=tj.filter(j=>j.week_key===wk);
      const wkEndDate = new Date(wk+"T12:00:00Z"); wkEndDate.setUTCDate(wkEndDate.getUTCDate()+6);
      const wkEndStr = wkEndDate.toISOString().split("T")[0];
      return { wk, rev:wj.reduce((s,j)=>s+(j.revenue||0),0), tips:tipsRangeTotal(tipEntries, t.id, wk, wkEndStr), count:wj.length };
    }).filter(w=>w.rev>0);
    return { ...t, rev, hrs, ups, tips, revPerHr:hrs>0?rev/hrs:0, upsellPct:rev>0?(ups/rev)*100:0, wkBreakdown };
  }).filter(t=>t.rev>0||t.hrs>0).sort((a,b)=>b.rev-a.rev);

  const metricStyle = { background:C.white, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      {/* Period selector */}
      <DateRangePicker label="📊 Time Period" color={C.blue} preset={preset} setPreset={setPreset} customStart={cStart} setCustomStart={setCStart} customEnd={cEnd} setCustomEnd={setCEnd}>
        <div style={{ marginTop:"8px", fontSize:"11px", color:C.blue, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>
            {start} → {end} · {inRange.length} job{inRange.length!==1?"s":""}
          </div>
      </DateRangePicker>

      {inRange.length===0?(
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"32px", textAlign:"center", color:C.muted, fontSize:"13px" }}>
          No jobs found for this period. The HCP sync runs every 5 minutes.
        </div>
      ):(
        <>
          {/* Metric cards */}
          <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:"10px" }}>
            {[
              { label:"Serviced Revenue", value:`$${Math.round(totalRevenue).toLocaleString()}`, color:C.green,                                              sub:`${inRange.length} jobs` },
              { label:"Tips",            value:`$${Math.round(totalTips).toLocaleString()}`,   color:C.gold,                                               sub:"separate from revenue" },
              { label:"Hours",           value:totalHours>0?totalHours.toFixed(1):"—",            color:C.blue,                                               sub:totalHours>0?`${(totalHours/Math.max(inRange.length,1)).toFixed(1)}h/job avg`:"Enter hours below" },
              { label:"Rev / Hour",   value:totalHours>0?`$${revPerHr.toFixed(2)}`:"—",        color:totalHours>0?(revPerHr>=75?C.green:C.orange):C.muted, sub:"Target: >$75/hr" },
              { label:"Upsell $",     value:`$${Math.round(totalUpsells).toLocaleString()}`,   color:C.gold,                                               sub:`of $${Math.round(totalRevenue).toLocaleString()} revenue` },
              { label:"Upsell Rate",  value:`${upsellPct.toFixed(1)}%`,                        color:upsellPct>=10?C.green:C.orange,                       sub:"Target: >10%" },
              { label:"Labor Cost %", value:totalLabor>0?`${laborPct.toFixed(1)}%`:"—",        color:totalLabor>0?(laborPct<24?C.green:C.orange):C.muted,  sub:"Target: <24%" },
            ].map(s=>(
              <div key={s.label} style={{ ...metricStyle, borderTop:`3px solid ${s.color}` }}>
                <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginBottom:"8px" }}>{s.label}</div>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"28px", color:s.color, lineHeight:1 }}>{s.value}</div>
                {s.sub&&<div style={{ fontSize:"11px", color:C.muted, marginTop:"5px" }}>{s.sub}</div>}
              </div>
            ))}
          </div>

          {/* Per-tech breakdown — admin / all-techs view only */}
          {techRows.length>0&&(
            <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", overflow:"hidden" }}>
              <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
                <Label color={C.blue}>Per-Tech Breakdown</Label>
              </div>
              <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"10px" }}>
                {techRows.map((t,i)=>(
                  <div key={t.id} style={{ background:C.cardLt, border:`1px solid ${C.border}`, borderRadius:"10px", padding:"12px 14px" }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"8px" }}>
                      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"16px", color:C.black }}>{medal(i)} {t.name}{t.is_active===false&&<ArchivedTag/>}</div>
                      <div style={{ textAlign:"right" }}>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:C.green, lineHeight:1 }}>${Math.round(t.rev).toLocaleString()}</div>
                        <div style={{ fontSize:"9px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase", marginBottom:"2px" }}>serviced</div>
                        {t.tips>0&&<div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:C.gold }}>${t.tips.toFixed(0)} tips</div>}
                      </div>
                    </div>
                    <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:"6px" }}>
                      {[
                        { l:"Hours",    v:t.hrs.toFixed(1),             c:C.blue   },
                        { l:"Rev/hr",   v:`$${t.revPerHr.toFixed(0)}`,  c:C.purple },
                        { l:"Upsells",  v:`$${Math.round(t.ups)}`,      c:C.gold   },
                        { l:"Upsell %", v:`${t.upsellPct.toFixed(1)}%`, c:t.upsellPct>=10?C.green:C.orange },
                      ].map(s=>(
                        <div key={s.l} style={{ background:C.white, borderRadius:"4px", padding:"6px", textAlign:"center" }}>
                          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:s.c }}>{s.v}</div>
                          <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>{s.l}</div>
                        </div>
                      ))}
                    </div>
                    {t.wkBreakdown?.length>0&&(
                      <div style={{ marginTop:"8px", borderTop:`1px solid ${C.border}`, paddingTop:"8px", display:"flex", flexDirection:"column", gap:"3px" }}>
                        {t.wkBreakdown.map(w=>(
                          <div key={w.wk} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"4px 8px", background:C.white, borderRadius:"4px" }}>
                            <div style={{ fontSize:"11px", color:C.muted, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{formatWeekLabel(w.wk)} · {w.count} job{w.count!==1?"s":""}</div>
                            <div style={{ display:"flex", gap:"8px", alignItems:"center" }}>
                              <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:C.green }}>${Math.round(w.rev).toLocaleString()}</span>
                              {w.tips>0&&<span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", color:C.gold }}>+${w.tips.toFixed(0)} tips</span>}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Repair Revenue — admin only */}
      {techId===null && (
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.orange}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"12px" }}>
          <Label color={C.orange}>Repair Revenue from HCP</Label>
          <div style={{ fontSize:"12px", color:C.muted }}>Re-scans completed jobs and their invoices across a custom date range and rewrites revenue to the board. Use this to fix missing or wrong revenue.</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"8px" }}>
            {[["FROM", repairRevFrom, setRepairRevFrom], ["TO", repairRevTo, setRepairRevTo]].map(([lbl, val, set]) => (
              <div key={lbl}>
                <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginBottom:"4px" }}>{lbl}</div>
                <input type="date" value={val} onChange={e => set(e.target.value)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"8px 10px", borderRadius:"8px", fontSize:"13px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box" }}/>
              </div>
            ))}
          </div>
          <button onClick={repairRevenueFromHCP} disabled={repairingRev} style={{ background:repairingRev?"#333":C.orange, border:"none", color:C.white, padding:"13px", borderRadius:"12px", cursor:repairingRev?"not-allowed":"pointer", fontSize:"13px", fontWeight:"700", letterSpacing:"2px", fontFamily:"'Barlow Condensed',sans-serif", width:"100%", textTransform:"uppercase" }}>
            {repairingRev ? "Scanning HCP — this may take ~20 sec..." : "Repair Revenue"}
          </button>
          {repairRevResult && (
            <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
              <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px 14px", fontSize:"12px", color:C.muted, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"8px" }}>
                <span>
                  Scanned <strong style={{color:C.black}}>{repairRevResult.jobsScanned}</strong> jobs · matched <strong style={{color:C.black}}>{repairRevResult.invoicesMatched}</strong> invoices · wrote <strong style={{color:C.orange}}>{repairRevResult.jobsWritten} row{repairRevResult.jobsWritten===1?"":"s"}</strong> to the board
                </span>
                {repairRevResult.jobs && repairRevResult.jobs.length > 0 && (
                  <div style={{ display:"flex", gap:"6px" }}>
                    <button onClick={()=>setRevExpanded(v=>!v)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"5px 10px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px", letterSpacing:"1px" }}>
                      {revExpanded ? "COLLAPSE" : "VIEW FULL REPORT"}
                    </button>
                    <button onClick={exportRevenueCSV} style={{ background:C.green, border:"none", color:C.black, padding:"5px 10px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px", letterSpacing:"1px" }}>
                      EXPORT CSV
                    </button>
                  </div>
                )}
              </div>
              {repairRevResult.jobs && repairRevResult.jobs.length > 0 && (
                <div style={{ overflowX:"auto", maxHeight: revExpanded ? "none" : "320px", overflowY:"auto", borderRadius:"8px", border:`1px solid ${C.border}` }}>
                  <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"11px", fontFamily:"'Barlow',sans-serif" }}>
                    <thead>
                      <tr style={{ background:C.card, position:"sticky", top:0 }}>
                        {["Job ID","Tech","Date","Revenue","Invoice"].map(h => (
                          <th key={h} style={{ padding:"6px 10px", textAlign:"left", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", whiteSpace:"nowrap", borderBottom:`1px solid ${C.border}` }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {repairRevResult.jobs.map((row, i) => (
                        <tr key={row.jobId+"|"+row.tech} style={{ background: i%2===0 ? C.cardLt : C.card }}>
                          <td style={{ padding:"5px 10px", color:C.muted, whiteSpace:"nowrap" }}>{row.jobId}</td>
                          <td style={{ padding:"5px 10px", color:C.black, whiteSpace:"nowrap" }}>{row.tech}</td>
                          <td style={{ padding:"5px 10px", color:C.muted, whiteSpace:"nowrap" }}>{row.date}</td>
                          <td style={{ padding:"5px 10px", color:C.green, fontWeight:"700", whiteSpace:"nowrap" }}>${row.revenue.toFixed(2)}</td>
                          <td style={{ padding:"5px 10px", color: row.invoiceFound ? C.green : C.muted, whiteSpace:"nowrap" }}>{row.invoiceFound ? "✓" : "fallback"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      )}

    </div>
  );
}

// ─── PAYROLL TAB ──────────────────────────────────────────────────────────────
function PayrollTab({ techs, jobs, tipEntries=[] }) {
  const allPeriods = getPayPeriods();
  const activePeriods = allPeriods.filter(p=>jobs.some(j=>j.job_date>=p.start&&j.job_date<=p.end)||p.key===currentPPKey());
  const [selKey, setSelKey] = useState(currentPPKey());
  const period = allPeriods.find(p=>p.key===selKey) || allPeriods[0];
  if (!period) return null;

  const periodJobs = jobs.filter(j=>j.job_date>=period.start&&j.job_date<=period.end);
  const wkKeys = [...new Set(periodJobs.map(j=>j.week_key))].filter(Boolean).sort();

  const rows = techs.map(t=>{
    const tj      = periodJobs.filter(j=>j.tech_id===t.id);
    const revenue = tj.reduce((s,j)=>s+(j.revenue||0),0);
    const tips    = tipsRangeTotal(tipEntries, t.id, period.start, period.end);
    const rate    = t.commission_rate||27;
    const commission = revenue*(rate/100);
    const total   = commission+tips;
    const weeks   = wkKeys.map(wk=>{
      const wj=tj.filter(j=>j.week_key===wk);
      const wkEndDate = new Date(wk+"T12:00:00Z"); wkEndDate.setUTCDate(wkEndDate.getUTCDate()+6);
      const wkEndStr = wkEndDate.toISOString().split("T")[0];
      const wkTips = tipsRangeTotal(tipEntries, t.id, wk, wkEndStr);
      return { wk, rev:wj.reduce((s,j)=>s+(j.revenue||0),0), tips:wkTips, count:wj.length };
    }).filter(w=>w.rev>0||w.tips>0);
    return { ...t, revenue, tips, rate, commission, total, weeks };
  }).filter(r=>r.revenue>0||r.tips>0).sort((a,b)=>b.total-a.total);

  const teamTotal = rows.reduce((s,r)=>s+r.total,0);

  function exportCSV() {
    const lines=["Tech,Revenue,Commission Rate,Commission,Tips,Total Pay",...rows.map(r=>[r.name,`$${r.revenue.toFixed(2)}`,`${r.rate}%`,`$${r.commission.toFixed(2)}`,`$${r.tips.toFixed(2)}`,`$${r.total.toFixed(2)}`].join(","))].join("\n");
    const url=URL.createObjectURL(new Blob([lines],{type:"text/csv"}));
    const a=Object.assign(document.createElement("a"),{href:url,download:`skylo-payroll-${selKey}.csv`});
    a.click(); URL.revokeObjectURL(url);
  }

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>

      {/* Period selector */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.green}`, borderRadius:"12px", padding:"16px 18px" }}>
        <Label color={C.green}>💵 Pay Period</Label>
        <select value={selKey} onChange={e=>setSelKey(e.target.value)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", width:"100%", cursor:"pointer", marginBottom:"12px" }}>
          {activePeriods.map(p=>(
            <option key={p.key} value={p.key}>{fmtShortDate(p.start)} – {fmtShortDate(p.end)}{p.key===currentPPKey()?" — Current":""}</option>
          ))}
        </select>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"8px" }}>
          {[
            { l:"Pay Period",  v:`${fmtShortDate(period.start)} – ${fmtShortDate(period.end)}` },
            { l:"Submit By",   v:fmtShortDate(period.submit) },
            { l:"Pay Date",    v:fmtShortDate(period.payout) },
          ].map(s=>(
            <div key={s.l} style={{ background:C.cardLt, borderRadius:"8px", padding:"8px 10px", textAlign:"center" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:C.black }}>{s.v}</div>
              <div style={{ fontSize:"9px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase", marginTop:"2px" }}>{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Team total */}
      <div style={{ background:`${C.green}15`, border:`2px solid ${C.green}44`, borderRadius:"12px", padding:"16px 20px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"13px", color:C.green, letterSpacing:"2px" }}>TEAM TOTAL</div>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"34px", color:C.black }}>${teamTotal.toFixed(2)}</div>
      </div>

      {rows.length===0?(
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"32px", textAlign:"center", color:C.muted, fontSize:"13px" }}>
          No jobs synced for this pay period yet. HCP sync runs every 5 min.
        </div>
      ):(
        <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
          {rows.map(r=>(
            <div key={r.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px 18px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"12px" }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"20px", color:C.black }}>{r.name}{r.is_active===false&&<ArchivedTag/>}</div>
                <div style={{ textAlign:"right" }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"28px", color:C.green, lineHeight:1 }}>${r.total.toFixed(2)}</div>
                  <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>TOTAL PAY</div>
                </div>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"8px", marginBottom:r.weeks.length>1?"10px":0 }}>
                {[
                  { l:"Revenue",                v:`$${Math.round(r.revenue).toLocaleString()}`, c:C.blue  },
                  { l:`Commission (${r.rate}%)`, v:`$${r.commission.toFixed(2)}`,                c:C.green },
                  { l:"Tips",                   v:`$${r.tips.toFixed(2)}`,                      c:C.gold  },
                ].map(item=>(
                  <div key={item.l} style={{ background:C.cardLt, borderRadius:"8px", padding:"10px 12px" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"18px", color:item.c }}>{item.v}</div>
                    <div style={{ fontSize:"10px", color:C.muted, marginTop:"3px" }}>{item.l}</div>
                  </div>
                ))}
              </div>
              {r.weeks.length>1&&(
                <div style={{ borderTop:`1px solid ${C.border}`, paddingTop:"10px" }}>
                  <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase", marginBottom:"6px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>Week Breakdown</div>
                  <div style={{ display:"flex", flexDirection:"column", gap:"4px" }}>
                    {r.weeks.map(w=>(
                      <div key={w.wk} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", background:C.cardLt, borderRadius:"6px", padding:"6px 10px" }}>
                        <div style={{ fontSize:"12px", color:C.muted, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{formatWeekLabel(w.wk)} · {w.count} job{w.count!==1?"s":""}</div>
                        <div style={{ display:"flex", gap:"10px", alignItems:"center" }}>
                          <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:C.blue }}>${Math.round(w.rev).toLocaleString()}</span>
                          {w.tips>0&&<span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", color:C.gold }}>+${w.tips.toFixed(0)} tips</span>}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <button onClick={exportCSV} style={{ background:C.blue, border:"none", color:C.white, padding:"13px", borderRadius:"12px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", letterSpacing:"2px", textTransform:"uppercase" }}>
        📥 Export CSV — {fmtShortDate(period.start)} to {fmtShortDate(period.end)}
      </button>
    </div>
  );
}

// ─── LEADERBOARD ─────────────────────────────────────────────────────────────
function Leaderboard({ techs, jobs, upsells, reviews, callbacks, switchovers, timeEntries=[] }) {
  const METRICS = [
    { id:"revenue",  label:"Revenue",    icon:"💰" },
    { id:"upsells",  label:"Upsells",    icon:"📈" },
    { id:"revhr",    label:"Rev / Hr",   icon:"⚡" },
    { id:"reviews",  label:"Reviews",    icon:"⭐" },
    { id:"pts",      label:"Pts",        icon:"🏆" },
  ];
  const [metric, setMetric] = useState("revenue");

  const wk = getWeekKey();
  const rows = techs.map(t => {
    const tj      = jobs.filter(j=>j.tech_id===t.id&&j.week_key===wk);
    const revenue = tj.reduce((s,j)=>s+(j.revenue||0),0);
    const wkEnd   = new Date(wk+"T12:00:00Z"); wkEnd.setUTCDate(wkEnd.getUTCDate()+6);
    const hours   = rangeHoursTotal(timeEntries, t.id, wk, wkEnd.toISOString().split("T")[0]);
    const wkUps   = upsellAmountInRange(jobs, t.id, wk, weekEndDate(wk));
    const mk      = getMonthKey();
    const mRevs   = reviews.filter(r=>r.tech_id===t.id&&r.month_key===mk).reduce((s,r)=>s+r.count,0);
    const tt      = calcTotals(t,upsells,switchovers,reviews,callbacks||[],jobs);
    return { ...t, revenue, hours, revhr:hours>0?revenue/hours:0, wkUps, mRevs, pts:tt.total };
  });

  const sorted = [...rows].sort((a,b) => {
    if (metric==="revenue") return b.revenue-a.revenue;
    if (metric==="upsells") return b.wkUps-a.wkUps;
    if (metric==="revhr")   return b.revhr-a.revhr;
    if (metric==="reviews") return b.mRevs-a.mRevs;
    return b.pts-a.pts;
  });

  const getValue = r => {
    if (metric==="revenue") return `$${Math.round(r.revenue).toLocaleString()}`;
    if (metric==="upsells") return `$${Math.round(r.wkUps).toLocaleString()}`;
    if (metric==="revhr")   return `$${r.revhr.toFixed(0)}/hr`;
    if (metric==="reviews") return r.mRevs;
    return r.pts.toLocaleString()+" pts";
  };
  const getLabel = r => {
    if (metric==="revenue") return "this week";
    if (metric==="upsells") return "this week";
    if (metric==="revhr")   return "this week";
    if (metric==="reviews") return "this month";
    return "all time";
  };

  const medals = ["🥇","🥈","🥉"];
  const colors = [C.gold, C.muted, "#cd7f32"];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      {/* Metric toggle */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", padding:"14px 16px" }}>
        <Label color={C.gold}>🏆 Leaderboard</Label>
        <div style={{ display:"flex", gap:"6px", flexWrap:"wrap" }}>
          {METRICS.map(m=>(
            <button key={m.id} onClick={()=>setMetric(m.id)} style={{ background:metric===m.id?C.gold:C.cardLt, border:`1px solid ${metric===m.id?C.gold:C.border}`, color:metric===m.id?C.white:C.muted, padding:"6px 14px", borderRadius:"20px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", letterSpacing:"1px" }}>
              {m.icon} {m.label}
            </button>
          ))}
        </div>
      </div>

      {sorted.length===0?(
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"32px", textAlign:"center", color:C.muted, fontSize:"13px" }}>
          No data yet for this period. Check back after jobs sync from HCP.
        </div>
      ):(
        <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
          {sorted.map((r,i)=>(
            <div key={r.id} style={{ background:C.card, border:`1px solid ${i<3?colors[i]+"55":C.border}`, borderLeft:`4px solid ${i<3?colors[i]:C.border}`, borderRadius:"12px", padding:"14px 16px", display:"flex", alignItems:"center", gap:"14px" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", width:"32px", textAlign:"center", color:i<3?colors[i]:C.muted }}>
                {i<3?medals[i]:i+1}
              </div>
              <div style={{ width:"40px", height:"40px", borderRadius:"50%", background:i<3?`${colors[i]}22`:`${C.blue}15`, border:`2px solid ${i<3?colors[i]:C.border}`, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"13px", fontWeight:"900", color:i<3?colors[i]:C.blue, flexShrink:0 }}>{r.avatar}</div>
              <div style={{ flex:1 }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"17px", color:C.black }}>{r.name}</div>
                <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>{getLabel(r)}</div>
              </div>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:i<3?colors[i]:C.black }}>{getValue(r)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── JOURNEY BOARD ────────────────────────────────────────────────────────────
function JourneyBoard({ techs, upsells, switchovers, reviews, quota, callbacks, jobs=[] }) {
  const [selected, setSelected] = useState(null);
  const mk = getMonthKey();
  const ranked = [...techs].map(t=>{
    const tt=calcTotals(t,upsells,switchovers,reviews,callbacks||[],jobs);
    const tier=getTier(tt.total);
    const nextTier=JOURNEY_TIERS.find(t2=>t2.minPts>tt.total);
    const ptsToNext=nextTier?nextTier.minPts-tt.total:0;
    const tierPct=nextTier?Math.round(((tt.total-tier.minPts)/(nextTier.minPts-tier.minPts))*100):100;
    const totalReviews=reviews.filter(r=>r.tech_id===t.id).reduce((s,r)=>s+r.count,0);
    const totalSwitches=switchovers.filter(s=>s.tech_id===t.id).length;
    // This month's actuals
    const monthUpsellAmt = (() => {
      const now = new Date(); const y = now.getFullYear(); const m = String(now.getMonth()+1).padStart(2,"0");
      const { start, end } = monthBounds(y, m);
      return upsellAmountInRange(jobs, t.id, start, end);
    })();
    const monthReviewCount = reviews.filter(r=>r.tech_id===t.id && r.month_key===mk).reduce((s,r)=>s+r.count,0);
    const monthSwitchCount = switchovers.filter(s=>s.tech_id===t.id && s.week_key && (() => { const now=new Date(); const y=now.getFullYear(); const m=String(now.getMonth()+1).padStart(2,"0"); return s.week_key.startsWith(`${y}-${m}`); })()).length;
    return {...t,...tt,tier,nextTier,ptsToNext,tierPct,totalReviews,totalSwitches,monthUpsellAmt,monthReviewCount,monthSwitchCount};
  }).sort((a,b)=>b.total-a.total);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"20px" }}>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))", gap:"12px" }}>
        {ranked.map((t,idx)=>(
          <JourneyCard key={t.id} tech={t} rank={idx+1} total={ranked.length} upsells={upsells} jobs={jobs}
            quota={quota||DEFAULT_QUOTA}
            onClick={()=>setSelected(selected===t.id?null:t.id)} expanded={selected===t.id}/>
        ))}
      </div>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px 18px" }}>
        <Label>Arena Tiers</Label>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))", gap:"8px" }}>
          {JOURNEY_TIERS.map(tier=>(
            <div key={tier.id} style={{ background:tier.bg, border:`1px solid ${tier.color}33`, borderLeft:`3px solid ${tier.color}`, borderRadius:"12px", padding:"12px" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:tier.color, letterSpacing:"2px" }}>{tier.icon} {tier.name}</div>
              <div style={{ fontSize:"10px", color:C.muted, fontFamily:"'Barlow Condensed',sans-serif", marginBottom:"4px" }}>
                {tier.maxPts===Infinity?`${tier.minPts.toLocaleString()}+ pts`:`${tier.minPts.toLocaleString()} – ${tier.maxPts.toLocaleString()} pts`}
              </div>
              <div style={{ fontSize:"11px", color:tier.color, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>🎁 {tier.reward}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function JourneyCard({ tech, rank, total, onClick, expanded, upsells, quota, jobs=[] }) {
  const tier = tech.tier;
  const tenure = formatTenure(tech.start_date);
  const earnedBadges = ALL_BADGE_DEFS.filter(b=>tech.badges?.includes(b.id));
  const q = quota || DEFAULT_QUOTA;

  // Current week pay breakdown
  const wk = getWeekKey();
  const weekUpsellAmt = upsellAmountInRange(jobs, tech.id, wk, weekEndDate(wk));
  const { totalPay, breakdown } = calcWeeklyPay(weekUpsellAmt);
  const nextPayTier = getNextPayTier(weekUpsellAmt);

  // Month quota tracking
  const upPct     = Math.min(Math.round((tech.monthUpsellAmt / q.upsells) * 100), 100);
  const revPct    = Math.min(Math.round((tech.monthReviewCount / q.reviews) * 100), 100);
  const swPct     = Math.min(Math.round((tech.monthSwitchCount / q.switchovers) * 100), 100);
  const upHit     = tech.monthUpsellAmt >= q.upsells;
  const revHit    = tech.monthReviewCount >= q.reviews;
  const swHit     = tech.monthSwitchCount >= q.switchovers;
  const allHit    = upHit && revHit && swHit;
  const hitsCount = [upHit, revHit, swHit].filter(Boolean).length;

  return (
    <div onClick={onClick} style={{ background:C.white, border:`2px solid ${allHit ? "#00c853" : tier.color}44`, borderTop:`3px solid ${allHit ? "#00c853" : tier.color}`, borderRadius:"12px", cursor:"pointer", overflow:"hidden", boxShadow:"0 2px 10px rgba(43,156,240,0.08)" }}>
      <div style={{ padding:"16px 18px" }}>
        <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", marginBottom:"14px" }}>
          <div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"22px", color:C.black, lineHeight:1 }}>{tech.name}</div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"13px", color:tier.color, letterSpacing:"2px", marginTop:"3px" }}>{tier.icon} {tier.name} ARENA</div>
            {tenure&&<div style={{ fontSize:"10px", color:C.muted, marginTop:"3px" }}>⏱ {tenure} with Skylo</div>}
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"30px", color:C.blue, lineHeight:1 }}>{tech.total.toLocaleString()}</div>
            <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>PTS</div>
            <div style={{ fontSize:"10px", color:tier.color, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginTop:"2px" }}>#{rank} of {total}</div>
          </div>
        </div>

        {/* ── MONTHLY QUOTA TRACKER ── */}
        <div style={{ background:allHit?`${C.green}12`:`${C.blue}08`, border:`1px solid ${allHit?C.green:C.border}`, borderRadius:"10px", padding:"12px 14px", marginBottom:"14px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"10px" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"12px", color:allHit?C.green:C.black, letterSpacing:"2px", textTransform:"uppercase" }}>
              {allHit ? "✅ QUOTA HIT THIS MONTH" : `📊 MONTHLY QUOTA — ${hitsCount}/3`}
            </div>
            <div style={{ fontSize:"10px", color:C.muted }}>{formatMonthLabel(getMonthKey())}</div>
          </div>
          {[
            { label:"Upsells",     actual:`$${tech.monthUpsellAmt}`,       target:`$${q.upsells}`,  pct:upPct,  hit:upHit,  color:C.green  },
            { label:"Reviews",     actual:tech.monthReviewCount,            target:q.reviews,        pct:revPct, hit:revHit, color:C.gold   },
            { label:"Switchovers", actual:tech.monthSwitchCount,            target:q.switchovers,    pct:swPct,  hit:swHit,  color:C.blue   },
          ].map(row=>(
            <div key={row.label} style={{ marginBottom:"8px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"3px" }}>
                <span style={{ fontSize:"11px", color:C.muted, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{row.label}</span>
                <span style={{ fontSize:"11px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", color:row.hit?C.green:C.black }}>
                  {row.actual} <span style={{ color:C.muted, fontWeight:"600" }}>/ {row.target}</span>
                  {row.hit && <span style={{ color:C.green, marginLeft:"4px" }}>✓</span>}
                </span>
              </div>
              <div style={{ background:C.border, borderRadius:"4px", height:"5px", overflow:"hidden" }}>
                <div style={{ width:`${row.pct}%`, height:"100%", background:row.hit?C.green:row.color, borderRadius:"4px", transition:"width 0.3s" }}/>
              </div>
            </div>
          ))}
        </div>

        {tech.nextTier?(
          <div style={{ background:`${tier.color}12`, border:`1px solid ${tier.color}44`, borderRadius:"10px", padding:"12px 14px", marginBottom:"14px" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"8px" }}>
              <div>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"13px", color:tier.color, letterSpacing:"1px" }}>🎯 WORKING TOWARD</div>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:C.black, lineHeight:1, marginTop:"2px" }}>{tech.nextTier.reward}</div>
              </div>
              <div style={{ textAlign:"right", flexShrink:0 }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:tier.color, lineHeight:1 }}>{tech.ptsToNext.toLocaleString()}</div>
                <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>PTS TO GO</div>
              </div>
            </div>
            <Bar pct={tech.tierPct} color={tier.color} h={7}/>
            <div style={{ fontSize:"10px", color:C.muted, marginTop:"5px" }}>{tech.tierPct}% of the way there · {tech.total.toLocaleString()} / {tech.nextTier.minPts.toLocaleString()} pts</div>
          </div>
        ):(
          <div style={{ marginBottom:"14px", background:`${tier.color}18`, border:`1px solid ${tier.color}44`, borderRadius:"8px", padding:"8px 12px", textAlign:"center" }}>
            <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:tier.color, letterSpacing:"2px" }}>💎 PLATINUM STATUS ACHIEVED</span>
          </div>
        )}
        <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:"6px" }}>
          {[
            {l:"Badges",   v:tech.badges?.length||0,        c:C.purple},
            {l:"Upsells",  v:`$${Math.round(tech.upsellAmt).toLocaleString()}`, c:C.green},
            {l:"Switchovers", v:tech.totalSwitches,        c:C.blue},
            {l:"Reviews",  v:tech.totalReviews,         c:C.gold},
          ].map(s=>(
            <div key={s.l} style={{ background:C.cardLt, borderRadius:"8px", padding:"8px 4px", textAlign:"center" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:s.c }}>{s.v}</div>
              <div style={{ fontSize:"9px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase" }}>{s.l}</div>
            </div>
          ))}
        </div>
        {expanded&&(
          <div style={{ borderTop:`1px solid ${C.border}`, paddingTop:"14px", marginTop:"14px", display:"flex", flexDirection:"column", gap:"12px" }}>
            
            {/* 💵 Weekly Pay Scale */}
            <div style={{ background:C.cardLt, borderRadius:"12px", padding:"12px 14px", border:`1px solid ${C.green}44` }}>
              <div style={{ fontSize:"10px", color:C.green, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", marginBottom:"10px" }}>💵 This Week's Pay Scale</div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"baseline", marginBottom:"10px" }}>
                <span style={{ fontSize:"12px", color:C.muted }}>Week upsells</span>
                <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:C.black }}>${weekUpsellAmt.toLocaleString()}</span>
              </div>
              {/* Pay scale — backfill display */}
              <div style={{ display:"flex", flexDirection:"column", gap:"4px", marginBottom:"8px" }}>
                {(()=>{
                  const { rate } = calcWeeklyPay(weekUpsellAmt);
                  const currentPct = Math.round(rate*100);
                  return [
                    { floor:0,   ceil:150,      baseRate:15, label:"$1–$149"    },
                    { floor:150, ceil:400,       baseRate:20, label:"$150–$399" },
                    { floor:400, ceil:700,       baseRate:25, label:"$400–$699" },
                    { floor:700, ceil:Infinity,  baseRate:30, label:"$700+"      },
                  ].map(b=>{
                    const isCurrent    = weekUpsellAmt >= b.floor && (b.ceil===Infinity ? true : weekUpsellAmt < b.ceil);
                    const isPast       = b.ceil !== Infinity && weekUpsellAmt >= b.ceil;
                    const isLocked     = weekUpsellAmt < b.floor;
                    const backfilled   = isPast && currentPct > b.baseRate;
                    const displayRate  = isLocked ? b.baseRate : currentPct;
                    return (
                      <div key={b.label} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", background:isCurrent?`${C.green}22`:isPast?`${C.green}08`:"transparent", border:isCurrent?`1px solid ${C.green}55`:"1px solid transparent", borderRadius:"6px", padding:"6px 10px" }}>
                        <div style={{ display:"flex", alignItems:"center", gap:"6px" }}>
                          <span style={{ fontSize:"11px", color:isCurrent?C.green:isPast?C.black:C.muted, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:isCurrent?"900":"600" }}>{b.label}</span>
                          {isCurrent && <span style={{ fontSize:"9px", background:C.green, color:C.white, borderRadius:"8px", padding:"1px 7px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900" }}>YOUR TIER</span>}
                          {backfilled && <span style={{ fontSize:"9px", background:`${C.green}22`, color:C.green, borderRadius:"8px", padding:"1px 7px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800" }}>↑ BACKFILLED</span>}
                        </div>
                        <div style={{ display:"flex", alignItems:"center", gap:"5px" }}>
                          {backfilled && <span style={{ fontSize:"10px", color:C.muted, textDecoration:"line-through", fontFamily:"'Barlow Condensed',sans-serif" }}>{b.baseRate}%</span>}
                          <span style={{ fontSize:"13px", color:isLocked?C.muted:C.green, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900" }}>{displayRate}%</span>
                        </div>
                      </div>
                    );
                  });
                })()}
              </div>
              <div style={{ borderTop:`1px solid ${C.green}33`, paddingTop:"8px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontSize:"12px", color:C.muted }}>Est. upsell bonus <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", color:C.black }}>({Math.round(calcWeeklyPay(weekUpsellAmt).rate*100)}% × ${weekUpsellAmt})</span></span>
                <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:C.green }}>${totalPay.toFixed(2)}</span>
              </div>
              {nextPayTier&&(
                <div style={{ marginTop:"8px", background:nextPayTier.amt===null?`${C.green}18`:`${C.gold}18`, border:`1px solid ${nextPayTier.amt===null?C.green:C.gold}44`, borderRadius:"8px", padding:"6px 10px", fontSize:"11px", color:nextPayTier.amt===null?C.green:C.gold, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>
                  {nextPayTier.amt===null
                    ? `🔥 ${nextPayTier.label}`
                    : `💡 Upsell $${nextPayTier.amt.toFixed(0)} more to unlock ${nextPayTier.label}`}
                </div>
              )}
            </div>

            <div>
              <Label color={tier.color}>Points Breakdown</Label>
              {[
                {l:"Badge Points",      v:tech.badgePts,   c:C.purple},
                {l:"Upsell Points",     v:tech.upsellPts,  c:C.green},
                {l:"Switchover Points", v:tech.switchPts,  c:C.blue},
                {l:"Review Points",     v:tech.reviewPts,  c:C.gold},
              ].map(item=>(
                <div key={item.l} style={{ display:"flex", justifyContent:"space-between", marginBottom:"6px" }}>
                  <span style={{ fontSize:"12px", color:C.muted }}>{item.l}</span>
                  <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:item.c }}>{item.v.toLocaleString()}</span>
                </div>
              ))}
            </div>
            {tech.start_date&&(
              <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px 12px", display:"flex", justifyContent:"space-between" }}>
                <span style={{ fontSize:"12px", color:C.muted }}>Started</span>
                <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"13px", color:C.black }}>{new Date(tech.start_date+"T00:00:00").toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})} · {tenure}</span>
              </div>
            )}
            {earnedBadges.length>0&&(
              <div>
                <Label color={tier.color}>Badges</Label>
                <div style={{ display:"flex", flexWrap:"wrap", gap:"5px" }}>
                  {earnedBadges.map(b=>(
                    <span key={b.id} style={{ background:`${tier.color}18`, border:`1px solid ${tier.color}44`, borderRadius:"6px", padding:"3px 10px", fontSize:"11px", color:C.black, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{b.icon} {b.name}</span>
                  ))}
                </div>
              </div>
            )}
            <div>
              <Label color={tier.color}>Current Perks</Label>
              {tier.perks.map((p,i)=>(
                <div key={i} style={{ fontSize:"12px", color:C.black, display:"flex", alignItems:"center", gap:"6px", marginBottom:"4px" }}>
                  <span style={{ color:tier.color, fontWeight:"900" }}>✓</span>{p}
                </div>
              ))}
            </div>
          </div>
        )}
        <div style={{ textAlign:"center", marginTop:"12px", fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>
          {expanded?"▲ COLLAPSE":"▼ EXPAND"}
        </div>
      </div>
    </div>
  );
}


// ─── KYLE BONUS + QUOTA SETTINGS ─────────────────────────────────────────────
function QuotaSettings({ quota, onSave, saving }) {
  const [form, setForm] = useState({ ...quota });
  const inp = { background:C.white, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"8px", fontSize:"16px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", width:"100%", boxSizing:"border-box" };
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"14px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
        <Label color={C.blue}>📋 Monthly Quota Targets</Label>
        <div style={{ fontSize:"13px", color:C.muted }}>Set the baseline expectation for each tech per month. These show up on every Journey card so techs always know what they're working toward.</div>
        {[
          { key:"upsells",     label:"Upsell Target",      icon:"💰", suffix:"$ / month",  desc:"Minimum upsell revenue expected per tech" },
          { key:"reviews",     label:"Review Target",       icon:"⭐", suffix:"reviews / month", desc:"Minimum Google reviews expected" },
          { key:"switchovers", label:"Switchover Target",   icon:"🔄", suffix:"switchovers / month", desc:"Minimum service plan conversions expected" },
        ].map(f=>(
          <div key={f.key}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"6px" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:C.black }}>{f.icon} {f.label}</div>
              <div style={{ fontSize:"11px", color:C.muted }}>{f.desc}</div>
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
              <input type="number" value={form[f.key]} min={0}
                onChange={e=>setForm(v=>({...v,[f.key]:Number(e.target.value)}))}
                style={inp}/>
              <span style={{ fontSize:"12px", color:C.muted, whiteSpace:"nowrap", fontFamily:"'Barlow Condensed',sans-serif" }}>{f.suffix}</span>
            </div>
          </div>
        ))}
        <button disabled={saving} onClick={()=>onSave(form)}
          style={{ background:saving?C.border:C.blue, border:"none", color:C.white, padding:"13px", borderRadius:"24px", cursor:saving?"not-allowed":"pointer", fontSize:"14px", fontWeight:"900", fontStyle:"italic", letterSpacing:"2px", fontFamily:"'Barlow Condensed',sans-serif", textTransform:"uppercase" }}>
          {saving?"Saving...":"Save Quota Targets"}
        </button>
      </div>
      <div style={{ background:`${C.blue}10`, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px 18px" }}>
        <Label color={C.blue}>💡 Operations Bonus Rule</Label>
        <div style={{ fontSize:"13px", color:C.black, marginBottom:"6px" }}>When <strong>{Math.round(OPS_BONUS_THRESHOLD*100)}% or more of active techs hit all 3 quotas</strong> in a month, Will earns <strong style={{ color:C.green }}>5% of the total team upsell revenue</strong> for that month.</div>
        <div style={{ fontSize:"12px", color:C.muted }}>The more the team upsells, the more Will earns — no cap. He's incentivized to coach everyone to their max, not just hit a threshold.</div>
      </div>
    </div>
  );
}

function OperationsProgressTab({ techs, upsells, switchovers, reviews, quota, callbacks=[], jobs=[], timeEntries=[], rideAlongs=[] }) {
  const mk = getMonthKey();
  const q = quota || DEFAULT_QUOTA;

  // Archived techs shouldn't count toward the quota-hit denominator or appear
  // in the breakdown below — they're not working, so including them made the
  // team's hit rate look worse than it actually is among current techs.
  // Owner/admin accounts (title:"owner", e.g. Truxton/Casey) are tracked for
  // revenue completeness elsewhere but were never meant to count toward the
  // tech bonus-threshold quota -- they'd quietly inflate the denominator.
  const activeTechs = techs.filter(t => t.is_active !== false && t.title !== "owner");
  const techStats = activeTechs.map(t => {
    const now = new Date(); const y = now.getFullYear(); const m = String(now.getMonth()+1).padStart(2,"0");
    const { start: mStart, end: mEnd } = monthBounds(y, m);
    const monthUpsellAmt   = upsellAmountInRange(jobs, t.id, mStart, mEnd);
    const monthReviewCount = reviews.filter(r=>r.tech_id===t.id && r.month_key===mk).reduce((s,r)=>s+r.count,0);
    const monthSwitchCount = switchovers.filter(s=>s.tech_id===t.id && s.week_key?.startsWith(`${y}-${m}`)).length;
    const upHit  = monthUpsellAmt   >= q.upsells;
    const revHit = monthReviewCount >= q.reviews;
    const swHit  = monthSwitchCount >= q.switchovers;
    const allHit = upHit && revHit && swHit;
    return { ...t, monthUpsellAmt, monthReviewCount, monthSwitchCount, upHit, revHit, swHit, allHit, hitsCount:[upHit,revHit,swHit].filter(Boolean).length };
  });

  const hittingCount  = techStats.filter(t=>t.allHit).length;
  const totalTechs    = activeTechs.length;
  const hitRate       = totalTechs > 0 ? hittingCount / totalTechs : 0;
  const bonusHit      = hitRate >= OPS_BONUS_THRESHOLD;
  const pctDisplay    = Math.round(hitRate * 100);
  const neededForBonus = Math.ceil(OPS_BONUS_THRESHOLD * totalTechs);

  // Total team upsell revenue this month
  const now2 = new Date(); const y2 = now2.getFullYear(); const mo2 = String(now2.getMonth()+1).padStart(2,"0");
  const { start: teamMStart, end: teamMEnd } = monthBounds(y2, mo2);
  const monthTeamUpsells = upsellAmountInRange(jobs, null, teamMStart, teamMEnd);
  const bonusAmt = Math.round(monthTeamUpsells * OPS_BONUS_PCT * 100) / 100;

  function mtWeekKeyFromDate(dateStr) {
    const d = new Date(dateStr + "T12:00:00Z");
    const day = d.getUTCDay();
    const back = day === 0 ? 6 : day - 1;
    d.setUTCDate(d.getUTCDate() - back);
    return d.toISOString().split("T")[0];
  }

  // KPI 1 — ride-alongs completed this week. A row in ride_alongs IS the
  // completion record (no separate status field) — confirmed no "completed"
  // boolean exists anywhere in the schema.
  const RIDE_ALONG_WEEKLY_TARGET = 4;
  const thisWeekKey = getWeekKey();
  const rideAlongsThisWeek = rideAlongs.filter(r => r.date && mtWeekKeyFromDate(r.date) === thisWeekKey).length;
  const rideAlongHit = rideAlongsThisWeek >= RIDE_ALONG_WEEKLY_TARGET;

  // KPI 2 — check-in completion + on-time rate. checkins isn't in the global
  // loadAll() state (same as DevelopmentTab, which fetches it locally too),
  // so this tab fetches its own copy. NOTE: milestones are week 1/2/4/6/12 in
  // the actual schema, not week 1/2/4/8/12 — there's no "week_8" anywhere.
  // "Tote/truck audits" are NOT a separate tracked entity — confirmed no such
  // table/field exists; only these tech check-ins are real data.
  const [checkins, setCheckins] = useState([]);
  const [checkinsLoaded, setCheckinsLoaded] = useState(false);
  useEffect(() => {
    sb("checkins?select=*").then(rows => { setCheckins(rows||[]); setCheckinsLoaded(true); }).catch(()=>setCheckinsLoaded(true));
  }, []);
  const todayStr = new Date().toISOString().split("T")[0];
  const dueCheckins = checkins.filter(c => c.scheduled_date && c.scheduled_date <= todayStr);
  const completedCheckins = dueCheckins.filter(c => c.status === "completed");
  const onTimeCheckins = completedCheckins.filter(c => c.completed_date && c.completed_date <= c.scheduled_date);
  const checkinCompletionRate = dueCheckins.length > 0 ? (completedCheckins.length / dueCheckins.length) * 100 : null;
  const checkinOnTimeRate = completedCheckins.length > 0 ? (onTimeCheckins.length / completedCheckins.length) * 100 : null;

  // KPI 3 — audit calibration accuracy. No supervisor re-audit/spot-check
  // data source exists anywhere in the codebase — this is a manual-entry
  // number stored in the settings table, same pattern as the quota JSON blob,
  // until a real calibration data source gets built.
  const [calibration, setCalibration] = useState(null);
  const [calibrationInput, setCalibrationInput] = useState("");
  const [calibrationSaving, setCalibrationSaving] = useState(false);
  useEffect(() => {
    sb("settings?key=eq.calibration_accuracy&select=*").then(rows => {
      if (rows && rows[0]) { try { const v = JSON.parse(rows[0].value); setCalibration(v); setCalibrationInput(String(v.pct)); } catch {} }
    }).catch(()=>{});
  }, []);
  async function saveCalibration() {
    const pct = parseFloat(calibrationInput);
    if (isNaN(pct)) return;
    setCalibrationSaving(true);
    try {
      const value = JSON.stringify({ pct, updatedAt: new Date().toISOString().split("T")[0] });
      const existing = await sb("settings?key=eq.calibration_accuracy&select=id").catch(()=>[]);
      if (existing && existing.length > 0) await sb(`settings?id=eq.${existing[0].id}`, { method:"PATCH", body: JSON.stringify({ value }), prefer:"return=minimal" });
      else await sb("settings", { method:"POST", body: JSON.stringify({ key:"calibration_accuracy", value }) });
      setCalibration({ pct, updatedAt: new Date().toISOString().split("T")[0] });
    } catch {}
    setCalibrationSaving(false);
  }

  // KPIs 5-8 — team-wide rates for the current month, reusing the same
  // revenue/hours/upsell computations ReportsTab already does at team level.
  const monthJobs = jobs.filter(j => j.job_date && j.job_date.startsWith(`${y2}-${mo2}`));
  const monthTeamRevenue = monthJobs.reduce((s,j)=>s+(j.revenue||0),0);
  const teamUpsellRate = monthTeamRevenue > 0 ? (monthTeamUpsells / monthTeamRevenue) * 100 : 0;

  const monthTeamReviews = reviews.filter(r => r.month_key === mk).reduce((s,r)=>s+(r.count||0),0);
  const reviewQuotaTarget = q.reviews * totalTechs;
  const teamReviewRate = reviewQuotaTarget > 0 ? (monthTeamReviews / reviewQuotaTarget) * 100 : 0;

  const monthTeamSwitchovers = switchovers.filter(s => s.week_key?.startsWith(`${y2}-${mo2}`)).length;

  // KPI #8 — Rev/Hr. Real clock in/out data (time_entries), not the old
  // manually-typed weekly tech_hours numbers. Scoped to the same active,
  // non-owner tech population as the bonus threshold above -- Truxton/Casey
  // occasionally clocking a job in shouldn't skew the team's Rev/Hr either.
  const activeTechIds = new Set(activeTechs.map(t=>t.id));
  const monthTeamHours = timeEntries.filter(e => activeTechIds.has(e.tech_id) && e.work_date.startsWith(`${y2}-${mo2}`)).reduce((s,e)=>s+sessionHours(e),0);
  const teamRevPerHr = monthTeamHours > 0 ? monthTeamRevenue / monthTeamHours : 0;

  // Callback rate has no job-level linkage (callbacks only carry tech_id +
  // reason + created_at), so this is jobs-in-period vs callbacks-in-period,
  // not a true per-job attribution — the best available with real data.
  const monthCallbacks = callbacks.filter(c => c.created_at && c.created_at.startsWith(`${y2}-${mo2}`)).length;
  const callbackRate = monthJobs.length > 0 ? (monthCallbacks / monthJobs.length) * 100 : 0;

  // 8-week trend — no charting library exists in this app (package.json has
  // only react/react-dom), so this is a lightweight CSS bar trend rather than
  // pulling in a new dependency.
  const last8WeekKeys = [];
  { const base = new Date(); for (let i=7;i>=0;i--) { const wd=new Date(base); wd.setDate(base.getDate()-i*7); last8WeekKeys.push(mtWeekKeyFromDate(wd.toISOString().split("T")[0])); } }
  const trendWeeks = [...new Set(last8WeekKeys)].map(wk => {
    const wkJobs = jobs.filter(j=>j.week_key===wk);
    const wkRev  = wkJobs.reduce((s,j)=>s+(j.revenue||0),0);
    const wkEnd  = new Date(wk+"T12:00:00Z"); wkEnd.setUTCDate(wkEnd.getUTCDate()+6);
    const wkHrs  = timeEntries.filter(e=>activeTechIds.has(e.tech_id) && e.work_date>=wk && e.work_date<=wkEnd.toISOString().split("T")[0]).reduce((s,e)=>s+sessionHours(e),0);
    const wkCallbacks = callbacks.filter(c => c.created_at && mtWeekKeyFromDate(c.created_at.split("T")[0]) === wk).length;
    return { wk, revPerHr: wkHrs>0?wkRev/wkHrs:0, callbackRate: wkJobs.length>0?(wkCallbacks/wkJobs.length)*100:0 };
  });
  const maxRevPerHr = Math.max(1, ...trendWeeks.map(w=>w.revPerHr));
  const maxCallbackRate = Math.max(1, ...trendWeeks.map(w=>w.callbackRate));

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      {/* Will's bonus status */}
      <div style={{ background:bonusHit?`${C.green}15`:C.white, border:`2px solid ${bonusHit?C.green:C.border}`, borderTop:`3px solid ${bonusHit?C.green:C.blue}`, borderRadius:"12px", padding:"20px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"13px", color:bonusHit?C.green:C.muted, letterSpacing:"2px", textTransform:"uppercase", marginBottom:"6px" }}>
          {bonusHit ? "🎉 BONUS UNLOCKED" : "⏳ BONUS IN PROGRESS"}
        </div>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"36px", color:bonusHit?C.green:C.black, lineHeight:1, marginBottom:"4px" }}>
          {bonusHit ? `$${bonusAmt.toFixed(2)} EARNED` : `$${bonusAmt.toFixed(2)} PROJECTED`}
        </div>
        <div style={{ fontSize:"12px", color:C.muted, marginBottom:"4px" }}>
          5% of ${monthTeamUpsells.toLocaleString()} team upsells this month
        </div>
        <div style={{ fontSize:"13px", color:C.muted, marginBottom:"16px" }}>
          {bonusHit
            ? `${hittingCount} of ${totalTechs} techs hit all quotas — great coaching, Will.`
            : `${hittingCount} of ${totalTechs} techs on quota. Need ${neededForBonus - hittingCount} more to unlock.`}
        </div>
        <div style={{ marginBottom:"8px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"4px" }}>
            <span style={{ fontSize:"11px", color:C.muted, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>TEAM QUOTA RATE</span>
            <span style={{ fontSize:"11px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", color:bonusHit?C.green:C.black }}>{pctDisplay}% <span style={{ color:C.muted }}>/</span> {Math.round(OPS_BONUS_THRESHOLD*100)}% needed</span>
          </div>
          <div style={{ background:C.border, borderRadius:"6px", height:"10px", overflow:"hidden" }}>
            <div style={{ width:`${Math.min(pctDisplay,100)}%`, height:"100%", background:bonusHit?C.green:C.blue, borderRadius:"6px" }}/>
          </div>
          <div style={{ display:"flex", justifyContent:"flex-end", marginTop:"3px" }}>
            <div style={{ width:`${OPS_BONUS_THRESHOLD*100}%`, borderRight:`2px dashed ${C.muted}`, height:"6px", marginTop:"-3px" }}/>
          </div>
        </div>
        <div style={{ background:C.cardLt, border:`1px solid ${C.border}`, borderRadius:"8px", padding:"10px 12px", marginTop:"12px" }}>
          <div style={{ display:"flex", justifyContent:"space-between", fontSize:"12px", color:C.muted, marginBottom:"4px" }}>
            <span>Team upsells this month</span>
            <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", color:C.black }}>${monthTeamUpsells.toLocaleString()}</span>
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", fontSize:"12px", color:C.muted, marginBottom:"4px" }}>
            <span>Will's rate</span>
            <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", color:C.black }}>{Math.round(OPS_BONUS_PCT*100)}%</span>
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", fontSize:"13px", borderTop:`1px solid ${C.border}`, paddingTop:"6px", marginTop:"4px" }}>
            <span style={{ fontWeight:"700", color:C.black }}>Will's bonus</span>
            <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:bonusHit?C.green:C.muted }}>${bonusAmt.toFixed(2)} {!bonusHit&&"(locked)"}</span>
          </div>
        </div>
        <div style={{ fontSize:"11px", color:C.muted, marginTop:"10px" }}>Month: {formatMonthLabel(mk)} · Unlocks when {Math.round(OPS_BONUS_THRESHOLD*100)}% of active techs hit all 3 quotas</div>
      </div>

      {/* Per-tech quota breakdown */}
      <div style={{ background:C.white, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
          <Label color={C.blue}>📊 This Month's Quota Status — {formatMonthLabel(mk)}</Label>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"8px", marginTop:"4px" }}>
            {[
              { label:"Upsell Quota",      val:`$${q.upsells}/mo`,    color:C.green },
              { label:"Review Quota",      val:`${q.reviews}/mo`,     color:C.gold  },
              { label:"Switchover Quota",  val:`${q.switchovers}/mo`, color:C.blue  },
            ].map(item=>(
              <div key={item.label} style={{ background:C.white, border:`1px solid ${C.border}`, borderRadius:"8px", padding:"8px 10px", textAlign:"center" }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:item.color }}>{item.val}</div>
                <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>{item.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"10px" }}>
          {techStats.map(t=>(
            <div key={t.id} style={{ background:t.allHit?`${C.green}10`:C.cardLt, border:`1px solid ${t.allHit?C.green:C.border}`, borderRadius:"10px", padding:"12px 14px" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"8px" }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"16px", color:C.black }}>{t.name}</div>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:t.allHit?C.green:C.muted }}>
                  {t.allHit ? "✅ ALL HIT" : `${t.hitsCount}/3`}
                </div>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"6px" }}>
                {[
                  { label:"Upsells",    val:`$${t.monthUpsellAmt}`,  target:`$${q.upsells}`,  hit:t.upHit,  color:C.green },
                  { label:"Reviews",    val:t.monthReviewCount,       target:q.reviews,         hit:t.revHit, color:C.gold  },
                  { label:"Switchovers",   val:t.monthSwitchCount,       target:q.switchovers,     hit:t.swHit,  color:C.blue  },
                ].map(col=>(
                  <div key={col.label} style={{ background:col.hit?`${col.color}15`:C.white, border:`1px solid ${col.hit?col.color:C.border}`, borderRadius:"6px", padding:"6px 8px", textAlign:"center" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"15px", color:col.hit?col.color:C.black }}>{col.val}{col.hit?" ✓":""}</div>
                    <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>{col.label} / {col.target}</div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* KPI 1: Ride-Alongs This Week */}
      <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${rideAlongHit?C.green:C.orange}`, borderRadius:"12px", padding:"18px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
        <Label color={rideAlongHit?C.green:C.orange}>🚗 Ride-Alongs This Week</Label>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"32px", color:rideAlongHit?C.green:C.black }}>{rideAlongsThisWeek} <span style={{ fontSize:"16px", color:C.muted }}>/ {RIDE_ALONG_WEEKLY_TARGET} target</span></div>
          <div style={{ fontSize:"24px" }}>{rideAlongHit?"✅":"⚠️"}</div>
        </div>
        <div style={{ fontSize:"11px", color:C.muted, marginTop:"4px" }}>Week of {formatWeekLabel(thisWeekKey)}</div>
      </div>

      {/* KPI 2: Check-In Completion & On-Time Rate */}
      <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", padding:"18px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
        <Label color={C.blue}>📋 Check-In Completion Rate</Label>
        <div style={{ fontSize:"11px", color:C.muted, marginBottom:"10px" }}>Week 1/2/4/6/12 tech check-ins (the actual milestones tracked — there's no week 8). Tote/truck audits aren't a separate tracked data source yet.</div>
        {!checkinsLoaded ? (
          <div style={{ fontSize:"12px", color:C.muted }}>Loading…</div>
        ) : dueCheckins.length===0 ? (
          <div style={{ fontSize:"12px", color:C.muted }}>No check-ins due yet.</div>
        ) : (
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"10px" }}>
            <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px", textAlign:"center" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:C.black }}>{checkinCompletionRate.toFixed(0)}%</div>
              <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>Completed ({completedCheckins.length}/{dueCheckins.length} due)</div>
            </div>
            <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px", textAlign:"center" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:C.black }}>{checkinOnTimeRate===null?"—":checkinOnTimeRate.toFixed(0)+"%"}</div>
              <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>On-Time ({onTimeCheckins.length}/{completedCheckins.length} completed)</div>
            </div>
          </div>
        )}
      </div>

      {/* KPI 3: Audit Calibration Accuracy — manual entry, no automated source exists */}
      <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.purple}`, borderRadius:"12px", padding:"18px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
        <Label color={C.purple}>🎯 Audit Calibration Accuracy</Label>
        <div style={{ fontSize:"11px", color:C.muted, marginBottom:"10px" }}>Manual entry — no supervisor re-audit/spot-check data source exists yet. Enter the latest calibration % here until that's built.</div>
        <div style={{ display:"flex", gap:"8px", alignItems:"center" }}>
          <input type="number" min="0" max="100" value={calibrationInput} onChange={e=>setCalibrationInput(e.target.value)}
            style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"8px 10px", borderRadius:"8px", fontSize:"14px", width:"100px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}/>
          <span style={{ fontSize:"12px", color:C.muted }}>%</span>
          <button onClick={saveCalibration} disabled={calibrationSaving} style={{ background:calibrationSaving?"#333":C.purple, border:"none", color:C.white, padding:"8px 16px", borderRadius:"8px", cursor:calibrationSaving?"not-allowed":"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px" }}>
            {calibrationSaving?"Saving...":"Save"}
          </button>
        </div>
        {calibration && <div style={{ fontSize:"11px", color:C.muted, marginTop:"8px" }}>Last recorded: {calibration.pct}% on {calibration.updatedAt}</div>}
      </div>

      {/* KPI 4: Team Churn Rate — flagged as not computable, no fabricated number */}
      <div style={{ background:"#fff8e6", border:"1px solid #f59e0b44", borderTop:"3px solid #f59e0b", borderRadius:"12px", padding:"18px" }}>
        <Label color="#f59e0b">📉 Team Churn Rate — Not Available Yet</Label>
        <div style={{ fontSize:"12px", color:C.black }}>Archiving a tech only flips a status flag today — there's no timestamp recorded for when someone actually left, and hire date isn't reliably filled in for every tech. A trustworthy churn rate needs both before this can show a real number.</div>
      </div>

      {/* KPIs 5-7: Team Upsell Rate / Review Rate / Switchover Total */}
      <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.green}`, borderRadius:"12px", padding:"18px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
        <Label color={C.green}>📈 Team Rates — {formatMonthLabel(mk)}</Label>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"10px" }}>
          <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px", textAlign:"center" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:C.green }}>{teamUpsellRate.toFixed(1)}%</div>
            <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>Upsell Rate</div>
          </div>
          <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px", textAlign:"center" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:C.gold }}>{teamReviewRate.toFixed(0)}%</div>
            <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>Review Rate ({monthTeamReviews}/{reviewQuotaTarget})</div>
          </div>
          <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px", textAlign:"center" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:C.blue }}>{monthTeamSwitchovers}</div>
            <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>Switchovers</div>
          </div>
        </div>
      </div>

      {/* KPI 8: Team Rev/Hr + Callback Rate, with an 8-week trend */}
      <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", padding:"18px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
        <Label color={C.blue}>📊 Rev/Hr & Callback Rate — Last 8 Weeks</Label>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"16px", marginTop:"8px", marginBottom:"14px" }}>
          <div style={{ textAlign:"center" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:C.black }}>${teamRevPerHr.toFixed(2)}/hr</div>
            <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase" }}>This Month</div>
          </div>
          <div style={{ textAlign:"center" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:C.black }}>{callbackRate.toFixed(1)}%</div>
            <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase" }}>Callback Rate ({monthCallbacks}/{monthJobs.length} jobs)</div>
          </div>
        </div>
        <div style={{ fontSize:"10px", color:C.muted, marginBottom:"8px" }}>No job-level link exists on callbacks (only tech_id/reason/date), so this is callbacks-in-period ÷ jobs-in-period, not true per-job attribution.</div>
        <div style={{ display:"flex", flexDirection:"column", gap:"6px" }}>
          {trendWeeks.map(w=>(
            <div key={w.wk} style={{ display:"grid", gridTemplateColumns:"70px 1fr 1fr", gap:"8px", alignItems:"center" }}>
              <div style={{ fontSize:"10px", color:C.muted }}>{formatWeekLabel(w.wk)}</div>
              <div style={{ background:C.border, borderRadius:"4px", height:"14px", position:"relative", overflow:"hidden" }}>
                <div style={{ width:`${(w.revPerHr/maxRevPerHr)*100}%`, height:"100%", background:C.blue, borderRadius:"4px" }}/>
                <div style={{ position:"absolute", top:0, left:"4px", fontSize:"9px", color:C.black, lineHeight:"14px" }}>${w.revPerHr.toFixed(0)}/hr</div>
              </div>
              <div style={{ background:C.border, borderRadius:"4px", height:"14px", position:"relative", overflow:"hidden" }}>
                <div style={{ width:`${(w.callbackRate/maxCallbackRate)*100}%`, height:"100%", background:"#ef4444", borderRadius:"4px" }}/>
                <div style={{ position:"absolute", top:0, left:"4px", fontSize:"9px", color:C.black, lineHeight:"14px" }}>{w.callbackRate.toFixed(0)}%</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ display:"flex", gap:"16px", marginTop:"8px" }}>
          <div style={{ fontSize:"9px", color:C.muted }}>🔵 Rev/hr</div>
          <div style={{ fontSize:"9px", color:C.muted }}>🔴 Callback rate</div>
        </div>
      </div>
    </div>
  );
}

// ─── TEAM LEAD PANEL ─────────────────────────────────────────────────────────
function TeamLeadPanel({ tech, techs, upsells, switchovers, reviews, callbacks, quota, jobs=[] }) {
  const q = quota || DEFAULT_QUOTA;
  const teamMembers = (techs||[]).filter(t=>t.team_lead_id===tech.id);
  const mk = getMonthKey();
  const now = new Date(); const y=now.getFullYear(); const mo=String(now.getMonth()+1).padStart(2,"0");
  const { start: mStart, end: mEnd } = monthBounds(y, mo);

  // Lead's own quota
  const leadUpsells  = upsellAmountInRange(jobs, tech.id, mStart, mEnd);
  const leadReviews  = (reviews||[]).filter(r=>r.tech_id===tech.id&&r.month_key===mk).reduce((s,r)=>s+r.count,0);
  const leadSwitches = (switchovers||[]).filter(s=>s.tech_id===tech.id&&s.week_key?.startsWith(`${y}-${mo}`)).length;
  const leadHitsQuota = leadUpsells>=q.upsells && leadReviews>=q.reviews && leadSwitches>=q.switchovers;

  // Team member stats
  const teamMemberStats = teamMembers.map(m=>{
    const monthUpsellAmt   = upsellAmountInRange(jobs, m.id, mStart, mEnd);
    const monthReviewCount = (reviews||[]).filter(r=>r.tech_id===m.id&&r.month_key===mk).reduce((s,r)=>s+r.count,0);
    const monthSwitchCount = (switchovers||[]).filter(s=>s.tech_id===m.id&&s.week_key?.startsWith(`${y}-${mo}`)).length;
    const upHit=monthUpsellAmt>=q.upsells, revHit=monthReviewCount>=q.reviews, swHit=monthSwitchCount>=q.switchovers;
    const tt = calcTotals(m,upsells||[],switchovers||[],reviews||[],callbacks||[],jobs);
    return { ...m, monthUpsellAmt, monthReviewCount, monthSwitchCount, upHit, revHit, swHit, allHit:upHit&&revHit&&swHit, total:tt.total };
  });

  const hittingCount   = teamMemberStats.filter(m=>m.allHit).length;
  const totalMembers   = teamMembers.length;
  const neededForPartial = Math.ceil(totalMembers * (2/3));
  const allTeamHit     = leadHitsQuota && hittingCount === totalMembers && totalMembers > 0;
  const partialHit     = leadHitsQuota && hittingCount >= neededForPartial && !allTeamHit && totalMembers > 0;
  const teamTotalPts   = teamMemberStats.reduce((s,m)=>s+m.total,0);
  const overridePct    = allTeamHit ? 0.10 : partialHit ? 0.05 : 0;
  const overridePts    = Math.round(teamTotalPts * overridePct);
  const statusColor    = allTeamHit ? C.green : partialHit ? C.gold : C.blue;

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"14px" }}>

      {/* No members yet */}
      {totalMembers===0&&(
        <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", padding:"24px 20px", textAlign:"center", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
          <div style={{ fontSize:"32px", marginBottom:"10px" }}>👥</div>
          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"20px", color:C.black, marginBottom:"6px" }}>No Team Members Yet</div>
          <div style={{ fontSize:"13px", color:C.muted }}>Ask your admin to assign members to your team.</div>
        </div>
      )}

      {/* Override status card */}
      {totalMembers>0&&(
        <div style={{ background:(allTeamHit||partialHit)?`${statusColor}12`:C.white, border:`2px solid ${allTeamHit||partialHit?statusColor:C.border}`, borderTop:`4px solid ${statusColor}`, borderRadius:"16px", padding:"18px 20px", boxShadow:"0 4px 16px rgba(43,156,240,0.10)" }}>
          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"13px", color:statusColor, letterSpacing:"2px", marginBottom:"6px" }}>
            {allTeamHit?"🏆 10% OVERRIDE UNLOCKED":partialHit?"⚡ 5% OVERRIDE UNLOCKED":"⏳ TEAM LEAD OVERRIDE"}
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"14px" }}>
            <div>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"36px", color:overridePts>0?statusColor:C.black, lineHeight:1 }}>
                {overridePts>0?`+${overridePts.toLocaleString()} PTS`:"LOCKED"}
              </div>
              <div style={{ fontSize:"12px", color:C.muted, marginTop:"4px" }}>
                {overridePct>0?`${Math.round(overridePct*100)}% of team's ${teamTotalPts.toLocaleString()} pts`:"Get your team to quota to unlock"}
              </div>
            </div>
            <div style={{ textAlign:"right" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:C.black }}>{hittingCount}/{totalMembers}</div>
              <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>ON QUOTA</div>
            </div>
          </div>

          {/* Conditions */}
          <div style={{ display:"flex", flexDirection:"column", gap:"8px", marginBottom:"12px" }}>
            {[
              { label:"Your own quota hit", hit:leadHitsQuota },
              { label:`${neededForPartial}/${totalMembers} teammates hit quota → 5% override`, hit:hittingCount>=neededForPartial, pts:Math.round(teamTotalPts*0.05) },
              { label:`All ${totalMembers}/${totalMembers} teammates hit quota → 10% override`, hit:allTeamHit, pts:Math.round(teamTotalPts*0.10) },
            ].map((row,i)=>(
              <div key={i} style={{ display:"flex", alignItems:"center", gap:"8px", background:row.hit?`${C.green}10`:`${C.border}30`, border:`1px solid ${row.hit?C.green:C.border}`, borderRadius:"8px", padding:"8px 12px" }}>
                <span style={{ color:row.hit?C.green:"#ef4444", fontSize:"16px", flexShrink:0 }}>{row.hit?"✓":"✗"}</span>
                <span style={{ fontSize:"12px", color:row.hit?C.black:C.muted, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", flex:1 }}>{row.label}</span>
                {i>0&&<span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"12px", color:row.hit?C.green:C.muted }}>+{row.pts} pts</span>}
              </div>
            ))}
          </div>

          {!leadHitsQuota&&<div style={{ fontSize:"12px", color:C.muted, fontStyle:"italic" }}>Hit your own quota first to unlock any override.</div>}
          {leadHitsQuota&&!partialHit&&totalMembers>0&&<div style={{ fontSize:"12px", color:C.muted, fontStyle:"italic" }}>Get {neededForPartial-hittingCount} more teammate{neededForPartial-hittingCount!==1?"s":""} to quota to unlock 5%.</div>}
          {partialHit&&!allTeamHit&&<div style={{ fontSize:"12px", color:C.gold, fontStyle:"italic", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>5% unlocked! Get {totalMembers-hittingCount} more to quota for the full 10%.</div>}
        </div>
      )}

      {/* Team member cards */}
      {totalMembers>0&&(
        <div style={{ background:C.white, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
          <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"16px", color:C.black }}>👥 {tech.team_name||"Your Team"} — {formatMonthLabel(mk)}</div>
            <div style={{ fontSize:"11px", color:C.muted, marginTop:"2px" }}>Push your guys to hit all 3 before month end</div>
          </div>
          <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"10px" }}>
            {teamMemberStats.map(m=>(
              <div key={m.id} style={{ background:m.allHit?`${C.green}10`:C.cardLt, border:`1px solid ${m.allHit?C.green:C.border}`, borderRadius:"10px", padding:"12px 14px" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"8px" }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"16px", color:C.black }}>{m.name}</div>
                  <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                    <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"12px", color:m.allHit?C.green:C.muted }}>{m.allHit?"✅ ALL HIT":`${[m.upHit,m.revHit,m.swHit].filter(Boolean).length}/3`}</span>
                    <span style={{ fontSize:"11px", color:C.gold, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>+{Math.round(m.total*overridePct)} pts override</span>
                  </div>
                </div>
                <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"6px" }}>
                  {[
                    { label:"Upsells",  val:`$${m.monthUpsellAmt}`, target:`$${q.upsells}`,  hit:m.upHit,  color:C.green },
                    { label:"Reviews",  val:m.monthReviewCount,      target:q.reviews,         hit:m.revHit, color:C.gold  },
                    { label:"Switchovers", val:m.monthSwitchCount,      target:q.switchovers,     hit:m.swHit,  color:C.blue  },
                  ].map(col=>(
                    <div key={col.label} style={{ background:col.hit?`${col.color}15`:C.white, border:`1px solid ${col.hit?col.color:C.border}`, borderRadius:"6px", padding:"6px 8px", textAlign:"center" }}>
                      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:col.hit?col.color:C.black }}>{col.val}{col.hit?" ✓":""}</div>
                      <div style={{ fontSize:"9px", color:C.muted, textTransform:"uppercase", letterSpacing:"1px" }}>{col.label} / {col.target}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}


// ─── INCENTIVE BOARD ─────────────────────────────────────────────────────────
const INCENTIVE_TIERS = [
  {
    pts: 2500,
    prize: "$150",
    color: "#cd7f32",
    icon: "🔥",
    name: "IGNITION",
    tagline: "3–4 months of solid work. You've earned it.",
    items: [
      { name:"Fresh Kicks",              desc:"$150 toward Nike Air Forces, Jordans, or your shoe of choice", img:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=240&fit=crop&auto=format" },
      { name:"Premium Apparel",          desc:"$150 to spend on gear, fits, or streetwear", img:"https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=400&h=240&fit=crop&auto=format" },
      { name:"Lagoon Pass or Adventure", desc:"Day pass to local attraction or adventure experience", img:"https://images.unsplash.com/photo-1504701954957-2010ec3bcec1?w=400&h=240&fit=crop&auto=format" },
      { name:"Cash",                     desc:"$150 straight cash — no questions asked", img:"https://images.unsplash.com/photo-1554672408-730436b60dde?w=400&h=240&fit=crop&auto=format" },
      { name:"Gift Cards",               desc:"$150 in gift cards to the stores you actually shop at", img:"https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?w=400&h=240&fit=crop&auto=format" },
    ],
  },
  {
    pts: 4500,
    prize: "$300",
    color: "#a8c0d6",
    icon: "⚡",
    name: "VOLTAGE",
    tagline: "6–7 months in. The team is noticing.",
    items: [
      { name:"Ray-Bans or Designer Shades", desc:"Premium sunglasses — Tom Ford, Oakley, Ray-Ban", img:"https://images.unsplash.com/photo-1473496169904-658ba7574b0d?w=400&h=240&fit=crop&auto=format" },
      { name:"Designer Cologne",           desc:"Tom Ford, Chanel, or your signature scent — up to $300", img:"https://images.unsplash.com/photo-1541643600914-78b084683702?w=400&h=240&fit=crop&auto=format" },
      { name:"Cash",                        desc:"$300 straight cash — spend it how you want", img:"https://images.unsplash.com/photo-1554672408-730436b60dde?w=400&h=240&fit=crop&auto=format" },
      { name:"Xbox or Gaming Bundle",       desc:"New Xbox or $300 gaming store credit", img:"https://images.unsplash.com/photo-1605979257913-1704eb7b6246?w=400&h=240&fit=crop&auto=format" },
      { name:"Hotel Weekend",               desc:"2-night hotel stay anywhere in-state with your person", img:"https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=400&h=240&fit=crop&auto=format" },
    ],
  },
  {
    pts: 6000,
    prize: "$600",
    color: "#ffd600",
    icon: "🏆",
    name: "OVERDRIVE",
    tagline: "9 months of excellence. Elite territory.",
    items: [
      { name:"Insta360 X5 Camera",         desc:"The sickest action cam — full kit", img:"https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=240&fit=crop&auto=format" },
      { name:"Apple Watch",                 desc:"Latest Apple Watch — your pick of model", img:"https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=400&h=240&fit=crop&auto=format" },
      { name:"Flights + Trip",              desc:"Domestic flights + hotel — pick your destination", img:"https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=400&h=240&fit=crop&auto=format" },
      { name:"Car Parts Fund",              desc:"$600 toward wheels, tires, suspension, or your build", img:"https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=240&fit=crop&auto=format" },
      { name:"Cash",                        desc:"$600 in your pocket — no strings attached", img:"https://images.unsplash.com/photo-1554672408-730436b60dde?w=400&h=240&fit=crop&auto=format" },
    ],
  },
  {
    pts: 8000,
    prize: "$1,200",
    color: "#c4b5fd",
    icon: "👑",
    name: "LEGEND",
    tagline: "A full year of being the best. One of one.",
    items: [
      { name:"All-Inclusive Resort",        desc:"Cancun, Dominican Republic, or your pick — you + a guest", img:"https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=400&h=240&fit=crop&auto=format" },
      { name:"S&P 500 / Roth IRA Contribution", desc:"$1,200 invested directly into your future — stocks or retirement", img:"https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=240&fit=crop&auto=format" },
      { name:"Performance Car Build",       desc:"$1,200 no-questions-asked contribution to your car build", img:"https://images.unsplash.com/photo-1544636331-e26879cd4d9b?w=400&h=240&fit=crop&auto=format" },
      { name:"VIP Concert + Hotel",         desc:"Floor seats to a major show + hotel night for you and a +1", img:"https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=400&h=240&fit=crop&auto=format" },
      { name:"Paid Time Off Bonus",         desc:"Take time off + $1,200 spending money — you earned it", img:"https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=400&h=240&fit=crop&auto=format" },
    ],
  },
];

function IncentiveBoard({ techs, upsells, switchovers, reviews, callbacks, currentId, jobs=[] }) {
  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", padding:"16px 18px" }}>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"28px", color:C.black, letterSpacing:"2px", marginBottom:"4px" }}>SKYLO REWARDS PROGRAM</div>
        <div style={{ fontSize:"13px", color:C.muted, marginBottom:"8px" }}>Stack your points from upsells, switchovers, reviews, and badges. Hit a tier, claim your Skylo Cash — then your points reset and the grind starts again.</div>
        <div style={{ background:`${C.blue}12`, border:`1px solid ${C.border}`, borderRadius:"8px", padding:"10px 14px", fontSize:"12px", color:C.muted, display:"flex", gap:"6px", alignItems:"flex-start" }}>
          <span style={{ color:C.blue, fontSize:"14px" }}>ℹ️</span>
          <span><strong style={{ color:C.black }}>How it works:</strong> Every $2 upselled = 1 pt. Reviews are 5 pts each (+20 bonus at 10/mo). Switchovers are 15–120 pts by plan. Hit 2,500 pts ($150) · 4,500 pts ($300) · 6,000 pts ($600) · 8,000 pts ($1,200) — then points reset and you climb again.</span>
        </div>
        <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:"8px", marginTop:"14px" }}>
          {[
            {l:"Upsells",    v:"$2 = 1 pt",        c:C.green},
            {l:"Reviews",    v:"5 pts each",        c:C.gold},
            {l:"Switchovers",v:"15–120 pts",        c:C.purple},
            {l:"Badges",     v:"40–1,000 pts",      c:C.blue},
          ].map(item=>(
            <div key={item.l} style={{ background:C.cardLt, borderRadius:"4px", padding:"8px 12px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <span style={{ fontSize:"12px", color:C.muted }}>{item.l}</span>
              <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:item.c }}>{item.v}</span>
            </div>
          ))}
        </div>
      </div>

      {INCENTIVE_TIERS.map((tier, ti) => {
        const myTotal = currentId ? (() => {
          const tech = techs?.find(t=>t.id===currentId);
          if (!tech) return 0;
          return calcTotals(tech, upsells, switchovers, reviews, callbacks, jobs).total;
        })() : null;
        const unlocked = myTotal !== null && myTotal >= tier.pts;
        const progress = myTotal !== null ? Math.min(Math.round((myTotal / tier.pts) * 100), 100) : null;
        const prevPts = ti === 0 ? 0 : INCENTIVE_TIERS[ti-1].pts;
        const tierProgress = myTotal !== null ? Math.min(Math.round(((myTotal - prevPts) / (tier.pts - prevPts)) * 100), 100) : null;

        return (
          <div key={tier.name} style={{ background:C.card, border:`1px solid ${unlocked ? tier.color+"66" : C.border}`, borderTop:`4px solid ${tier.color}`, borderRadius:"12px", overflow:"hidden", opacity: unlocked || myTotal === null ? 1 : 0.85 }}>
            <div style={{ padding:"16px 18px", borderBottom:`1px solid ${C.border}`, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
              <div>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"28px", color:tier.color, letterSpacing:"3px", lineHeight:1 }}>{tier.icon} {tier.name}</div>
                <div style={{ fontSize:"12px", color:C.muted, marginTop:"3px" }}>{tier.tagline}</div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"38px", color:C.black, lineHeight:1 }}>{tier.prize}</div>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:"12px", color:tier.color, fontWeight:"700", letterSpacing:"1px" }}>{tier.pts.toLocaleString()} PTS REQUIRED</div>
              </div>
            </div>

            {myTotal !== null && (
              <div style={{ padding:"12px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
                {unlocked ? (
                  <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:tier.color, letterSpacing:"2px" }}>✅ UNLOCKED — SEE ADMIN TO CLAIM</div>
                  </div>
                ) : (
                  <div>
                    <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"6px" }}>
                      <span style={{ fontSize:"11px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase" }}>Progress</span>
                      <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"12px", color:tier.color }}>{(tier.pts - myTotal).toLocaleString()} pts away</span>
                    </div>
                    <div style={{ background:C.border, borderRadius:"2px", height:"6px", overflow:"hidden" }}>
                      <div style={{ width:`${Math.max(tierProgress||0,0)}%`, height:"100%", background:tier.color, borderRadius:"2px" }}/>
                    </div>
                    <div style={{ fontSize:"10px", color:C.muted, marginTop:"4px" }}>{Math.max(tierProgress||0,0)}% of the way there</div>
                  </div>
                )}
              </div>
            )}

            <div style={{ padding:"14px 18px" }}>
              <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginBottom:"12px" }}>Choose Your Reward</div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(150px,1fr))", gap:"10px" }}>
                {tier.items.map(item=>(
                  <div key={item.name} style={{ background:C.cardLt, borderRadius:"12px", overflow:"hidden", border:`1px solid ${C.border}` }}>
                    <img src={item.img} alt={item.name} style={{ width:"100%", height:"110px", objectFit:"cover", display:"block" }} loading="lazy"/>
                    <div style={{ padding:"10px" }}>
                      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"13px", color:C.black, lineHeight:"1.2", marginBottom:"3px" }}>{item.name}</div>
                      <div style={{ fontSize:"10px", color:C.muted, lineHeight:"1.3" }}>{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── TIME SHEET (tech-facing) ─────────────────────────────────────────────────
function TimeSheetTab({ tech, timeEntries, refreshAll, showToast, nowTick }) {
  const myEntries = timeEntries.filter(e => e.tech_id === tech.id);
  const today = mtDateStr(nowTick);
  const openEntry = myEntries.find(e => !e.clock_out);
  const isClockedInToday = !!openEntry && openEntry.work_date === today;
  const [saving, setSaving] = useState(false);
  const [editDate, setEditDate] = useState(today);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ in:"", out:"" });

  // Lazy auto-close: any of THIS tech's own sessions still open from a past
  // date get closed at that day's midnight the moment they load this tab.
  // Nothing else depends on this having already run -- sessionHours() caps a
  // past-date open session at midnight regardless -- this just persists the
  // auto_closed flag so it's visible next time they check.
  useEffect(() => {
    const stale = myEntries.filter(e => !e.clock_out && e.work_date < today);
    if (stale.length === 0) return;
    (async () => {
      for (const e of stale) {
        await sb(`time_entries?id=eq.${e.id}`, { method:"PATCH", body:JSON.stringify({ clock_out: mtDayEndUTC(e.work_date), auto_closed:true }), prefer:"return=minimal" }).catch(()=>{});
      }
      await refreshAll();
    })();
    // eslint-disable-next-line
  }, [myEntries.map(e=>e.id+(e.clock_out||"")).join(","), today]);

  async function clockIn() {
    setSaving(true);
    try {
      await sb("time_entries", { method:"POST", body:JSON.stringify({ tech_id:tech.id, work_date:today, clock_in:new Date().toISOString() }) });
      await refreshAll();
      showToast("✅ Clocked in!");
    } catch(e) { showToast("Error: "+e.message, false); }
    setSaving(false);
  }
  async function clockOut() {
    if (!openEntry) return;
    setSaving(true);
    try {
      await sb(`time_entries?id=eq.${openEntry.id}`, { method:"PATCH", body:JSON.stringify({ clock_out:new Date().toISOString() }), prefer:"return=minimal" });
      await refreshAll();
      showToast("✅ Clocked out!");
    } catch(e) { showToast("Error: "+e.message, false); }
    setSaving(false);
  }

  const todayTotal = dayHoursTotal(myEntries, tech.id, today, nowTick);
  const autoClosedDays = [...new Set(myEntries.filter(e=>e.auto_closed).map(e=>e.work_date))].sort((a,b)=>b.localeCompare(a));

  const recentDays = Array.from({length:14}, (_,i) => {
    const d = new Date(today+"T12:00:00Z"); d.setUTCDate(d.getUTCDate()-i);
    return d.toISOString().split("T")[0];
  });

  const editEntries = myEntries.filter(e => e.work_date === editDate).sort((a,b)=>a.clock_in.localeCompare(b.clock_in));

  function startEdit(e) {
    setEditingId(e.id);
    setEditForm({ in: isoToMtTimeInput(e.clock_in), out: e.clock_out ? isoToMtTimeInput(e.clock_out) : "" });
  }
  async function saveEdit() {
    if (!editForm.in) return showToast("Clock-in time required", false);
    setSaving(true);
    try {
      const body = { clock_in: mtTimeToIso(editDate, editForm.in), clock_out: editForm.out ? mtTimeToIso(editDate, editForm.out) : null, auto_closed:false };
      await sb(`time_entries?id=eq.${editingId}`, { method:"PATCH", body:JSON.stringify(body), prefer:"return=minimal" });
      await refreshAll();
      setEditingId(null);
      showToast("✅ Session updated");
    } catch(e) { showToast("Error: "+e.message, false); }
    setSaving(false);
  }
  async function addSession() {
    setSaving(true);
    try {
      const res = await sb("time_entries", { method:"POST", body:JSON.stringify({ tech_id:tech.id, work_date:editDate, clock_in:mtTimeToIso(editDate,"08:00"), clock_out:mtTimeToIso(editDate,"16:00") }) });
      await refreshAll();
      if (res && res[0]) startEdit(res[0]);
      showToast("✅ Session added — adjust the times below");
    } catch(e) { showToast("Error: "+e.message, false); }
    setSaving(false);
  }
  async function deleteSession(id) {
    if (!window.confirm("Delete this session?")) return;
    setSaving(true);
    try {
      await sb(`time_entries?id=eq.${id}`, { method:"DELETE", prefer:"return=minimal" });
      await refreshAll();
      setEditingId(null);
      showToast("Session deleted");
    } catch(e) { showToast("Error: "+e.message, false); }
    setSaving(false);
  }

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", padding:"16px 18px" }}>
        <Label color={C.blue}>🕒 Time Sheet</Label>
        <div style={{ fontSize:"12px", color:C.muted, marginTop:"6px" }}>Clock in when you walk in the door for the day, and clock out when you arrive back for the day! This entry does not effect your pay in any way shape or form so please enter the correct time</div>
      </div>

      {autoClosedDays.length>0&&(
        <div style={{ background:`${C.gold}18`, border:`1px solid ${C.gold}`, borderRadius:"10px", padding:"12px 16px", fontSize:"12px", color:C.black }}>
          ⚠ {autoClosedDays.length} day{autoClosedDays.length!==1?"s":""} auto-closed at midnight because a clock-out was missed ({autoClosedDays.slice(0,3).map(fmtShortDate).join(", ")}{autoClosedDays.length>3?"...":""}) — fix it below with Edit Time if it's wrong.
        </div>
      )}

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"14px" }}>
        <div style={{ display:"flex", gap:"12px" }}>
          <button onClick={clockIn} disabled={saving||isClockedInToday} style={{ flex:1, background:isClockedInToday?C.border:C.green, border:"none", color:C.white, padding:"16px", borderRadius:"12px", cursor:(saving||isClockedInToday)?"not-allowed":"pointer", fontSize:"14px", fontWeight:"900", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", textTransform:"uppercase" }}>Clock In</button>
          <button onClick={clockOut} disabled={saving||!isClockedInToday} style={{ flex:1, background:!isClockedInToday?C.border:"#ef4444", border:"none", color:C.white, padding:"16px", borderRadius:"12px", cursor:(saving||!isClockedInToday)?"not-allowed":"pointer", fontSize:"14px", fontWeight:"900", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", textTransform:"uppercase" }}>Clock Out</button>
        </div>
        <div style={{ textAlign:"center" }}>
          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"32px", color:C.blue }}>{todayTotal.toFixed(2)}h</div>
          <div style={{ fontSize:"11px", color:C.muted, letterSpacing:"1px" }}>{isClockedInToday ? "CLOCKED IN — LIVE TOTAL FOR TODAY" : "TOTAL FOR TODAY"}</div>
        </div>
      </div>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}` }}><Label color={C.blue}>Recent Days</Label></div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"6px" }}>
          {recentDays.map(d => {
            const total = dayHoursTotal(myEntries, tech.id, d, nowTick);
            const isAutoClosed = myEntries.some(e=>e.work_date===d&&e.auto_closed);
            return (
              <div key={d} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"6px 0", borderBottom:`1px solid ${C.border}` }}>
                <span style={{ fontSize:"13px", color:C.black }}>{fmtShortDate(d)}{d===today?" (Today)":""}{isAutoClosed?" ⚠":""}</span>
                <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                  <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"13px", color:total>0?C.black:C.muted }}>{total.toFixed(2)}h</span>
                  <button onClick={()=>{setEditDate(d);setEditingId(null);}} style={{ background:"none", border:`1px solid ${C.border}`, color:C.blue, padding:"3px 8px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"10px" }}>EDIT</button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", padding:"16px 18px", display:"flex", flexDirection:"column", gap:"12px" }}>
        <Label color={C.blue}>Edit a Day</Label>
        <div style={{ fontSize:"11px", color:C.muted }}>Forgot to clock in or out? Pick the date and fix it here — no admin needed.</div>
        <input type="date" value={editDate} onChange={e=>{setEditDate(e.target.value);setEditingId(null);}} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"8px 10px", borderRadius:"8px", fontSize:"13px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box" }}/>
        {editEntries.length===0 && <div style={{ fontSize:"12px", color:C.muted }}>No sessions logged for this day yet.</div>}
        {editEntries.map(e => (
          <div key={e.id} style={{ background:C.cardLt, borderRadius:"8px", padding:"10px 12px" }}>
            {editingId===e.id ? (
              <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"8px" }}>
                  <div>
                    <div style={{ fontSize:"10px", color:C.muted, marginBottom:"4px" }}>Clock In</div>
                    <input type="time" value={editForm.in} onChange={ev=>setEditForm(f=>({...f,in:ev.target.value}))} style={{ background:C.card, border:`1px solid ${C.border}`, color:C.black, padding:"8px", borderRadius:"8px", fontSize:"13px", width:"100%", boxSizing:"border-box" }}/>
                  </div>
                  <div>
                    <div style={{ fontSize:"10px", color:C.muted, marginBottom:"4px" }}>Clock Out</div>
                    <input type="time" value={editForm.out} onChange={ev=>setEditForm(f=>({...f,out:ev.target.value}))} style={{ background:C.card, border:`1px solid ${C.border}`, color:C.black, padding:"8px", borderRadius:"8px", fontSize:"13px", width:"100%", boxSizing:"border-box" }}/>
                  </div>
                </div>
                <div style={{ display:"flex", gap:"8px" }}>
                  <button onClick={saveEdit} disabled={saving} style={{ flex:1, background:C.blue, border:"none", color:C.white, padding:"8px", borderRadius:"8px", cursor:"pointer", fontWeight:"700", fontSize:"12px" }}>Save</button>
                  <button onClick={()=>setEditingId(null)} style={{ background:"none", border:`1px solid ${C.border}`, color:C.muted, padding:"8px 14px", borderRadius:"8px", cursor:"pointer", fontSize:"12px" }}>Cancel</button>
                  <button onClick={()=>deleteSession(e.id)} style={{ background:"none", border:"1px solid #ef4444", color:"#ef4444", padding:"8px 14px", borderRadius:"8px", cursor:"pointer", fontSize:"12px" }}>Delete</button>
                </div>
              </div>
            ) : (
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontSize:"13px", color:C.black }}>
                  {formatMTTime(e.clock_in)} → {e.clock_out ? formatMTTime(e.clock_out) : (e.work_date===today ? "still clocked in" : "—")}
                  {e.auto_closed && <span style={{ color:C.gold }}> ⚠ auto-closed</span>}
                </span>
                <button onClick={()=>startEdit(e)} style={{ background:"none", border:`1px solid ${C.border}`, color:C.blue, padding:"4px 10px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px" }}>Edit Time</button>
              </div>
            )}
          </div>
        ))}
        <button onClick={addSession} disabled={saving} style={{ background:C.cardLt, border:`1px solid ${C.blue}`, color:C.blue, padding:"10px", borderRadius:"8px", cursor:saving?"not-allowed":"pointer", fontWeight:"700", fontSize:"12px" }}>+ Add Session for This Day</button>
      </div>
    </div>
  );
}

// ─── TECH DASHBOARD ───────────────────────────────────────────────────────────
function TechDashboard({ tech, techs, upsells, switchovers, reviews, callbacks, quota, jobs, timeEntries=[], tipEntries=[], refreshAll=async()=>{}, rideAlongs=[], onLogout }) {
  const q = quota || DEFAULT_QUOTA;
  const [tab, setTab] = useState("overview");
  const [menuOpen, setMenuOpen] = useState(false);
  const [toast, setToast] = useState(null);
  const showToast = (msg, ok=true) => { setToast({msg,ok}); setTimeout(()=>setToast(null), 3000); };
  // Ticks while this dashboard is open so an active clock-in's live running
  // total (Time Sheet tab) advances without a manual refresh.
  const [nowTick, setNowTick] = useState(Date.now());
  useEffect(() => { const iv = setInterval(() => setNowTick(Date.now()), 30000); return () => clearInterval(iv); }, []);
  const tt = calcTotals(tech, upsells, switchovers, reviews, callbacks, jobs);
  const tier = getTier(tt.total);
  const nextTier = JOURNEY_TIERS.find(t=>t.minPts>tt.total);
  const allRanked = [...techs].map(t=>({...t,...calcTotals(t,upsells,switchovers,reviews,callbacks||[],jobs)})).sort((a,b)=>b.total-a.total);
  const myPos = allRanked.findIndex(t=>t.id===tech.id)+1;
  const wk=getWeekKey(), mk=getMonthKey();
  const weekUpsell = upsellAmountInRange(jobs, tech.id, wk, weekEndDate(wk));
  const monthReviews = reviews.filter(r=>r.tech_id===tech.id&&r.month_key===mk).reduce((s,r)=>s+r.count,0);
  const tenure = formatTenure(tech.start_date);

  // Month quota actuals
  const now = new Date(); const y = now.getFullYear(); const mo = String(now.getMonth()+1).padStart(2,"0");
  const { start: mStart, end: mEnd } = monthBounds(y, mo);
  const monthUpsellAmt   = upsellAmountInRange(jobs, tech.id, mStart, mEnd);
  const monthSwitchCount = switchovers.filter(s=>s.tech_id===tech.id && s.week_key?.startsWith(`${y}-${mo}`)).length;
  const upHit  = monthUpsellAmt   >= q.upsells;
  const revHit = monthReviews     >= q.reviews;
  const swHit  = monthSwitchCount >= q.switchovers;
  const allQuotaHit = upHit && revHit && swHit;
  const quotaHitCount = [upHit,revHit,swHit].filter(Boolean).length;
  const tenureDays = tech.start_date ? Math.floor((Date.now() - new Date(tech.start_date+"T12:00:00Z")) / 86400000) : 0;
  const myRecentRA = rideAlongs.filter(r=>r.tech_id===tech.id).sort((a,b)=>b.date?.localeCompare(a.date)).slice(0,3);
  const raAvgScore = myRecentRA.length ? myRecentRA.reduce((s,r)=>{ const cl=r.checklist?JSON.parse(r.checklist):{}; const v=Object.values(cl); return s+(v.length?v.filter(x=>x==="✅").length/v.length*100:0); },0)/myRecentRA.length : 0;
  const eligibleForTechII = tenureDays >= 56 && myRecentRA.length >= 3 && raAvgScore >= 85;
  const stageConf = STAGE_CONFIG[tech.onboarding_stage || "active"] || STAGE_CONFIG.active;

  const techNavSections = [
    { label:null, items:[
      ["overview","🏠","Overview"],
      ["timesheet","🕒","Time Sheet"],
      ["reports","📊","My Reports"],
      ["leaderboard","🏆","Leaderboard"],
    ]},
    { label:"Journey", items:[
      ["journey","🗺️","Journey Map"],
      ["total","🎯","Total Score"],
      ["badges","🥇","Badges"],
      ["incentive","🎁","Rewards"],
    ]},
    { label:"My Stats", items:[
      ["upsells","💰","Upsells"],
      ["switchovers","🔄","Switchovers"],
      ["reviews","⭐","Reviews"],
      ...(tech.is_lead?[["myteam","👥","My Team"]]:[]),
    ]},
    { label:"Training", items:[
      ["training","📋","Perfect Day Training"],
    ]},
  ];

  return (
    <div style={{ minHeight:"100vh", background:"#f0f8ff" }}>
      <style>{GS}</style>
      <SideNav sections={techNavSections} active={tab} setActive={setTab} open={menuOpen} onClose={()=>setMenuOpen(false)} name={tech.name} role={`${tier.icon} ${tier.name}`}/>
      <Header left={<HamburgerBtn onClick={()=>setMenuOpen(true)}/>} right={<LogoutBtn onLogout={onLogout}/>}/>
      <div style={{ background:C.white, borderBottom:`1px solid ${C.border}`, padding:"14px 20px 0", boxShadow:"0 2px 12px rgba(43,156,240,0.08)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:"14px", marginBottom:"14px" }}>
          <div style={{ width:"50px", height:"50px", borderRadius:"50%", background:`${C.blue}18`, border:`2px solid ${C.blue}`, display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"16px", fontWeight:"900", color:C.blue, flexShrink:0 }}>{tech.avatar}</div>
          <div style={{ flex:1 }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"24px", color:C.black, lineHeight:1 }}>{tech.name}</div>
            <div style={{ display:"flex", gap:"8px", alignItems:"center", marginTop:"4px", flexWrap:"wrap" }}>
              <Pill color={tier.color}>{tier.icon} {tier.name}</Pill>
              {tenure&&<span style={{ fontSize:"11px", color:C.muted }}>⏱ {tenure}</span>}
              {tech.title && <Pill color={C.purple}>🏷 {TITLE_LABELS[tech.title] || tech.title}</Pill>}
              {tech.onboarding_stage && tech.onboarding_stage !== "active" && <Pill color={stageConf.color}>{stageConf.icon} {stageConf.label}</Pill>}
              {eligibleForTechII && <Pill color={C.gold}>🌟 Tech II Eligible</Pill>}
            </div>
          </div>
          <div style={{ textAlign:"right" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"34px", color:C.blue, lineHeight:1 }}>{tt.total.toLocaleString()}</div>
            <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px" }}>TOTAL PTS</div>
          </div>
        </div>
        {nextTier&&(
          <div style={{ marginBottom:"12px" }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:"5px" }}>
              <span style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>🎯 TOWARD: {nextTier.reward}</span>
              <span style={{ fontSize:"10px", color:tier.color, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{(nextTier.minPts-tt.total).toLocaleString()} PTS TO GO</span>
            </div>
            <Bar pct={Math.round(((tt.total-tier.minPts)/(nextTier.minPts-tier.minPts))*100)} color={tier.color} h={4}/>
          </div>
        )}
      </div>
      <div style={{ padding:"20px", maxWidth:"800px", margin:"0 auto" }}>
        {tab==="overview"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>

            {/* ── MONTHLY QUOTA CARD ── */}
            <div style={{ background:allQuotaHit?`${C.green}12`:C.white, border:`2px solid ${allQuotaHit?C.green:C.border}`, borderTop:`4px solid ${allQuotaHit?C.green:C.blue}`, borderRadius:"16px", padding:"18px 20px", boxShadow:"0 4px 16px rgba(43,156,240,0.10)" }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:"14px" }}>
                <div>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"18px", color:allQuotaHit?C.green:C.black, letterSpacing:"1px" }}>
                    {allQuotaHit ? "✅ QUOTA CRUSHED" : `📊 MONTHLY QUOTA`}
                  </div>
                  <div style={{ fontSize:"11px", color:C.muted, marginTop:"2px" }}>{formatMonthLabel(mk)} · {quotaHitCount}/3 targets hit</div>
                </div>
                <div style={{ background:allQuotaHit?C.green:quotaHitCount>=2?C.gold:quotaHitCount===1?C.orange:"#ef4444", borderRadius:"20px", padding:"4px 12px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:C.white }}>
                  {allQuotaHit?"ON FIRE 🔥":quotaHitCount>=2?"CLOSE":"NEEDS WORK"}
                </div>
              </div>
              <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
                {[
                  { label:"💰 Upsells",     actual:`$${monthUpsellAmt}`,   target:`$${q.upsells}`,    pct:Math.min(Math.round((monthUpsellAmt/q.upsells)*100),100),    hit:upHit,  color:C.green },
                  { label:"⭐ Reviews",      actual:monthReviews,            target:q.reviews,           pct:Math.min(Math.round((monthReviews/q.reviews)*100),100),       hit:revHit, color:C.gold  },
                  { label:"🔄 Switchovers", actual:monthSwitchCount,        target:q.switchovers,       pct:Math.min(Math.round((monthSwitchCount/q.switchovers)*100),100),hit:swHit,  color:C.blue  },
                ].map(row=>(
                  <div key={row.label}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"5px" }}>
                      <span style={{ fontSize:"12px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", color:C.black }}>{row.label}</span>
                      <div style={{ display:"flex", alignItems:"center", gap:"8px" }}>
                        <span style={{ fontSize:"12px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", color:row.hit?row.color:C.black }}>
                          {row.actual} <span style={{ color:C.muted, fontWeight:"600" }}>/ {row.target}</span>
                        </span>
                        {row.hit
                          ? <span style={{ background:row.color, color:C.white, borderRadius:"10px", padding:"1px 8px", fontSize:"10px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900" }}>✓ HIT</span>
                          : <span style={{ background:C.cardLt, color:C.muted, borderRadius:"10px", padding:"1px 8px", fontSize:"10px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{row.pct}%</span>
                        }
                      </div>
                    </div>
                    <div style={{ background:C.border, borderRadius:"6px", height:"7px", overflow:"hidden" }}>
                      <div style={{ width:`${row.pct}%`, height:"100%", background:row.hit?row.color:row.color+"99", borderRadius:"6px", transition:"width 0.4s ease" }}/>
                    </div>
                  </div>
                ))}
              </div>
              {!allQuotaHit&&(
                <div style={{ fontSize:"11px", color:C.muted, fontStyle:"italic", marginTop:"12px" }}>
                  Keep pushing — hit all 3 targets this month 💪
                </div>
              )}
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:"10px" }}>
              <StatBlock label="Total Points" value={tt.total.toLocaleString()} color={C.blue} accent={C.blue}/>
              <StatBlock label="Team Rank" value={`#${myPos} / ${techs.length}`} color={C.green} accent={C.green}/>
              <StatBlock label="Week Upsells" value={`$${weekUpsell.toLocaleString()}`} color={C.green} sub={`All-time $${Math.round(tt.upsellAmt).toLocaleString()}`} accent={C.green}/>
              <StatBlock label="Month Reviews" value={monthReviews} color={C.gold} sub={`All-time ${reviews.filter(r=>r.tech_id===tech.id).reduce((s,r)=>s+r.count,0)}`} accent={C.gold}/>
            </div>

            {/* ── WEEKLY PROJECTION ── */}
            {(()=>{
              const wkJobs = (jobs||[]).filter(j=>j.tech_id===tech.id&&j.week_key===wk);
              const wkRevenue = wkJobs.reduce((s,j)=>s+(j.revenue||0),0);
              const wkEnd = new Date(wk+"T12:00:00Z"); wkEnd.setUTCDate(wkEnd.getUTCDate()+6);
              const wkHours   = rangeHoursTotal(timeEntries, tech.id, wk, wkEnd.toISOString().split("T")[0], nowTick);
              if (wkRevenue===0&&wkHours===0) return null;
              const mt = new Date(Date.now()-6*60*60*1000);
              const day = mt.getDay();
              const daysElapsed = Math.max(day===0?6:day-1, 1);
              const daysInWeek  = 6;
              const projRevenue = Math.round((wkRevenue/daysElapsed)*daysInWeek);
              const projHours   = Math.round((wkHours/daysElapsed)*daysInWeek*10)/10;
              const projMonthly = Math.round(projRevenue*(52/12));
              const { totalPay:projBonus } = calcWeeklyPay(Math.round((weekUpsell/daysElapsed)*daysInWeek));
              return (
                <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.purple}`, borderRadius:"12px", padding:"16px 18px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"12px", color:C.purple, letterSpacing:"2px", marginBottom:"12px" }}>
                    📈 WEEK PROJECTION — {daysElapsed}/{daysInWeek} DAYS IN
                  </div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:"8px" }}>
                    {[
                      { l:"Proj. Revenue",      v:`$${projRevenue.toLocaleString()}`,   c:C.green  },
                      { l:"Proj. Hours",         v:`${projHours}h`,                      c:C.blue   },
                      { l:"Proj. Monthly Rev",   v:`$${projMonthly.toLocaleString()}`,   c:C.purple },
                      { l:"Proj. Upsell Bonus",  v:`$${projBonus.toFixed(2)}`,           c:C.gold   },
                    ].map(s=>(
                      <div key={s.l} style={{ background:C.cardLt, borderRadius:"8px", padding:"10px", textAlign:"center" }}>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"20px", color:s.c }}>{s.v}</div>
                        <div style={{ fontSize:"9px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase" }}>{s.l}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ fontSize:"10px", color:C.muted, marginTop:"8px" }}>Based on {daysElapsed} day{daysElapsed!==1?"s":""} of pace · refreshes every 5 min</div>
                </div>
              );
            })()}

            {/* ── EARNINGS CARD ── */}
            {(()=>{
              const wkJobs    = (jobs||[]).filter(j=>j.tech_id===tech.id&&j.week_key===wk);
              const wkRevenue = wkJobs.reduce((s,j)=>s+(j.revenue||0),0);
              const wkEndDate = new Date(wk+"T12:00:00Z"); wkEndDate.setUTCDate(wkEndDate.getUTCDate()+6);
              const wkTips    = tipsRangeTotal(tipEntries, tech.id, wk, wkEndDate.toISOString().split("T")[0]);
              if (wkRevenue===0&&wkTips===0) return null;
              const rate       = tech.commission_rate||27;
              const commission = wkRevenue*(rate/100);
              const total      = commission+wkTips;
              return (
                <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.green}`, borderRadius:"12px", padding:"16px 18px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"12px", color:C.green, letterSpacing:"2px", marginBottom:"12px" }}>💵 YOUR EARNINGS — THIS WEEK</div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:"8px", marginBottom:"10px" }}>
                    {[
                      { l:"Revenue",             v:`$${wkRevenue.toLocaleString()}`,   c:C.blue  },
                      { l:`Commission (${rate}%)`,v:`$${commission.toFixed(2)}`,        c:C.green },
                      { l:"Tips",                v:`$${wkTips.toFixed(2)}`,            c:C.gold  },
                    ].map(s=>(
                      <div key={s.l} style={{ background:C.cardLt, borderRadius:"8px", padding:"10px", textAlign:"center" }}>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"18px", color:s.c }}>{s.v}</div>
                        <div style={{ fontSize:"9px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase", marginTop:"3px" }}>{s.l}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ background:`${C.green}15`, border:`1px solid ${C.green}44`, borderRadius:"8px", padding:"10px 14px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <div style={{ fontSize:"11px", color:C.green, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", letterSpacing:"1px" }}>TOTAL THIS WEEK</div>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"26px", color:C.black }}>${total.toFixed(2)}</div>
                  </div>
                </div>
              );
            })()}

            {/* Team info — always show if assigned, show unassigned message if not */}
            {(() => {
              const myLead = techs.find(t=>t.id===tech.team_lead_id);
              const myTeam = tech.is_lead
                ? techs.filter(t=>t.team_lead_id===tech.id)
                : techs.filter(t=>t.team_lead_id===tech.team_lead_id&&t.id!==tech.id);
              const teamName = tech.is_lead ? tech.team_name : myLead?.team_name;
              const isOnTeam = tech.team_lead_id || tech.is_lead;

              return (
                <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", padding:"14px 16px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"10px" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"13px", color:C.gold, letterSpacing:"1px" }}>👥 YOUR TEAM</div>
                    {teamName&&<div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"16px", color:C.black }}>{teamName}</div>}
                  </div>

                  {!isOnTeam&&(
                    <div style={{ fontSize:"12px", color:C.muted }}>You haven't been assigned to a team yet — check with your manager.</div>
                  )}

                  {isOnTeam&&(
                    <>
                      {myLead&&(
                        <div style={{ display:"flex", alignItems:"center", gap:"8px", marginBottom:"8px", paddingBottom:"8px", borderBottom:`1px solid ${C.border}` }}>
                          <div style={{ width:"32px", height:"32px", borderRadius:"50%", background:`${C.gold}22`, border:`1px solid ${C.gold}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"11px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", color:C.gold }}>{myLead.avatar}</div>
                          <div>
                            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:C.black }}>{myLead.name}</div>
                            <div style={{ fontSize:"10px", color:C.gold, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", letterSpacing:"1px" }}>TEAM LEAD</div>
                          </div>
                        </div>
                      )}
                      {tech.is_lead&&(
                        <div style={{ fontSize:"11px", color:C.gold, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", marginBottom:"8px", letterSpacing:"1px" }}>👑 YOU ARE THE TEAM LEAD</div>
                      )}
                      <div style={{ display:"flex", flexWrap:"wrap", gap:"6px" }}>
                        {myTeam.map(m=>(
                          <div key={m.id} style={{ background:C.cardLt, border:`1px solid ${C.border}`, borderRadius:"20px", padding:"4px 12px" }}>
                            <span style={{ fontSize:"11px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", color:C.black }}>{m.name}</span>
                          </div>
                        ))}
                        {myTeam.length===0&&<div style={{ fontSize:"12px", color:C.muted }}>No teammates assigned yet</div>}
                      </div>
                    </>
                  )}
                </div>
              );
            })()}
            <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${tier.color}`, borderRadius:"12px", padding:"16px 18px" }}>
              <Label color={tier.color}>Points Breakdown</Label>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:"8px" }}>
                {[
                  {l:"🏅 Badges",    v:tt.badgePts,   c:C.purple},
                  {l:"💰 Upsells",   v:tt.upsellPts,  c:C.green},
                  {l:"🔄 Switchovers",  v:tt.switchPts,  c:C.blue},
                  {l:"⭐ Reviews",   v:tt.reviewPts,  c:C.gold},
                  ...(tt.callbackCount>0?[{l:`📞 Callbacks (${tt.callbackCount})`, v:tt.callbackPts, c:"#ef4444"}]:[]),
                  ...(tech.is_lead?(()=>{ const {overridePts,overridePct,allTeamHit,partialHit}=calcTeamOverride(tech,techs,upsells,switchovers,reviews,callbacks||[],q,jobs); const active=allTeamHit||partialHit; return [{l:`👥 Team Override (${active?Math.round(overridePct*100)+"% unlocked":"locked"})`,v:active?`+${overridePts}`:"—",c:active?C.gold:C.muted}]; })():[]),
                ].map(item=>(
                  <div key={item.l} style={{ background:C.cardLt, borderRadius:"4px", padding:"10px 12px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ fontSize:"12px", color:C.muted }}>{item.l}</span>
                    <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"18px", color:item.c }}>{item.v.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
            {tech.badges.length>0&&(
              <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px 18px" }}>
                <Label>My Badges</Label>
                <div style={{ display:"flex", flexWrap:"wrap", gap:"6px" }}>
                  {ALL_BADGE_DEFS.filter(b=>tech.badges?.includes(b.id)).map(b=>(
                    <div key={b.id} style={{ background:`${C.blue}18`, border:`1px solid ${C.blue}44`, borderRadius:"4px", padding:"6px 10px", display:"flex", alignItems:"center", gap:"6px" }}>
                      <span style={{ fontSize:"16px" }}>{b.icon}</span>
                      <div>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", color:C.black }}>{b.name}</div>
                        <div style={{ fontSize:"10px", color:C.blue, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>+{b.pts} PTS</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
        {tab==="timesheet"&&<TimeSheetTab tech={tech} timeEntries={timeEntries} refreshAll={refreshAll} showToast={showToast} nowTick={nowTick}/>}
        {tab==="reports"&&<ReportsTab techs={techs} jobs={jobs||[]} upsells={upsells||[]} timeEntries={timeEntries} tipEntries={tipEntries} techId={tech.id}/>}
        {tab==="leaderboard"&&<Leaderboard techs={techs} jobs={jobs||[]} upsells={upsells} reviews={reviews} callbacks={callbacks||[]} switchovers={switchovers} timeEntries={timeEntries}/>}
        {tab==="badges"&&<BadgeGrid earned={tech.badges}/>}
        {tab==="upsells"&&<UpsellLeaderboard techs={techs} upsells={upsells} jobs={jobs||[]} currentId={tech.id}/>}
        {tab==="switchovers"&&<SwitchoverLeaderboard techs={techs} switchovers={switchovers} currentId={tech.id}/>}
        {tab==="reviews"&&<ReviewLeaderboard techs={techs} reviews={reviews} currentId={tech.id}/>}
        {tab==="total"&&<TotalLeaderboard techs={techs} upsells={upsells} switchovers={switchovers} reviews={reviews} callbacks={callbacks||[]} jobs={jobs}/>}
        {tab==="journey"&&(
          <div>
            <div style={{ fontSize:"13px", color:C.muted, marginBottom:"16px" }}>Tap any card to expand full breakdown.</div>
            <JourneyBoard techs={techs} upsells={upsells} switchovers={switchovers} reviews={reviews} quota={q} callbacks={callbacks||[]} jobs={jobs}/>
          </div>
        )}
        {tab==="incentive"&&(
          <div>
            <div style={{ fontSize:"13px", color:C.muted, marginBottom:"16px" }}>Your personal progress toward each reward tier.</div>
            <IncentiveBoard techs={techs} upsells={upsells} switchovers={switchovers} reviews={reviews} callbacks={callbacks||[]} currentId={tech.id} jobs={jobs}/>
          </div>
        )}
        {tab==="myteam"&&(
          <TeamLeadPanel tech={tech} techs={techs} upsells={upsells} switchovers={switchovers} reviews={reviews} callbacks={callbacks||[]} quota={q} jobs={jobs}/>
        )}
        {tab==="training"&&<PerfectDayTrainingPanel tech={tech}/>}
      </div>
      {toast&&(
        <div style={{ position:"fixed", bottom:"24px", left:"50%", transform:"translateX(-50%)", background:toast.ok?C.green:"#ef4444", color:C.white, padding:"12px 28px", borderRadius:"24px", fontSize:"14px", fontWeight:"900", zIndex:999, whiteSpace:"nowrap", fontFamily:"'Barlow Condensed',sans-serif", letterSpacing:"1px", fontStyle:"italic", boxShadow:"0 4px 20px rgba(0,0,0,0.15)" }}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}




// ─── DELETE TAB ───────────────────────────────────────────────────────────────
function DeleteTab({ techs, upsells, switchovers, reviews, saving, setSaving, refreshAll, showToast }) {
  const [section, setSection] = useState("upsells");
  const [filterTech, setFilterTech] = useState("");

  const selStyle = { background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"8px 12px", borderRadius:"12px", fontSize:"13px", fontFamily:"'Barlow',sans-serif", width:"100%", cursor:"pointer" };

  async function deleteUpsell(id) {
    if (!window.confirm("Delete this upsell entry?")) return;
    setSaving(true);
    try { await sb(`upsells?id=eq.${id}`,{method:"DELETE",prefer:"return=minimal"}); await refreshAll(); showToast("Upsell deleted"); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function deleteSwitchover(id) {
    if (!window.confirm("Delete this switchover?")) return;
    setSaving(true);
    try { await sb(`switchovers?id=eq.${id}`,{method:"DELETE",prefer:"return=minimal"}); await refreshAll(); showToast("Switchover deleted"); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function deleteReview(id) {
    if (!window.confirm("Delete this review entry?")) return;
    setSaving(true);
    try { await sb(`reviews?id=eq.${id}`,{method:"DELETE",prefer:"return=minimal"}); await refreshAll(); showToast("Review entry deleted"); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }

  const filteredUpsells = upsells.filter(u=>!filterTech||u.tech_id===filterTech).sort((a,b)=>b.week_key?.localeCompare(a.week_key||"")||0);
  const filteredSwitchovers = switchovers.filter(s=>!filterTech||s.tech_id===filterTech).sort((a,b)=>(b.created_at||"").localeCompare(a.created_at||""));
  const filteredReviews = reviews.filter(r=>!filterTech||r.tech_id===filterTech).sort((a,b)=>b.month_key?.localeCompare(a.month_key||"")||0);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
      <div style={{ background:`#ff444418`, border:`1px solid #ff444444`, borderRadius:"12px", padding:"12px 16px", fontSize:"12px", color:C.muted }}>
        <span style={{ color:C.red, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800" }}>⚠️ DELETE ZONE</span> — Deletions are permanent. Use this to remove test data or mistakes.
      </div>

      {/* Section picker */}
      <div style={{ display:"flex", gap:"8px" }}>
        {[["upsells","💰 Upsells"],["switchovers","🔄 Switchovers"],["reviews","⭐ Reviews"]].map(([id,label])=>(
          <button key={id} onClick={()=>setSection(id)} style={{ background:section===id?C.red:C.card, border:`1px solid ${section===id?C.red:C.border}`, color:section===id?C.white:C.muted, padding:"8px 14px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px", letterSpacing:"1px" }}>{label}</button>
        ))}
      </div>

      {/* Filter by tech */}
      <select value={filterTech} onChange={e=>setFilterTech(e.target.value)} style={selStyle}>
        <option value="">All Techs</option>
        {techs.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
      </select>

      {/* UPSELLS */}
      {section==="upsells"&&(
        <div style={{ display:"flex", flexDirection:"column", gap:"6px" }}>
          {filteredUpsells.length===0&&<div style={{ fontSize:"13px", color:C.muted, padding:"12px" }}>No upsell entries found.</div>}
          {filteredUpsells.map(u=>{
            const tech=techs.find(t=>t.id===u.tech_id);
            return (
              <div key={u.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"12px 16px", display:"flex", alignItems:"center", justifyContent:"space-between", gap:"12px" }}>
                <div>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"15px", color:C.black }}>{tech?.name}</div>
                  <div style={{ fontSize:"12px", color:C.muted }}>{formatWeekLabel(u.week_key)} · <span style={{ color:C.green, fontWeight:"700" }}>${u.amount?.toLocaleString()}</span></div>
                </div>
                <button onClick={()=>deleteUpsell(u.id)} disabled={saving} style={{ background:"none", border:`1px solid ${C.red}`, color:C.red, padding:"6px 12px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", letterSpacing:"1px", flexShrink:0 }}>DELETE</button>
              </div>
            );
          })}
        </div>
      )}

      {/* SWITCHOVERS */}
      {section==="switchovers"&&(
        <div style={{ display:"flex", flexDirection:"column", gap:"6px" }}>
          {filteredSwitchovers.length===0&&<div style={{ fontSize:"13px", color:C.muted, padding:"12px" }}>No switchover entries found.</div>}
          {filteredSwitchovers.map(s=>{
            const tech=techs.find(t=>t.id===s.tech_id);
            const plan=PLAN_MAP[s.plan_id];
            const pc=PLAN_COLORS[s.plan_id]||C.muted;
            return (
              <div key={s.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"12px 16px", display:"flex", alignItems:"center", justifyContent:"space-between", gap:"12px" }}>
                <div>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"15px", color:C.black }}>{tech?.name}</div>
                  <div style={{ fontSize:"12px", color:C.muted }}>{formatWeekLabel(s.week_key)} · <span style={{ color:pc, fontWeight:"700" }}>{plan?.label||s.plan_id} · +{plan?.pts||0}pts</span></div>
                </div>
                <button onClick={()=>deleteSwitchover(s.id)} disabled={saving} style={{ background:"none", border:`1px solid ${C.red}`, color:C.red, padding:"6px 12px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", letterSpacing:"1px", flexShrink:0 }}>DELETE</button>
              </div>
            );
          })}
        </div>
      )}

      {/* REVIEWS */}
      {section==="reviews"&&(
        <div style={{ display:"flex", flexDirection:"column", gap:"6px" }}>
          {filteredReviews.length===0&&<div style={{ fontSize:"13px", color:C.muted, padding:"12px" }}>No review entries found.</div>}
          {filteredReviews.map(r=>{
            const tech=techs.find(t=>t.id===r.tech_id);
            return (
              <div key={r.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"12px 16px", display:"flex", alignItems:"center", justifyContent:"space-between", gap:"12px" }}>
                <div>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"15px", color:C.black }}>{tech?.name}</div>
                  <div style={{ fontSize:"12px", color:C.muted }}>{formatMonthLabel(r.month_key)} · <span style={{ color:C.gold, fontWeight:"700" }}>{r.count} ⭐</span></div>
                </div>
                <button onClick={()=>deleteReview(r.id)} disabled={saving} style={{ background:"none", border:`1px solid ${C.red}`, color:C.red, padding:"6px 12px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", letterSpacing:"1px", flexShrink:0 }}>DELETE</button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── ADMIN TIME SHEET ──────────────────────────────────────────────────────────
const MONTH_NAMES = { january:0, jan:0, february:1, feb:1, march:2, mar:2, april:3, apr:3, may:4, june:5, jun:5, july:6, jul:6, august:7, aug:7, september:8, sep:8, sept:8, october:9, oct:9, november:10, nov:10, december:11, dec:11 };
function AdminTimeSheetTab({ techs, timeEntries, refreshAll, showToast }) {
  const [rangePreset, setRangePreset] = useState("wtd");
  const [cStart, setCStart] = useState("");
  const [cEnd, setCEnd] = useState("");
  const { start, end } = getDateRangeBounds(rangePreset, cStart, cEnd);

  // Same active/archived + owner-exclusion pattern used everywhere else
  // (OperationsProgressTab, TechDashboard's activeTechs) -- Truxton/Casey
  // occasionally clocking in shouldn't appear on a per-tech hours ranking.
  const rankedTechs = techs
    .filter(t => t.is_active !== false && t.title !== "owner")
    .map(t => ({ ...t, hours: rangeHoursTotal(timeEntries, t.id, start, end) }))
    .filter(t => t.hours > 0)
    .sort((a,b) => b.hours - a.hours);

  const [bulkText, setBulkText] = useState("");
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);

  async function runImport() {
    setImporting(true);
    setImportResult(null);
    const lines = bulkText.split("\n").map(l=>l.trim()).filter(Boolean);
    const techByName = {};
    techs.forEach(t => { techByName[t.name.toLowerCase()] = t; });
    const nowYear = new Date().getFullYear();
    const rows = [];
    const errors = [];

    lines.forEach((line, i) => {
      // Format 2 — weekly total, historical June-1-to-present backfill only:
      // "Name: Month Day TotalHours" e.g. "JaMuar Hill: July 4 37.18". No
      // daily breakdown exists for this data, so it's spread evenly across 4
      // consecutive days (Mon-Thu) starting at WeekStartDate, one synthetic
      // 8am-start session per day -- keeps daily numbers plausible while
      // still rolling up to the correct weekly total for Rev/Hr etc.
      const weeklyMatch = line.match(/^(.+?):\s*([A-Za-z]+)\s+(\d{1,2})\s+([\d.]+)\s*$/);
      if (weeklyMatch) {
        const [, rawName, monthName, dayStr, hoursStr] = weeklyMatch;
        const tech = techByName[rawName.trim().toLowerCase()];
        if (!tech) { errors.push(`Line ${i+1}: no tech named "${rawName.trim()}"`); return; }
        const monthIdx = MONTH_NAMES[monthName.toLowerCase()];
        if (monthIdx === undefined) { errors.push(`Line ${i+1}: "${monthName}" isn't a recognized month name`); return; }
        const totalHours = parseFloat(hoursStr);
        if (isNaN(totalHours) || totalHours <= 0) { errors.push(`Line ${i+1}: invalid hours "${hoursStr}"`); return; }
        const weekStart = new Date(nowYear, monthIdx, parseInt(dayStr,10));
        if (weekStart.getDay() !== 1) {
          const actualDay = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][weekStart.getDay()];
          errors.push(`Line ${i+1}: "${monthName} ${dayStr}" is a ${actualDay}, not a Monday — week start dates must be Mondays`);
          return;
        }
        const perDayHours = totalHours / 4;
        for (let d = 0; d < 4; d++) {
          const dayDate = new Date(weekStart); dayDate.setDate(weekStart.getDate()+d);
          const dayStrFmt = `${dayDate.getFullYear()}-${String(dayDate.getMonth()+1).padStart(2,"0")}-${String(dayDate.getDate()).padStart(2,"0")}`;
          const clockIn = mtTimeToIso(dayStrFmt, "08:00");
          const clockOut = new Date(new Date(clockIn).getTime() + perDayHours*3600000).toISOString();
          rows.push({ tech_id: tech.id, work_date: dayStrFmt, clock_in: clockIn, clock_out: clockOut });
        }
        return;
      }

      // Format 1 — per-session: "Name, YYYY-MM-DD, HH:MM, HH:MM"
      const parts = line.split(",").map(p=>p.trim());
      if (parts.length !== 4) { errors.push(`Line ${i+1}: unrecognized format — expected "Name, YYYY-MM-DD, HH:MM, HH:MM" or "Name: Month Day TotalHours" — "${line}"`); return; }
      const [name, date, inTime, outTime] = parts;
      const tech = techByName[name.toLowerCase()];
      if (!tech) { errors.push(`Line ${i+1}: no tech named "${name}"`); return; }
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) { errors.push(`Line ${i+1}: date must be YYYY-MM-DD, got "${date}"`); return; }
      if (!/^\d{1,2}:\d{2}$/.test(inTime) || !/^\d{1,2}:\d{2}$/.test(outTime)) { errors.push(`Line ${i+1}: times must be 24-hour HH:MM, got "${inTime}" / "${outTime}"`); return; }
      const pad = t => t.length===4 ? "0"+t : t;
      rows.push({ tech_id: tech.id, work_date: date, clock_in: mtTimeToIso(date, pad(inTime)), clock_out: mtTimeToIso(date, pad(outTime)) });
    });

    if (errors.length > 0) { setImportResult({ ok:false, errors }); setImporting(false); return; }
    try {
      await sb("time_entries", { method:"POST", body:JSON.stringify(rows), prefer:"return=minimal" });
      await refreshAll();
      setImportResult({ ok:true, count: rows.length });
      setBulkText("");
      showToast(`✅ Imported ${rows.length} session${rows.length===1?"":"s"}`);
    } catch(e) { setImportResult({ ok:false, errors:[e.message] }); }
    setImporting(false);
  }

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      <DateRangePicker label="🕒 Time Sheet" color={C.blue} preset={rangePreset} setPreset={setRangePreset} customStart={cStart} setCustomStart={setCStart} customEnd={cEnd} setCustomEnd={setCEnd}>
        <div style={{ fontSize:"11px", color:C.blue, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginTop:"8px" }}>
          {start} → {end} · {rankedTechs.length} tech{rankedTechs.length!==1?"s":""} with hours
        </div>
      </DateRangePicker>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
          <Label color={C.blue}>🕒 Hours by Tech · {start} → {end}</Label>
        </div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"8px" }}>
          {rankedTechs.length===0 && <div style={{ fontSize:"13px", color:C.muted, textAlign:"center", padding:"12px" }}>No hours logged in this range.</div>}
          {rankedTechs.map((t,i)=>(
            <div key={t.id} style={{ display:"flex", justifyContent:"space-between" }}>
              <span style={{ fontSize:"13px", color:C.black }}>{medal(i)} {t.name}</span>
              <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"13px", color:C.black }}>{t.hours.toFixed(2)}h</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.orange}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"12px" }}>
        <Label color={C.orange}>Bulk Import — One-Time Backfill</Label>
        <div style={{ fontSize:"12px", color:C.muted, display:"flex", flexDirection:"column", gap:"4px" }}>
          <div>Two line formats, mix freely — one entry per line:</div>
          <div>• Per-session: <code>Tech Name, YYYY-MM-DD, HH:MM, HH:MM</code> (24-hour, Mountain Time). Same tech + date twice = two sessions that day (e.g. a lunch break).</div>
          <div>• Weekly total (historical, no daily breakdown available): <code>Tech Name: Month Day TotalHours</code> — day must be a <strong>Monday</strong>. Spread evenly across 4 synthetic Mon–Thu sessions so daily numbers stay plausible while the weekly total still rolls up correctly.</div>
        </div>
        <textarea value={bulkText} onChange={e=>setBulkText(e.target.value)} rows={8} placeholder={"Riley Lyon, 2026-06-02, 08:15, 16:30\nTom Lorenc, 2026-06-02, 07:30, 15:00\nJaMuar Hill: July 4 37.18"} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"10px", borderRadius:"8px", fontSize:"12px", fontFamily:"monospace", width:"100%", boxSizing:"border-box", resize:"vertical" }}/>
        <button onClick={runImport} disabled={importing||!bulkText.trim()} style={{ background:importing?"#333":C.orange, border:"none", color:C.white, padding:"13px", borderRadius:"12px", cursor:(importing||!bulkText.trim())?"not-allowed":"pointer", fontSize:"13px", fontWeight:"700", letterSpacing:"2px", fontFamily:"'Barlow Condensed',sans-serif", width:"100%", textTransform:"uppercase" }}>
          {importing ? "Importing..." : "Import Sessions"}
        </button>
        {importResult && (
          importResult.ok
            ? <div style={{ fontSize:"12px", color:C.green }}>✅ Imported {importResult.count} session{importResult.count===1?"":"s"}.</div>
            : <div style={{ background:"#ef444418", border:"1px solid #ef4444", borderRadius:"8px", padding:"10px", fontSize:"11px", color:"#ef4444", maxHeight:"200px", overflowY:"auto", display:"flex", flexDirection:"column", gap:"4px" }}>
                {importResult.errors.map((e,i)=><div key={i}>{e}</div>)}
              </div>
        )}
      </div>
    </div>
  );
}

// ─── ADMIN UPSELL ENTRY (with date picker) ────────────────────────────────────
function AdminUpsellEntry({ techs, refreshAll, showToast, upsells, jobs=[] }) {
  const todayDefault = new Date(Date.now() - 6*3600000).toISOString().split("T")[0];
  // Defaults to "custom" pre-filled with the old hardcoded range so existing
  // behavior is unchanged for anyone who doesn't touch the picker -- they
  // also now get Today/WTD/MTD/etc. shortcuts on top.
  const [repairPreset, setRepairPreset] = useState("custom");
  const [repairCStart, setRepairCStart] = useState("2026-06-01");
  const [repairCEnd,   setRepairCEnd]   = useState(todayDefault);
  const { start: repairFrom, end: repairTo } = getDateRangeBounds(repairPreset, repairCStart, repairCEnd);
  const [repairResult, setRepairResult] = useState(null);
  const [repairing, setRepairing] = useState(false);
  const [upsExpanded, setUpsExpanded] = useState(false);

  function exportUpsellsCSV() {
    const rows = repairResult?.jobs || [];
    if (rows.length === 0) return;
    const header = ["Job ID","Tech","Date","Revenue","Discount","Upsell Amount","Invoice Found"];
    const csvRows = rows.map(r => [r.jobId, r.tech, r.date, r.revenue.toFixed(2), r.discount.toFixed(2), r.upsells.toFixed(2), r.invoiceFound ? "Found" : "Fallback"]);
    const csv = [header, ...csvRows].map(row => row.map(cell => `"${String(cell).replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `upsell-repair_${repairFrom}_to_${repairTo}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  async function repairFromHCP() {
    setRepairing(true);
    setRepairResult(null);
    try {
      // Split range into 7-day chunks so each call stays under the 26s Netlify timeout
      const chunks = [];
      let cur = new Date(repairFrom + "T12:00:00Z");
      const end = new Date(repairTo + "T12:00:00Z");
      while (cur <= end) {
        const chunkFrom = cur.toISOString().split("T")[0];
        const chunkEnd = new Date(cur);
        chunkEnd.setUTCDate(chunkEnd.getUTCDate() + 6);
        const chunkTo = chunkEnd > end ? repairTo : chunkEnd.toISOString().split("T")[0];
        chunks.push({ from: chunkFrom, to: chunkTo });
        cur.setUTCDate(cur.getUTCDate() + 7);
      }
      let totalUpsells = 0, totalJobs = 0, totalInvMatched = 0, allJobRows = [];
      for (let i = 0; i < chunks.length; i++) {
        const chunk = chunks[i];
        showToast(`Scanning week ${i+1} of ${chunks.length}...`);
        const res = await fetch("/.netlify/functions/hcp-upsell-repair", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(chunk),
        });
        const data = await res.json();
        if (!data.ok) { showToast("Repair failed on week " + chunk.from, false); setRepairing(false); return; }
        totalUpsells += data.upsellsFound || 0;
        totalJobs += data.jobsScanned || 0;
        totalInvMatched += data.invoicesMatched || 0;
        if (data.jobs) allJobRows.push(...data.jobs);
      }
      await refreshAll();
      setRepairResult({ upsellsFound: totalUpsells, jobsScanned: totalJobs, invoicesMatched: totalInvMatched, jobs: allJobRows });
      showToast(`✅ Found ${totalUpsells} upsell${totalUpsells===1?"":"s"} from HCP`);
    } catch(e) { showToast("Error: "+e.message, false); }
    setRepairing(false);
  }

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      {/* ── Repair / Backfill ── */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.orange}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"12px" }}>
        <Label color={C.orange}>Repair Upsells from HCP</Label>
        <div style={{ fontSize:"12px", color:C.muted }}>Scans every "Additional Upgrades" line item across a custom date range and writes the real amounts to the board. Use this to fix missing or wrong upsells.</div>
        <DateRangePicker label="📅 Date Range" color={C.orange} preset={repairPreset} setPreset={setRepairPreset} customStart={repairCStart} setCustomStart={setRepairCStart} customEnd={repairCEnd} setCustomEnd={setRepairCEnd}>
          <div style={{ fontSize:"11px", color:C.orange, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginTop:"8px" }}>
            {repairFrom} → {repairTo}
          </div>
        </DateRangePicker>
        <button onClick={repairFromHCP} disabled={repairing} style={{ background:repairing?"#333":C.orange, border:"none", color:C.white, padding:"13px", borderRadius:"12px", cursor:repairing?"not-allowed":"pointer", fontSize:"13px", fontWeight:"700", letterSpacing:"2px", fontFamily:"'Barlow Condensed',sans-serif", width:"100%", textTransform:"uppercase" }}>
          {repairing ? "Scanning HCP — this may take ~20 sec..." : "Repair Upsells"}
        </button>
        {repairResult && (
          <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
            <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px 14px", fontSize:"12px", color:C.muted, display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:"8px" }}>
              <span>
                Scanned <strong style={{color:C.black}}>{repairResult.jobsScanned}</strong> jobs · matched <strong style={{color:C.black}}>{repairResult.invoicesMatched}</strong> invoices · wrote <strong style={{color:C.orange}}>{repairResult.upsellsFound} upsell{repairResult.upsellsFound===1?"":"s"}</strong> to the board
              </span>
              {repairResult.jobs && repairResult.jobs.length > 0 && (
                <div style={{ display:"flex", gap:"6px" }}>
                  <button onClick={()=>setUpsExpanded(v=>!v)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"5px 10px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px", letterSpacing:"1px" }}>
                    {upsExpanded ? "COLLAPSE" : "VIEW FULL REPORT"}
                  </button>
                  <button onClick={exportUpsellsCSV} style={{ background:C.green, border:"none", color:C.black, padding:"5px 10px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px", letterSpacing:"1px" }}>
                    EXPORT CSV
                  </button>
                </div>
              )}
            </div>
            {repairResult.jobs && repairResult.jobs.length > 0 && (
              <div style={{ overflowX:"auto", maxHeight: upsExpanded ? "none" : "320px", overflowY:"auto", borderRadius:"8px", border:`1px solid ${C.border}` }}>
                <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"11px", fontFamily:"'Barlow',sans-serif" }}>
                  <thead>
                    <tr style={{ background:C.card, position:"sticky", top:0 }}>
                      {["Job ID","Tech","Date","Revenue","Discount","Upsells","Invoice"].map(h => (
                        <th key={h} style={{ padding:"6px 10px", textAlign:"left", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", whiteSpace:"nowrap", borderBottom:`1px solid ${C.border}` }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {repairResult.jobs.map((row, i) => (
                      <tr key={row.jobId} style={{ background: i%2===0 ? C.cardLt : C.card }}>
                        <td style={{ padding:"5px 10px", color:C.muted, whiteSpace:"nowrap" }}>{row.jobId}</td>
                        <td style={{ padding:"5px 10px", color:C.black, whiteSpace:"nowrap" }}>{row.tech}</td>
                        <td style={{ padding:"5px 10px", color:C.muted, whiteSpace:"nowrap" }}>{row.date}</td>
                        <td style={{ padding:"5px 10px", color:C.green, fontWeight:"700", whiteSpace:"nowrap" }}>${row.revenue.toFixed(2)}</td>
                        <td style={{ padding:"5px 10px", color: row.discount > 0 ? C.orange : C.muted, whiteSpace:"nowrap" }}>{row.discount > 0 ? `-$${row.discount.toFixed(2)}` : "—"}</td>
                        <td style={{ padding:"5px 10px", color: row.upsells > 0 ? C.orange : C.muted, fontWeight: row.upsells > 0 ? "700" : "400", whiteSpace:"nowrap" }}>{row.upsells > 0 ? `$${row.upsells.toFixed(2)}` : "—"}</td>
                        <td style={{ padding:"5px 10px", color: row.invoiceFound ? C.green : C.muted, whiteSpace:"nowrap" }}>{row.invoiceFound ? "✓" : "fallback"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {(() => {
        // Same range the Repair Upsells button above uses — changing FROM/TO
        // updates this board too, instead of a separate hardcoded all-time sum.
        // Filters by each entry's real completion date (jobs.job_date, joined
        // via hcp_job_id), same exact-date approach as the tech-facing Upsells
        // tab. Manually-entered rows with no hcp_job_id have no date to match
        // against and are excluded, surfaced via the warning below rather than
        // silently dropped.
        const jobDateByHcpId = {};
        jobs.forEach(j => { if (j.hcp_job_id && !jobDateByHcpId[j.hcp_job_id]) jobDateByHcpId[j.hcp_job_id] = j.job_date; });
        const upsellsWithDate = (upsells||[]).map(u => ({ ...u, resolvedDate: u.hcp_job_id ? (jobDateByHcpId[u.hcp_job_id] || null) : null }));
        const rangeInRange = upsellsWithDate.filter(u => u.resolvedDate && u.resolvedDate >= repairFrom && u.resolvedDate <= repairTo);
        const noDateEntries = upsellsWithDate.filter(u => !u.resolvedDate);
        const noDateTotal = noDateEntries.reduce((s,u)=>s+(u.amount||0),0);
        const rangeByTech = {};
        rangeInRange.forEach(u => { rangeByTech[u.tech_id] = (rangeByTech[u.tech_id]||0) + (u.amount||0); });
        const rangeRanked = [...techs].map(t=>({...t, amt: rangeByTech[t.id]||0})).sort((a,b)=>b.amt-a.amt);
        return (
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px 18px" }}>
            <Label color={C.green}>Upsell Totals · {repairFrom} → {repairTo}</Label>
            {noDateEntries.length>0&&(
              <div style={{ background:C.cardLt, borderRadius:"8px", padding:"8px 12px", fontSize:"11px", color:C.muted, marginBottom:"10px" }}>
                ⚠ {noDateEntries.length} entr{noDateEntries.length!==1?"ies":"y"} totaling ${noDateTotal.toLocaleString()} {noDateEntries.length!==1?"have":"has"} no matched completion date (manually entered, not tied to an HCP job) — excluded from this range.
              </div>
            )}
            {rangeRanked.map((t,i)=>(
              <div key={t.id} style={{ display:"flex", justifyContent:"space-between", marginBottom:"8px" }}>
                <span style={{ fontSize:"13px", color:C.black }}>{medal(i)} {t.name}</span>
                <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", color:C.green }}>${t.amt.toLocaleString()} · {Math.round(t.amt*UPSELL_PTS_PER_DOLLAR)} pts</span>
              </div>
            ))}
          </div>
        );
      })()}
    </div>
  );
}

// ─── ADMIN REVIEW ENTRY (with month picker) ───────────────────────────────────
function AdminReviewEntry({ techs, reviews, saving, setSaving, refreshAll, showToast }) {
  const mk = getMonthKey();
  const [targetMonth, setTargetMonth] = useState(mk);
  const [form, setForm] = useState({});
  const [rangePreset, setRangePreset] = useState("wtd");
  const [cStart, setCStart] = useState("");
  const [cEnd, setCEnd] = useState("");

  const byMonth = {};
  reviews.forEach(r=>{ byMonth[r.month_key]=(byMonth[r.month_key]||0)+1; });
  const existingMonths = Object.keys(byMonth).sort((a,b)=>b.localeCompare(a));

  const monthData = {};
  reviews.filter(r=>r.month_key===targetMonth).forEach(r=>{ monthData[r.tech_id]=r.count; });

  async function handleSave() {
    setSaving(true);
    try {
      for (const t of techs) {
        const val = parseInt(form[t.id]);
        if (isNaN(val)||val<=0) continue;
        const existing = await sb(`reviews?tech_id=eq.${t.id}&month_key=eq.${targetMonth}&select=id`);
        if (existing&&existing.length>0) await sb(`reviews?id=eq.${existing[0].id}`,{method:"PATCH",body:JSON.stringify({count:val}),prefer:"return=minimal"});
        else await sb("reviews",{method:"POST",body:JSON.stringify({tech_id:t.id,month_key:targetMonth,count:val})});
      }
      await refreshAll();
      showToast("✅ Reviews saved for " + formatMonthLabel(targetMonth) + "!");
      setForm({});
    } catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }

  // Date range — same picker as Reports/Upsells/Switchovers. Reviews are only
  // logged with a month_key ("YYYY-MM"), not an exact day, so range filtering
  // matches by month overlap: any review in a month overlapping the range.
  const { start: rangeStart, end: rangeEnd } = getDateRangeBounds(rangePreset, cStart, cEnd);
  const rangeStartMonth = rangeStart.slice(0, 7);
  const rangeEndMonth   = rangeEnd.slice(0, 7);
  const rangeInRange = reviews.filter(r => r.month_key >= rangeStartMonth && r.month_key <= rangeEndMonth);
  const rangeByTech = {};
  rangeInRange.forEach(r => { rangeByTech[r.tech_id] = (rangeByTech[r.tech_id]||0) + (r.count||0); });
  const rangeRanked = techs
    .map(t => ({ ...t, count: rangeByTech[t.id] || 0 }))
    .filter(t => t.count > 0)
    .sort((a, b) => b.count - a.count);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"14px" }}>
      <Label color={C.gold}>Log 5-Star Reviews</Label>
      <div style={{ fontSize:"12px", color:C.muted }}>+{REVIEW_PTS} pts each · +{REVIEW_BONUS_PTS} bonus at 10+ · Log current or any past month</div>

      <div style={{ background:C.cardLt, borderRadius:"8px", padding:"8px 12px", fontSize:"12px", color:C.muted }}>
        {formatLastEntered(mostRecentTimestamp(reviews)) ? (
          <>Last entered: <strong style={{ color:C.black }}>{formatLastEntered(mostRecentTimestamp(reviews))}</strong> — everything before that is already logged.</>
        ) : "No reviews logged yet."}
      </div>

      <div>
        <div style={{ fontSize:"11px", color:C.muted, marginBottom:"6px" }}>Select month</div>
        <select value={targetMonth} onChange={e=>{ setTargetMonth(e.target.value); setForm({}); }} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"8px 12px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", width:"100%", cursor:"pointer" }}>
          <option value={mk}>{formatMonthLabel(mk)} — Current</option>
          {existingMonths.filter(m=>m!==mk).map(m=><option key={m} value={m}>{formatMonthLabel(m)}</option>)}
          {/* generate last 12 months as options */}
          {Array.from({length:11},(_,i)=>{
            const d = new Date(); d.setMonth(d.getMonth()-(i+1));
            const key = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`;
            return !byMonth[key] ? <option key={key} value={key}>{formatMonthLabel(key)}</option> : null;
          })}
        </select>
      </div>

      <div style={{ background:C.cardLt, borderRadius:"4px", padding:"8px 12px", fontSize:"12px", color:C.gold, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>
        Logging for: {formatMonthLabel(targetMonth)}{targetMonth===mk?" (Current Month)":""}
      </div>

      {techs.map(t=>(
        <div key={t.id} style={{ display:"flex", alignItems:"center", gap:"12px" }}>
          <div style={{ width:"150px" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"15px", color:C.black }}>{t.name}</div>
            <div style={{ fontSize:"11px", color:C.muted }}>logged: {monthData[t.id]||0} ⭐</div>
          </div>
          <div style={{ display:"flex", alignItems:"center", gap:"6px", flex:1 }}>
            <span style={{ color:C.gold, fontSize:"16px" }}>⭐</span>
            <input type="number" placeholder={monthData[t.id]||"0"} value={form[t.id]||""} onChange={e=>setForm(f=>({...f,[t.id]:e.target.value}))} style={{ background:C.card, border:`1px solid ${C.border}`, color:C.black, padding:"8px 10px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow Condensed',sans-serif", width:"100%", fontWeight:"700" }}/>
          </div>
        </div>
      ))}
      <button onClick={handleSave} disabled={saving} style={{ background:saving?"#333":C.gold, border:"none", color:saving?"#666":C.black, padding:"13px", borderRadius:"12px", cursor:saving?"not-allowed":"pointer", fontSize:"13px", fontWeight:"700", letterSpacing:"2px", fontFamily:"'Barlow Condensed',sans-serif", width:"100%", textTransform:"uppercase" }}>{saving?"Saving...":"Save Reviews"}</button>
    </div>

    <DateRangePicker label="📅 Date Range" color={C.gold} preset={rangePreset} setPreset={setRangePreset} customStart={cStart} setCustomStart={setCStart} customEnd={cEnd} setCustomEnd={setCEnd}>
      <div style={{ fontSize:"11px", color:C.gold, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginTop:"8px" }}>
        {rangeStart} → {rangeEnd} · matched by month (reviews are logged by month, not exact day)
      </div>
    </DateRangePicker>

    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", overflow:"hidden" }}>
      <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
        <Label color={C.gold}>⭐ Review Totals · {rangeStart} → {rangeEnd}</Label>
      </div>
      <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"8px" }}>
        {rangeRanked.length===0 && <div style={{ fontSize:"13px", color:C.muted, textAlign:"center", padding:"12px" }}>No reviews logged in this range.</div>}
        {rangeRanked.map((t,i)=>(
          <div key={t.id} style={{ display:"flex", justifyContent:"space-between" }}>
            <span style={{ fontSize:"13px", color:C.black }}>{medal(i)} {t.name}</span>
            <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"13px", color:C.black }}>{t.count} ⭐</span>
          </div>
        ))}
      </div>
    </div>
    </div>
  );
}

// ─── ADMIN TIP ENTRY ───────────────────────────────────────────────────────────
// Manual entry only — HCP doesn't reliably surface tip data (confirmed: not on
// the invoice, payment, or job objects in any usable way), and the various
// automatic fallbacks that used to run were themselves the source of
// consistently wrong tip numbers. This form is now the only way tips enter
// the system, for both manual use and a future Cowork automation filling the
// same form.
function AdminTipEntry({ techs, tipEntries, refreshAll, showToast }) {
  const todayDefault = new Date(Date.now() - 6*3600000).toISOString().split("T")[0];
  const [form, setForm] = useState({ techId:"", date:todayDefault, amount:"" });
  const [saving, setSaving] = useState(false);

  async function logTip() {
    const amt = parseFloat(form.amount);
    if (!form.techId) return showToast("Select a tech", false);
    if (!form.date) return showToast("Select a date", false);
    if (isNaN(amt) || amt <= 0) return showToast("Enter a valid tip amount", false);
    setSaving(true);
    try {
      await sb("tip_entries", { method:"POST", body:JSON.stringify({ tech_id:form.techId, work_date:form.date, amount:amt }) });
      await refreshAll();
      showToast(`✅ Logged $${amt.toFixed(2)} tip`);
      setForm(f => ({ ...f, amount:"" }));
    } catch(e) { showToast("Error: "+e.message, false); }
    setSaving(false);
  }

  async function deleteTip(id) {
    if (!window.confirm("Delete this tip entry?")) return;
    setSaving(true);
    try {
      await sb(`tip_entries?id=eq.${id}`, { method:"DELETE", prefer:"return=minimal" });
      await refreshAll();
      showToast("Tip entry deleted");
    } catch(e) { showToast("Error: "+e.message, false); }
    setSaving(false);
  }

  const recent = [...tipEntries].sort((a,b)=>(b.created_at||"").localeCompare(a.created_at||"")).slice(0,25);
  const techById = Object.fromEntries(techs.map(t=>[t.id,t]));
  const selStyle = (val) => ({ background:C.cardLt, border:`1px solid ${C.border}`, color:val?C.black:C.muted, padding:"10px 14px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", width:"100%", boxSizing:"border-box", cursor:"pointer" });

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"12px" }}>
        <Label color={C.gold}>Log a Tip</Label>
        <div style={{ fontSize:"12px", color:C.muted }}>Manual entry only — this is the source of truth for tip totals everywhere in the app (Reports, Payroll, etc.).</div>
        <select value={form.techId} onChange={e=>setForm(f=>({...f,techId:e.target.value}))} style={selStyle(form.techId)}>
          <option value="">— Select Tech —</option>
          {techs.filter(t=>t.is_active!==false).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
        <div>
          <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginBottom:"6px" }}>Date</div>
          <input type="date" value={form.date} onChange={e=>setForm(f=>({...f,date:e.target.value}))} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box" }}/>
        </div>
        <div>
          <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginBottom:"6px" }}>Amount</div>
          <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
            <span style={{ color:C.gold, fontSize:"16px" }}>$</span>
            <input type="number" min="0" step="0.01" placeholder="e.g. 20.00" value={form.amount} onChange={e=>setForm(f=>({...f,amount:e.target.value}))} style={{ flex:1, background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"12px", fontSize:"16px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", boxSizing:"border-box" }}/>
          </div>
        </div>
        <button onClick={logTip} disabled={saving} style={{ background:saving?"#333":C.gold, border:"none", color:C.black, padding:"13px", borderRadius:"12px", cursor:saving?"not-allowed":"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", letterSpacing:"2px", textTransform:"uppercase" }}>{saving?"Saving...":"Log Tip"}</button>
      </div>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}` }}><Label color={C.gold}>Recent Tips</Label></div>
        <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"8px" }}>
          {recent.length===0 && <div style={{ fontSize:"13px", color:C.muted, textAlign:"center", padding:"12px" }}>No tips logged yet.</div>}
          {recent.map(t=>(
            <div key={t.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"6px 0", borderBottom:`1px solid ${C.border}` }}>
              <span style={{ fontSize:"13px", color:C.black }}>{techById[t.tech_id]?.name||"Unknown"} · {fmtShortDate(t.work_date)}</span>
              <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"13px", color:C.gold }}>${t.amount.toFixed(2)}</span>
                <button onClick={()=>deleteTip(t.id)} style={{ background:"none", border:"1px solid #ef4444", color:"#ef4444", padding:"3px 8px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"10px" }}>DELETE</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── RIDE-ALONG SYSTEM ────────────────────────────────────────────────────────
// Covers only the LAST HOUR of a job — the window the ride-along observer is
// actually present for. Items reference RUBRIC_ITEMS_SEED ids (rubric_items table)
// by id rather than duplicating description/script text a second time.
const CHECKLIST_SECTIONS = [
  {
    id: "interior_finish",
    title: "Interior Finish",
    icon: "🧽",
    itemIds: ["item_21", "item_22", "item_23", "item_24", "item_25"],
  },
  {
    id: "exterior_finish",
    title: "Exterior Finish",
    icon: "✨",
    itemIds: ["item_31", "item_32", "item_33", "item_34", "item_35"],
  },
  {
    id: "closeout",
    title: "Client Walkthrough & Close",
    icon: "🤝",
    itemIds: ["item_36", "item_37", "item_38", "item_39"],
    notes: [
      { id:"faults", label:"Technique/script delivery faults — name any:" },
      { id:"wins",   label:"What are they succeeding with?" },
    ],
  },
  {
    id: "job_closeout",
    title: "Job Close-Out",
    icon: "📦",
    itemIds: ["item_43", "item_44", "item_45"],
  },
  {
    id: "next_client",
    title: "Next Client Update",
    icon: "📱",
    itemIds: ["item_46"],
  },
];

// Score = ✅ ÷ (✅ + ❌), N/A excluded. _meta_score_pct's value is a number, not
// "✅"/"❌", so it's naturally excluded from this filter — no special-casing needed.
function scorePctFromChecklist(cl) {
  const vals = Object.values(cl).filter(v => v === "✅" || v === "❌");
  if (!vals.length) return null;
  return Math.round(vals.filter(v => v === "✅").length / vals.length * 100);
}
function scoreColor(pct) {
  if (pct == null) return C.muted;
  if (pct >= 90) return C.green;
  if (pct >= 75) return C.blue;
  return C.red;
}

// Get all upcoming Thursdays
function getThursdays(count = 12) {
  const thursdays = [];
  const now = new Date();
  const day = now.getDay();
  const daysUntilThursday = (4 - day + 7) % 7 || 7;
  let next = new Date(now);
  next.setDate(now.getDate() + daysUntilThursday);
  for (let i = 0; i < count; i++) {
    const d = new Date(next);
    d.setDate(next.getDate() + i * 7);
    thursdays.push(d.toISOString().split("T")[0]);
  }
  return thursdays;
}

function formatDate(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("en-US", { weekday:"long", month:"long", day:"numeric" });
}

function RideAlongTab({ techs, rideAlongs, schedules, onSave, onSaveSchedule, saving }) {
  const [view, setView] = useState("schedule"); // "schedule" | "new" | "history" | "detail"
  const [selectedTech, setSelectedTech] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [checklist, setChecklist] = useState({});
  const [notes, setNotes] = useState({});
  const [generalNotes, setGeneralNotes] = useState("");
  const [viewDetail, setViewDetail] = useState(null);
  const [scheduleMap, setScheduleMap] = useState({});
  const [rubricItems, setRubricItems] = useState([]);
  const [loadingRubric, setLoadingRubric] = useState(true);
  const [expandedScript, setExpandedScript] = useState({});
  const thursdays = getThursdays(12);

  useEffect(() => {
    sb("rubric_items?select=*&order=sort_order")
      .then(items => setRubricItems(items || []))
      .catch(() => setRubricItems([]))
      .finally(() => setLoadingRubric(false));
  }, []);
  const rubricMap = {};
  rubricItems.forEach(r => { rubricMap[r.id] = r; });

  // Load existing schedule into map
  useEffect(() => {
    const map = {};
    schedules.forEach(s => { map[s.date] = s.tech_id; });
    setScheduleMap(map);
  }, [schedules]);

  function resetForm() {
    setChecklist({});
    setNotes({});
    setGeneralNotes("");
    setSelectedTech("");
    setSelectedDate("");
  }

  async function handleSaveRideAlong() {
    if (!selectedTech || !selectedDate) return;
    const scorePct = scorePctFromChecklist(checklist);
    await onSave({
      tech_id: selectedTech,
      date: selectedDate,
      checklist: JSON.stringify({ ...checklist, _meta_score_pct: scorePct }),
      notes: JSON.stringify(notes),
      general_notes: generalNotes,
    });
    resetForm();
    setView("history");
  }

  async function handleScheduleChange(date, techId) {
    const newMap = { ...scheduleMap, [date]: techId };
    setScheduleMap(newMap);
    await onSaveSchedule(date, techId);
  }

  const inp = { background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box", resize:"vertical", minHeight:"80px" };
  const selStyle = (val) => ({ background:C.cardLt, border:`1px solid ${C.border}`, color:val?C.white:C.muted, padding:"10px 14px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box", cursor:"pointer" });

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      {/* View switcher */}
      <div style={{ display:"flex", gap:"8px", flexWrap:"wrap" }}>
        {[["schedule","📅 Schedule"],["new","✏️ New Ride-Along"],["history","📋 History"]].map(([id,label])=>(
          <button key={id} onClick={()=>{ setView(id); setViewDetail(null); }} style={{ background:view===id?C.blue:C.card, border:`1px solid ${view===id?C.blue:C.border}`, color:view===id?C.white:C.muted, padding:"8px 16px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", letterSpacing:"1px", textTransform:"uppercase" }}>{label}</button>
        ))}
      </div>

      {/* SCHEDULE VIEW */}
      {view==="schedule"&&(
        <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.blue}`, borderRadius:"12px", padding:"16px 18px" }}>
            <Label color={C.blue}>📅 Thursday Ride-Along Schedule</Label>
            <div style={{ fontSize:"12px", color:C.muted, marginBottom:"14px" }}>Assign a tech to each Thursday. This is your weekly coaching schedule.</div>
            <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
              {thursdays.map(date=>{
                const assignedId = scheduleMap[date];
                const assignedTech = techs.find(t=>t.id===assignedId);
                const isPast = new Date(date) < new Date(new Date().toISOString().split("T")[0]);
                return (
                  <div key={date} style={{ background:C.cardLt, border:`1px solid ${assignedId?C.blue:C.border}`, borderRadius:"12px", padding:"12px 16px", display:"flex", alignItems:"center", gap:"12px", opacity:isPast?0.6:1 }}>
                    <div style={{ flex:1 }}>
                      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"15px", color:C.black }}>{formatDate(date)}</div>
                      {isPast&&<div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px", textTransform:"uppercase" }}>Past</div>}
                    </div>
                    <select
                      value={scheduleMap[date]||""}
                      onChange={e=>handleScheduleChange(date,e.target.value)}
                      style={{ background:C.card, border:`1px solid ${assignedId?C.blue:C.border}`, color:assignedId?C.blue:C.muted, padding:"6px 10px", borderRadius:"4px", fontSize:"13px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", cursor:"pointer", minWidth:"140px" }}
                    >
                      <option value="">— Assign Tech —</option>
                      {techs.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
                    </select>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Next up */}
          {(() => {
            const today = new Date().toISOString().split("T")[0];
            const next = thursdays.find(d=>d>=today&&scheduleMap[d]);
            if (!next) return null;
            const tech = techs.find(t=>t.id===scheduleMap[next]);
            return (
              <div style={{ background:`${C.blue}18`, border:`1px solid ${C.blue}44`, borderRadius:"12px", padding:"16px 18px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                <div>
                  <div style={{ fontSize:"10px", color:C.blue, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginBottom:"4px" }}>Next Ride-Along</div>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:C.black }}>{tech?.name}</div>
                  <div style={{ fontSize:"13px", color:C.muted }}>{formatDate(next)}</div>
                </div>
                <button onClick={()=>{ setSelectedTech(scheduleMap[next]); setSelectedDate(next); setView("new"); }} style={{ background:C.blue, border:"none", color:C.black, padding:"10px 18px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", letterSpacing:"1px" }}>START SESSION →</button>
              </div>
            );
          })()}
        </div>
      )}

      {/* NEW RIDE-ALONG FORM */}
      {view==="new"&&(
        <div style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.green}`, borderRadius:"12px", padding:"16px 18px", display:"flex", flexDirection:"column", gap:"12px" }}>
            <Label color={C.green}>✏️ New Ride-Along Session</Label>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"10px" }}>
              <select value={selectedTech} onChange={e=>setSelectedTech(e.target.value)} style={selStyle(selectedTech)}>
                <option value="">— Select Tech —</option>
                {techs.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
              <input type="date" value={selectedDate} onChange={e=>setSelectedDate(e.target.value)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:selectedDate?C.white:C.muted, padding:"10px 14px", borderRadius:"12px", fontSize:"14px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box" }}/>
            </div>
          </div>

          {loadingRubric&&(
            <div style={{ background:C.cardLt, border:`1px solid ${C.border}`, borderRadius:"10px", padding:"14px", fontSize:"13px", color:C.muted }}>Loading checklist items...</div>
          )}

          {!loadingRubric&&CHECKLIST_SECTIONS.map(section=>(
            <div key={section.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.blue}`, borderRadius:"12px", padding:"16px 18px" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"18px", color:C.black, letterSpacing:"2px", marginBottom:"14px" }}>{section.icon} {section.title.toUpperCase()}</div>
              <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
                {section.itemIds.map(itemId=>{
                  const item = rubricMap[itemId];
                  if (!item) return null;
                  const key = section.id+"_"+item.id;
                  return (
                    <div key={item.id} style={{ display:"flex", flexDirection:"column", gap:"2px" }}>
                      <div style={{ display:"flex", alignItems:"flex-start", gap:"12px" }}>
                        <div style={{ display:"flex", gap:"6px", flexShrink:0, marginTop:"2px" }}>
                          {["✅","❌","N/A"].map(val=>(
                            <button key={val} onClick={()=>setChecklist(c=>({...c,[key]:val}))}
                              style={{ background:checklist[key]===val?( val==="✅"?`${C.green}33`:val==="❌"?"#ff444433":"#ffffff22"):C.cardLt, border:`1px solid ${checklist[key]===val?(val==="✅"?C.green:val==="❌"?C.red:C.muted):C.border}`, color:checklist[key]===val?(val==="✅"?C.green:val==="❌"?C.red:C.white):C.muted, padding:"3px 8px", borderRadius:"4px", cursor:"pointer", fontSize:"11px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", whiteSpace:"nowrap" }}>
                              {val}
                            </button>
                          ))}
                        </div>
                        <div style={{ fontSize:"13px", color:C.black, lineHeight:"1.4", paddingTop:"2px" }}>{item.description}</div>
                      </div>
                      {item.has_script&&(
                        <div style={{ marginLeft:"78px" }}>
                          <button onClick={()=>setExpandedScript(s=>({...s,[item.id]:!s[item.id]}))} style={{ background:"none", border:"none", color:C.blue, fontSize:"11px", cursor:"pointer", padding:"2px 0", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>
                            {expandedScript[item.id]?"▲ Hide Perfect Day script":"▼ View Perfect Day script"}
                          </button>
                          {expandedScript[item.id]&&(
                            <div style={{ background:C.blueXlt, border:`1px solid ${C.border}`, borderRadius:"6px", padding:"8px 10px", fontSize:"12px", color:C.black, marginTop:"4px", lineHeight:1.5 }}>
                              {item.script_text}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
                {section.notes?.map(note=>(
                  <div key={note.id} style={{ marginTop:"4px" }}>
                    <div style={{ fontSize:"12px", color:C.muted, marginBottom:"6px" }}>{note.label}</div>
                    <textarea value={notes[section.id+"_"+note.id]||""} onChange={e=>setNotes(n=>({...n,[section.id+"_"+note.id]:e.target.value}))} placeholder="Type notes here..." style={{...inp, minHeight:"64px"}}/>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Live score */}
          {!loadingRubric&&(() => {
            const livePct = scorePctFromChecklist(checklist);
            return (
              <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${scoreColor(livePct)}`, borderRadius:"12px", padding:"16px 18px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                <Label color={scoreColor(livePct)}>📊 Live Score</Label>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"28px", color:scoreColor(livePct) }}>{livePct==null?"—":`${livePct}%`}</div>
              </div>
            );
          })()}

          {/* General notes */}
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.gold}`, borderRadius:"12px", padding:"16px 18px" }}>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"18px", color:C.black, letterSpacing:"2px", marginBottom:"10px" }}>📝 GENERAL NOTES & COACHING POINTS</div>
            <textarea value={generalNotes} onChange={e=>setGeneralNotes(e.target.value)} placeholder="Overall session notes, things to work on, wins, action items for next ride-along..." style={{...inp, minHeight:"100px"}}/>
          </div>

          <button onClick={handleSaveRideAlong} disabled={saving||!selectedTech||!selectedDate} style={{ background:saving||!selectedTech||!selectedDate?"#333":C.green, border:"none", color:saving||!selectedTech||!selectedDate?"#666":C.black, padding:"14px", borderRadius:"12px", cursor:saving||!selectedTech||!selectedDate?"not-allowed":"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", letterSpacing:"2px", textTransform:"uppercase" }}>
            {saving?"SAVING...":"SAVE RIDE-ALONG SESSION"}
          </button>
        </div>
      )}

      {/* HISTORY VIEW */}
      {view==="history"&&!viewDetail&&(
        <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.purple}`, borderRadius:"12px", padding:"16px 18px" }}>
            <Label color={C.purple}>📋 Ride-Along History</Label>
            {rideAlongs.length===0&&<div style={{ fontSize:"13px", color:C.muted }}>No ride-alongs logged yet.</div>}
            {[...rideAlongs].sort((a,b)=>b.date.localeCompare(a.date)).map(ra=>{
              const tech = techs.find(t=>t.id===ra.tech_id);
              const cl = ra.checklist ? JSON.parse(ra.checklist) : {};
              const passed = Object.values(cl).filter(v=>v==="✅").length;
              const failed = Object.values(cl).filter(v=>v==="❌").length;
              const total = Object.values(cl).length;
              const pct = typeof cl._meta_score_pct==="number" ? cl._meta_score_pct : scorePctFromChecklist(cl);
              return (
                <div key={ra.id} onClick={()=>setViewDetail(ra)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"14px 16px", marginBottom:"8px", cursor:"pointer", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"16px", color:C.black }}>{tech?.name}</div>
                    <div style={{ fontSize:"12px", color:C.muted }}>{formatDate(ra.date)}</div>
                    {total>0&&<div style={{ fontSize:"11px", color:C.muted, marginTop:"3px" }}><span style={{ color:C.green }}>✅ {passed}</span> passed · <span style={{ color:C.red }}>❌ {failed}</span> failed</div>}
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                    {pct!=null&&<Pill color={scoreColor(pct)}>{pct}%</Pill>}
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", color:C.blue, letterSpacing:"1px" }}>VIEW →</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* DETAIL VIEW */}
      {view==="history"&&viewDetail&&(
        <div style={{ display:"flex", flexDirection:"column", gap:"14px" }}>
          <button onClick={()=>setViewDetail(null)} style={{ background:"none", border:`1px solid ${C.border}`, color:C.muted, padding:"8px 16px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"12px", letterSpacing:"1px", alignSelf:"flex-start" }}>← BACK TO HISTORY</button>
          {(() => {
            const tech = techs.find(t=>t.id===viewDetail.tech_id);
            const cl = viewDetail.checklist ? JSON.parse(viewDetail.checklist) : {};
            const notes = viewDetail.notes ? JSON.parse(viewDetail.notes) : {};
            const pct = typeof cl._meta_score_pct==="number" ? cl._meta_score_pct : scorePctFromChecklist(cl);
            return (
              <>
                <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.purple}`, borderRadius:"12px", padding:"16px 18px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
                  <div>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"22px", color:C.black }}>{tech?.name}</div>
                    <div style={{ fontSize:"13px", color:C.muted }}>{formatDate(viewDetail.date)}</div>
                  </div>
                  {pct!=null&&<Pill color={scoreColor(pct)}>{pct}% Score</Pill>}
                </div>
                {CHECKLIST_SECTIONS.map(section=>(
                  <div key={section.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.blue}`, borderRadius:"12px", padding:"16px 18px" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:C.black, letterSpacing:"2px", marginBottom:"12px" }}>{section.icon} {section.title.toUpperCase()}</div>
                    {section.itemIds.map(itemId=>{
                      const item = rubricMap[itemId];
                      if (!item) return null;
                      const val = cl[section.id+"_"+item.id];
                      return (
                        <div key={item.id} style={{ marginBottom:"8px" }}>
                          <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                            <span style={{ fontSize:"14px", flexShrink:0 }}>{val||"—"}</span>
                            <span style={{ fontSize:"13px", color:C.black }}>{item.description}</span>
                          </div>
                          {item.has_script&&(
                            <div style={{ marginLeft:"24px" }}>
                              <button onClick={()=>setExpandedScript(s=>({...s,[item.id]:!s[item.id]}))} style={{ background:"none", border:"none", color:C.blue, fontSize:"11px", cursor:"pointer", padding:"2px 0", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>
                                {expandedScript[item.id]?"▲ Hide Perfect Day script":"▼ View Perfect Day script"}
                              </button>
                              {expandedScript[item.id]&&(
                                <div style={{ background:C.blueXlt, border:`1px solid ${C.border}`, borderRadius:"6px", padding:"8px 10px", fontSize:"12px", color:C.black, marginTop:"4px", lineHeight:1.5 }}>
                                  {item.script_text}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                    {section.notes?.map(note=>{
                      const val = notes[section.id+"_"+note.id];
                      if (!val) return null;
                      return (
                        <div key={note.id} style={{ marginTop:"8px", background:C.cardLt, borderRadius:"4px", padding:"10px 12px" }}>
                          <div style={{ fontSize:"11px", color:C.muted, marginBottom:"4px" }}>{note.label}</div>
                          <div style={{ fontSize:"13px", color:C.black, lineHeight:"1.5", whiteSpace:"pre-wrap" }}>{val}</div>
                        </div>
                      );
                    })}
                  </div>
                ))}
                {viewDetail.general_notes&&(
                  <div style={{ background:C.card, border:`1px solid ${C.border}`, borderLeft:`3px solid ${C.gold}`, borderRadius:"12px", padding:"16px 18px" }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:C.black, letterSpacing:"2px", marginBottom:"10px" }}>📝 GENERAL NOTES</div>
                    <div style={{ fontSize:"13px", color:C.black, lineHeight:"1.6", whiteSpace:"pre-wrap" }}>{viewDetail.general_notes}</div>
                  </div>
                )}
              </>
            );
          })()}
        </div>
      )}
    </div>
  );
}

// ─── EMPLOYEE DEVELOPMENT ────────────────────────────────────────────────────

const RUBRIC_ITEMS_SEED = [
  { id:"item_01", sort_order:1,  phase:"night_before",    description:"Manual night-before text reminder sent to next day's clients",                                                                                         has_script:true,  script_text:"Hey [Client Name] this is [Tech Name] from Skylo Detailing, I am the one who will be doing your car tomorrow! Just wanted to give you one last reminder about the appointment and let you know I'll be there around [9/12/3], and if you could have your personal belongings taken out of the vehicle that would be greatly appreciated, see you tomorrow!" },
  { id:"item_02", sort_order:2,  phase:"night_before",    description:"Checked schedule/route to confirm first job location and departure time from home",                                                                      has_script:false, script_text:"" },
  { id:"item_03", sort_order:3,  phase:"pre_job",         description:"Pre-job checklist completed",                                                                                                                           has_script:false, script_text:"" },
  { id:"item_04", sort_order:4,  phase:"pre_job",         description:"Chemicals topped off/full",                                                                                                                              has_script:false, script_text:"" },
  { id:"item_05", sort_order:5,  phase:"pre_job",         description:"Equipment totes checked and stocked",                                                                                                                    has_script:false, script_text:"" },
  { id:"item_06", sort_order:6,  phase:"pre_job",         description:"Truck stocked with proper towel count",                                                                                                                  has_script:false, script_text:"" },
  { id:"item_07", sort_order:7,  phase:"pre_job",         description:"Water tank checked full (topped off if not)",                                                                                                            has_script:false, script_text:"" },
  { id:"item_08", sort_order:8,  phase:"pre_job",         description:"Generator gas checked full (topped off if not)",                                                                                                         has_script:false, script_text:"" },
  { id:"item_09", sort_order:9,  phase:"pre_job",         description:"Departed with enough time to arrive 10 min early to first job",                                                                                         has_script:false, script_text:"" },
  { id:"item_10", sort_order:10, phase:"arrival",         description:"On My Way text sent via HCP automated feature (timing option matching drive time from warehouse)",                                                       has_script:false, script_text:"[Tech Name] is scheduled to arrive in [15/30/45] minutes" },
  { id:"item_11", sort_order:11, phase:"arrival",         description:"Correct arrival greeting/introduction script used",                                                                                                      has_script:true,  script_text:"Hey [Client Name], my name is [Tech Name] and I will be the one taking care of your premium detail today. If you could come out we can do the pre-job inspection to make sure we are taking care of everything you wanted today. (If client doesn't come out: tech does the pre-job inspection alone and texts the client about any concerns or upsells found.)" },
  { id:"item_12", sort_order:12, phase:"arrival",         description:"Pre-premium-detail inspection walkthrough completed with client, including upsell script if applicable",                                                         has_script:true,  script_text:"Open all doors and explain what will be done today based on the job's line items. Upsell moment if something is found not on the line items: \"Hey, I noticed there are some [stains on the seat / carpet / pet hair in the carpet] and that will need some extra time and equipment to get that all out. I can go ahead and do that for [$25/$50/$75] today, is that something you'd be interested in?\" If client pushes back: explain the surface will be cleaned as part of the standard detail, but getting it all the way out requires an extra 30-45 minutes and heavier-duty equipment, which is why it's an additional charge." },
  { id:"item_13", sort_order:13, phase:"arrival",         description:"Before pics taken",                                                                                                                                      has_script:false, script_text:"" },
  { id:"item_14", sort_order:14, phase:"sequencing",      description:"Correct interior/exterior order chosen based on weather (exterior first in AM if hot/sunny, exterior last if last job of day)",                          has_script:false, script_text:"" },
  { id:"item_15", sort_order:15, phase:"cleaning",        description:"Trash and floor mats removed",                                                                                                                           has_script:false, script_text:"" },
  { id:"item_16", sort_order:16, phase:"cleaning",        description:"Full vehicle air compressed",                                                                                                                            has_script:false, script_text:"" },
  { id:"item_17", sort_order:17, phase:"cleaning",        description:"Vacuumed (or LVP used if vacuum already cleared majority of dirt/debris)",                                                                               has_script:false, script_text:"" },
  { id:"item_18", sort_order:18, phase:"cleaning",        description:"Interior cleaned starting driver seat, back seat driver side, trunk, back seat passenger side, passenger seat",                                          has_script:false, script_text:"" },
  { id:"item_19", sort_order:19, phase:"mid_job",         description:"Mid-job update text sent with before/after photo of dirtiest area",                                                                                      has_script:true,  script_text:"Hey [Client Name], your premium detail is coming along well! Here's a before and after of those [stains/issue] we removed in your seats. I should be done in about [time], so if you can be available to come walk through the car with me then that would be awesome!" },
  { id:"item_20", sort_order:20, phase:"mid_job",         description:"Timing awareness communicated to next client (early/late notice) if applicable",                                                                         has_script:false, script_text:"" },
  { id:"item_21", sort_order:21, phase:"interior_finish", description:"Mats dried and returned",                                                                                                                                has_script:false, script_text:"" },
  { id:"item_22", sort_order:22, phase:"interior_finish", description:"Windows cleaned",                                                                                                                                        has_script:false, script_text:"" },
  { id:"item_23", sort_order:23, phase:"interior_finish", description:"Door jambs cleaned (if exterior is on the job)",                                                                                                         has_script:false, script_text:"" },
  { id:"item_24", sort_order:24, phase:"interior_finish", description:"Interior checklist completed",                                                                                                                           has_script:false, script_text:"" },
  { id:"item_25", sort_order:25, phase:"interior_finish", description:"After pics taken (interior)",                                                                                                                            has_script:false, script_text:"" },
  { id:"item_26", sort_order:26, phase:"exterior",        description:"Pre-rinse completed (mist down, cool and prime surface)",                                                                                                has_script:false, script_text:"" },
  { id:"item_27", sort_order:27, phase:"exterior",        description:"Tires sprayed and scrubbed, rinsed off",                                                                                                                 has_script:false, script_text:"" },
  { id:"item_28", sort_order:28, phase:"exterior",        description:"Foam applied (full car if shaded/cool, panel-by-panel if hot)",                                                                                          has_script:false, script_text:"" },
  { id:"item_29", sort_order:29, phase:"exterior",        description:"Wash wands used to scrub down full vehicle",                                                                                                             has_script:false, script_text:"" },
  { id:"item_30", sort_order:30, phase:"exterior",        description:"Rinsed off and thoroughly dried",                                                                                                                        has_script:false, script_text:"" },
  { id:"item_31", sort_order:31, phase:"exterior",        description:"Windows touched up with exterior towel",                                                                                                                 has_script:false, script_text:"" },
  { id:"item_32", sort_order:32, phase:"exterior",        description:"Rims dried, excess water/dirt removed from rims and tire face",                                                                                          has_script:false, script_text:"" },
  { id:"item_33", sort_order:33, phase:"exterior",        description:"Tire shine applied",                                                                                                                                     has_script:false, script_text:"" },
  { id:"item_34", sort_order:34, phase:"exterior",        description:"Exterior checklist completed",                                                                                                                           has_script:false, script_text:"" },
  { id:"item_35", sort_order:35, phase:"exterior",        description:"After pics taken (exterior), attached in HCP",                                                                                                           has_script:false, script_text:"" },
  { id:"item_36", sort_order:36, phase:"closeout",        description:"Correct walkthrough script used with client",                                                                                                            has_script:true,  script_text:"Hey [Client Name], I am just finishing up with a few last-minute touches, could you come out so we can walk through it together? Once they come out: Ok so your premium detail is looking awesome, I want to show you how it came out. If you see anything I missed please point it out so I can get it taken care of, 4 eyes are better than 2. We started off by taking out all the trash from the vehicle, then we did a full air compressor blow-out on your vents, seats, carpets and surfaces to get all the dirt and debris out of there, then we did a full vacuum on the vehicle including seats, carpets, all compartments and the trunk, then we cleaned, disinfected, and protected all hard surfaces such as the dash, console, cupholders, door panels, etc., then we did the interior windows and windshield. Then on the exterior we deep cleaned all the tires, rims, and wheel wells, we did a foam bath with a hand wash that removed all contaminants, bugs, and debris from your paint, touched up the windows, and finished off with a tire dressing on the wheel face." },
  { id:"item_37", sort_order:37, phase:"closeout",        description:"Tap-to-pay invoice completed",                                                                                                                           has_script:false, script_text:"" },
  { id:"item_38", sort_order:38, phase:"closeout",        description:"Google review ask made",                                                                                                                                 has_script:true,  script_text:"Hey, if you loved your premium detail and thought I did a great job I would love it if you could leave me a 5-star rating on Google, here's the link, and if you just mention my name it would help a ton with a competition we're currently running!" },
  { id:"item_39", sort_order:39, phase:"closeout",        description:"Referral ask made",                                                                                                                                      has_script:true,  script_text:"Is there any friends, family, or neighbors that you could think of that would love this service? If so, would you mind giving me their number or address so I could reach out to them? You get $20 off your next service for any referral that books and pays for the detail!" },
  { id:"item_40", sort_order:40, phase:"no_show",         description:"30-second video walkthrough recorded and sent (interior: front seats, vacuum/LVP, windows, back area; exterior: rims, tires, wheel wells, windows, grill, back end)", has_script:false, script_text:"" },
  { id:"item_41", sort_order:41, phase:"no_show",         description:"Google review link sent via text (same wording as item_38)",                                                                                             has_script:true,  script_text:"Hey, if you loved your premium detail and thought I did a great job I would love it if you could leave me a 5-star rating on Google, here's the link, and if you just mention my name it would help a ton with a competition we're currently running!" },
  { id:"item_42", sort_order:42, phase:"no_show",         description:"Referral ask sent via text (same wording as item_39)",                                                                                                   has_script:true,  script_text:"Is there any friends, family, or neighbors that you could think of that would love this service? If so, would you mind giving me their number or address so I could reach out to them? You get $20 off your next service for any referral that books and pays for the detail!" },
  { id:"item_43", sort_order:43, phase:"job_closeout",    description:"3 door hangers placed",                                                                                                                                  has_script:false, script_text:"" },
  { id:"item_44", sort_order:44, phase:"job_closeout",    description:"Customer satisfaction card placed",                                                                                                                      has_script:false, script_text:"" },
  { id:"item_45", sort_order:45, phase:"job_closeout",    description:"Photos of door hangers/card attached in HCP",                                                                                                            has_script:false, script_text:"" },
  { id:"item_46", sort_order:46, phase:"job_closeout",    description:"On My Way text sent to next client",                                                                                                                     has_script:false, script_text:"" },
  { id:"item_47", sort_order:47, phase:"end_of_day",      description:"All trash removed from truck",                                                                                                                           has_script:false, script_text:"" },
  { id:"item_48", sort_order:48, phase:"end_of_day",      description:"All personal belongings removed from truck",                                                                                                             has_script:false, script_text:"" },
  { id:"item_49", sort_order:49, phase:"end_of_day",      description:"Totes and exterior bucket emptied/cleaned out",                                                                                                          has_script:false, script_text:"" },
  { id:"item_50", sort_order:50, phase:"end_of_day",      description:"Water tank refilled",                                                                                                                                    has_script:false, script_text:"" },
  { id:"item_51", sort_order:51, phase:"end_of_day",      description:"Clean towels returned to correct bin",                                                                                                                   has_script:false, script_text:"" },
  { id:"item_52", sort_order:52, phase:"end_of_day",      description:"Dirty towels placed in correct dirty bin",                                                                                                               has_script:false, script_text:"" },
  { id:"item_53", sort_order:53, phase:"end_of_day",      description:"Next day's schedule checked",                                                                                                                            has_script:false, script_text:"" },
  { id:"item_54", sort_order:54, phase:"end_of_day",      description:"Night-before texts sent for next day's clients (same script as item_01)",                                                                                has_script:true,  script_text:"Hey [Client Name] this is [Tech Name] from Skylo Detailing, I am the one who will be doing your car tomorrow! Just wanted to give you one last reminder about the appointment and let you know I'll be there around [9/12/3], and if you could have your personal belongings taken out of the vehicle that would be greatly appreciated, see you tomorrow!" },
  { id:"item_55", sort_order:55, phase:"end_of_day",      description:"First job location confirmed for next day (to plan departure/arrival time)",                                                                             has_script:false, script_text:"" },
];

const PHASE_LABELS = {
  night_before:"Night Before", pre_job:"Pre-Job", arrival:"Arrival",
  sequencing:"Interior/Exterior Sequencing", cleaning:"Cleaning Sequence",
  mid_job:"Mid-Job Communication", interior_finish:"Interior Finish",
  exterior:"Exterior", closeout:"Client Walkthrough & Close",
  no_show:"No-Show Protocol", job_closeout:"Job Close-Out", end_of_day:"End of Day",
};

const STAGE_CONFIG = {
  classroom:      { label:"Classroom",      color:"#2b9cf0", icon:"📚" },
  field_training: { label:"Field Training", color:"#7c3aed", icon:"🔧" },
  cert_pending:   { label:"Cert Pending",   color:"#f59e0b", icon:"⏳" },
  cert_passed:    { label:"Certified",      color:"#00c853", icon:"✅" },
  active:         { label:"Active",         color:"#00c853", icon:"⭐" },
  hard_fail:      { label:"Hard Fail",      color:"#ef4444", icon:"🚫" },
};

const TITLE_LABELS = {
  detail_apprentice:    "Detail Apprentice",
  detail_pro:           "Detail Pro",
  senior_detail_pro:    "Senior Detail Pro",
  lead_detail_pro:      "Lead Detail Pro",
  equipment_coordinator:"Equipment Coordinator",
  field_supervisor:     "Field Supervisor",
};
const TRAINER_TITLES = ["lead_detail_pro","equipment_coordinator","field_supervisor"];

async function scheduleCheckins(techId, startDate) {
  const MILESTONES = [
    { milestone:"week_1",  days:7  },
    { milestone:"week_2",  days:14 },
    { milestone:"week_4",  days:28 },
    { milestone:"week_6",  days:42 },
    { milestone:"week_12", days:84 },
  ];
  const base = new Date(startDate + "T12:00:00Z");
  for (const { milestone, days } of MILESTONES) {
    const existing = await sb(`checkins?tech_id=eq.${techId}&milestone=eq.${milestone}&select=id`).catch(()=>[]);
    if (existing && existing.length > 0) continue;
    const d = new Date(base);
    d.setUTCDate(base.getUTCDate() + days);
    await sb("checkins", { method:"POST", body:JSON.stringify({ tech_id:techId, milestone, scheduled_date:d.toISOString().split("T")[0] }) });
  }
}

function PerfectDayTrainingPanel({ tech }) {
  const [rubricItems, setRubricItems] = useState([]);
  const [signoffs, setSignoffs] = useState({});
  const [expandedScript, setExpandedScript] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      sb("rubric_items?select=*&order=sort_order"),
      sb(`training_signoffs?tech_id=eq.${tech.id}&select=rubric_item_id,signed_off`),
    ]).then(([items, offs]) => {
      setRubricItems(items || []);
      const map = {};
      for (const o of (offs || [])) map[o.rubric_item_id] = o.signed_off;
      setSignoffs(map);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [tech.id]);

  if (loading) return <div style={{ color:C.muted, padding:"16px" }}>Loading training progress...</div>;

  const total = rubricItems.length;
  const done = rubricItems.filter(i => signoffs[i.id]).length;
  const pct = total ? Math.round((done / total) * 100) : 0;

  const byPhase = {}, phases = [];
  for (const item of rubricItems) {
    if (!byPhase[item.phase]) { byPhase[item.phase] = []; phases.push(item.phase); }
    byPhase[item.phase].push(item);
  }

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px" }}>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:C.black, marginBottom:"10px" }}>
          Perfect Day Training — {done}/{total} items signed off
        </div>
        <Bar pct={pct} color={done === total && total > 0 ? C.green : C.blue} h={8}/>
        <div style={{ fontSize:"11px", color:C.muted, marginTop:"4px" }}>
          {pct}% complete{done === total && total > 0 ? " — eligible for cert!" : ""}
        </div>
      </div>
      {total === 0 && (
        <div style={{ background:C.cardLt, border:`1px solid ${C.border}`, borderRadius:"10px", padding:"14px", fontSize:"13px", color:C.muted }}>
          Rubric items not seeded yet. Ask an admin to seed them in the Development tab.
        </div>
      )}
      {phases.map(phase => (
        <div key={phase} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden" }}>
          <div style={{ background:C.cardLt, padding:"10px 16px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:C.blue, letterSpacing:"1px" }}>
            {PHASE_LABELS[phase] || phase}
          </div>
          {byPhase[phase].map(item => (
            <div key={item.id} style={{ padding:"10px 16px", borderBottom:`1px solid ${C.border}40` }}>
              <div style={{ display:"flex", alignItems:"flex-start", gap:"10px" }}>
                <div style={{ width:"18px", height:"18px", borderRadius:"3px", border:`2px solid ${signoffs[item.id] ? C.green : C.border}`, background:signoffs[item.id] ? C.green : "transparent", flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", marginTop:"1px" }}>
                  {signoffs[item.id] && <span style={{ color:C.white, fontSize:"11px", lineHeight:1 }}>✓</span>}
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:"13px", color:signoffs[item.id] ? C.muted : C.black, textDecoration:signoffs[item.id] ? "line-through" : "none" }}>
                    <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", color:C.muted, marginRight:"4px" }}>#{item.sort_order}</span>
                    {item.description}
                  </div>
                  {item.has_script && (
                    <button onClick={() => setExpandedScript(s => ({...s, [item.id]: !s[item.id]}))} style={{ background:"none", border:"none", color:C.blue, fontSize:"11px", cursor:"pointer", padding:"2px 0", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>
                      {expandedScript[item.id] ? "▲ Hide script" : "▼ View script"}
                    </button>
                  )}
                  {item.has_script && expandedScript[item.id] && (
                    <div style={{ background:C.blueXlt, border:`1px solid ${C.border}`, borderRadius:"6px", padding:"8px 10px", fontSize:"12px", color:C.black, marginTop:"4px", lineHeight:1.5 }}>
                      {item.script_text}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function DevelopmentTab({ techs, rideAlongs, refreshAll, showToast }) {
  const inp = { background:C.white, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"8px", fontSize:"14px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box" };
  const sel = (val) => ({...inp, color:val ? C.black : C.muted });
  const btn = (color) => ({ background:color||C.blue, border:"none", color:C.white, padding:"11px 18px", borderRadius:"20px", cursor:"pointer", fontSize:"12px", fontWeight:"900", fontStyle:"italic", letterSpacing:"2px", fontFamily:"'Barlow Condensed',sans-serif", textTransform:"uppercase" });
  const btnSm = (color) => ({...btn(color), padding:"6px 14px", fontSize:"11px" });

  const [devView, setDevView] = useState("signoff");
  const [rubricItems, setRubricItems] = useState(null);
  const [signoffs, setSignoffs] = useState([]);
  const [certs, setCerts] = useState([]);
  const [certResults, setCertResults] = useState([]);
  const [checkins, setCheckins] = useState([]);
  const [loadingDev, setLoadingDev] = useState(true);
  const [seeding, setSeeding] = useState(false);

  const [trainerSel, setTrainerSel] = useState("");
  const [expandedTech, setExpandedTech] = useState(null);
  const [expandedScript, setExpandedScript] = useState({});

  const [certTechSel, setCertTechSel] = useState("");
  const [certAdminBy, setCertAdminBy] = useState("");
  const [certDate, setCertDate] = useState(new Date().toISOString().split("T")[0]);
  const [certScores, setCertScores] = useState({});
  const [submittingCert, setSubmittingCert] = useState(false);
  const [lastCertResult, setLastCertResult] = useState(null);

  const [selectedCheckin, setSelectedCheckin] = useState(null);
  const [checkinForm, setCheckinForm] = useState({});
  const [savingCheckin, setSavingCheckin] = useState(false);

  useEffect(() => { loadDevData(); }, []);

  async function loadDevData() {
    setLoadingDev(true);
    try {
      const [items, offs, c, cr, ci] = await Promise.all([
        sb("rubric_items?select=*&order=sort_order"),
        sb("training_signoffs?select=*"),
        sb("perfect_day_certs?select=*&order=created_at.desc"),
        sb("perfect_day_cert_results?select=*"),
        sb("checkins?select=*&order=scheduled_date"),
      ]);
      setRubricItems(items || []);
      setSignoffs(offs || []);
      setCerts(c || []);
      setCertResults(cr || []);
      setCheckins(ci || []);
    } catch(e) { showToast("Error loading dev data: " + e.message, false); }
    setLoadingDev(false);
  }

  async function seedRubricItems() {
    setSeeding(true);
    try {
      await sb("rubric_items?on_conflict=id", { method:"POST", prefer:"resolution=merge-duplicates,return=minimal", body:JSON.stringify(RUBRIC_ITEMS_SEED) });
      showToast("✅ 55 rubric items seeded!");
      await loadDevData();
    } catch(e) { showToast("Error seeding: " + e.message, false); }
    setSeeding(false);
  }

  async function toggleSignoff(techId, itemId) {
    if (!trainerSel) { showToast("Select a trainer first", false); return; }
    const existing = signoffs.find(s => s.tech_id === techId && s.rubric_item_id === itemId);
    const newVal = !(existing?.signed_off);
    try {
      await sb("training_signoffs?on_conflict=tech_id,rubric_item_id", {
        method:"POST", prefer:"resolution=merge-duplicates,return=minimal",
        body:JSON.stringify({ tech_id:techId, rubric_item_id:itemId, trainer_id:trainerSel, signed_off:newVal, signed_off_at: newVal ? new Date().toISOString() : null }),
      });
      setSignoffs(prev => {
        const filtered = prev.filter(s => !(s.tech_id===techId && s.rubric_item_id===itemId));
        return [...filtered, { tech_id:techId, rubric_item_id:itemId, trainer_id:trainerSel, signed_off:newVal }];
      });
    } catch(e) { showToast("Error: " + e.message, false); }
  }

  async function advanceStage(tech) {
    const order = ["classroom","field_training","cert_pending","cert_passed","active"];
    const idx = order.indexOf(tech.onboarding_stage || "classroom");
    if (idx < 0 || idx >= order.length - 1) return;
    const next = order[idx + 1];
    if (next === "cert_pending" && rubricItems) {
      const done = signoffs.filter(s => s.tech_id === tech.id && s.signed_off).length;
      if (done < rubricItems.length) {
        showToast(`❌ All ${rubricItems.length} items must be signed off before cert`, false);
        return;
      }
    }
    try {
      await sb(`techs?id=eq.${tech.id}`, { method:"PATCH", body:JSON.stringify({ onboarding_stage:next }), prefer:"return=minimal" });
      await refreshAll();
      showToast(`✅ ${tech.name} → ${STAGE_CONFIG[next]?.label || next}`);
      await loadDevData();
    } catch(e) { showToast("Error: " + e.message, false); }
  }

  async function submitCert() {
    if (!certTechSel) { showToast("Select a tech", false); return; }
    if (!certAdminBy) { showToast("Select administered by", false); return; }
    if (!rubricItems || rubricItems.length === 0) { showToast("Rubric items not loaded", false); return; }
    const missing = rubricItems.filter(i => !certScores[i.id]);
    if (missing.length > 0) { showToast(`Score all items first (${missing.length} remaining)`, false); return; }
    const failedItems = rubricItems.filter(i => certScores[i.id] === "fail");
    const overall = failedItems.length === 0 ? "pass" : "fail";
    const tech = techs.find(t => t.id === certTechSel);
    const attemptNumber = certs.filter(c => c.tech_id === certTechSel).length + 1;
    setSubmittingCert(true);
    try {
      const certRes = await sb("perfect_day_certs", { method:"POST", body:JSON.stringify({ tech_id:certTechSel, attempt_number:attemptNumber, administered_by:certAdminBy, test_date:certDate, overall_result:overall }) });
      const certId = certRes?.[0]?.id;
      if (!certId) throw new Error("No cert ID returned");
      for (const item of rubricItems) {
        await sb("perfect_day_cert_results", { method:"POST", body:JSON.stringify({ cert_id:certId, rubric_item_id:item.id, result:certScores[item.id] }) });
      }
      const certStatus = overall==="pass" ? "passed" : attemptNumber===1 ? "failed_retest_1" : attemptNumber===2 ? "failed_retest_2" : "hard_fail";
      const patch = { cert_attempts:attemptNumber, cert_status:certStatus };
      if (overall === "pass") patch.onboarding_stage = "cert_passed";
      await sb(`techs?id=eq.${certTechSel}`, { method:"PATCH", body:JSON.stringify(patch), prefer:"return=minimal" });
      setLastCertResult({ overall, failedItems, techName:tech?.name, attemptNumber });
      showToast(overall==="pass" ? `✅ ${tech?.name} PASSED!` : `${tech?.name} did not pass — study sheet below`);
      await refreshAll();
      await loadDevData();
      setCertScores({});
    } catch(e) { showToast("Error: " + e.message, false); }
    setSubmittingCert(false);
  }

  async function saveCheckin() {
    if (!selectedCheckin) return;
    setSavingCheckin(true);
    try {
      await sb(`checkins?id=eq.${selectedCheckin.id}`, { method:"PATCH", prefer:"return=minimal", body:JSON.stringify({ ...checkinForm, status:"completed", completed_date:new Date().toISOString().split("T")[0] }) });
      showToast("✅ Check-in saved!");
      setSelectedCheckin(null); setCheckinForm({});
      await loadDevData();
    } catch(e) { showToast("Error: " + e.message, false); }
    setSavingCheckin(false);
  }

  if (loadingDev) return <div style={{ color:C.muted, padding:"20px" }}>Loading...</div>;

  const byPhase = {}, phases = [];
  if (rubricItems) {
    for (const item of rubricItems) {
      if (!byPhase[item.phase]) { byPhase[item.phase] = []; phases.push(item.phase); }
      byPhase[item.phase].push(item);
    }
  }
  const signoffMap = {};
  for (const s of signoffs) {
    if (!signoffMap[s.tech_id]) signoffMap[s.tech_id] = {};
    signoffMap[s.tech_id][s.rubric_item_id] = s.signed_off;
  }
  const stageOrder = ["classroom","field_training","cert_pending","cert_passed","active"];
  const activeTechs = techs.filter(t => t.is_active !== false);

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      {rubricItems && rubricItems.length === 0 && (
        <div style={{ background:`${C.gold}18`, border:`1px solid ${C.gold}`, borderRadius:"10px", padding:"14px 16px", display:"flex", alignItems:"center", justifyContent:"space-between", gap:"12px" }}>
          <div style={{ fontSize:"13px", color:C.black }}>Rubric items not seeded yet.</div>
          <button onClick={seedRubricItems} disabled={seeding} style={btnSm(C.gold)}>{seeding ? "Seeding..." : "Seed 55 Items"}</button>
        </div>
      )}

      {/* Sub-view switcher */}
      <div style={{ display:"flex", gap:"8px", flexWrap:"wrap" }}>
        {[["signoff","📋 Training Sign-Off"],["cert","🏆 Perfect Day Cert"],["checkins","📅 Check-Ins"]].map(([id,label]) => (
          <button key={id} onClick={() => setDevView(id)} style={{ ...btnSm(devView===id ? C.blue : C.cardLt), color:devView===id ? C.white : C.black, flex:1, minWidth:"120px", border:`1px solid ${devView===id ? C.blue : C.border}` }}>{label}</button>
        ))}
      </div>

      {/* ── A. TRAINING SIGN-OFF ── */}
      {devView==="signoff" && (
        <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"12px 16px", display:"flex", alignItems:"center", gap:"12px" }}>
            <span style={{ fontSize:"12px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", color:C.muted, whiteSpace:"nowrap" }}>SIGNING OFF AS:</span>
            <select value={trainerSel} onChange={e=>setTrainerSel(e.target.value)} style={{...sel(trainerSel), flex:1}}>
              <option value="">— Select Trainer —</option>
              {activeTechs.filter(t=>TRAINER_TITLES.includes(t.title)).map(t => <option key={t.id} value={t.id}>{t.name} — {TITLE_LABELS[t.title]}</option>)}
            </select>
          </div>
          {activeTechs.map(tech => {
            const sc = STAGE_CONFIG[tech.onboarding_stage || "classroom"] || STAGE_CONFIG.classroom;
            const items = rubricItems || [];
            const tSoffs = signoffMap[tech.id] || {};
            const doneCount = items.filter(i => tSoffs[i.id]).length;
            const isExp = expandedTech === tech.id;
            const stageIdx = stageOrder.indexOf(tech.onboarding_stage || "classroom");
            const canAdv = stageIdx >= 0 && stageIdx < stageOrder.indexOf("active");
            return (
              <div key={tech.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden" }}>
                <div onClick={() => setExpandedTech(isExp ? null : tech.id)} style={{ padding:"12px 16px", display:"flex", alignItems:"center", gap:"12px", cursor:"pointer", background:C.cardLt }}>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:C.black, flex:1 }}>{tech.name}</div>
                  <Pill color={sc.color}>{sc.icon} {sc.label}</Pill>
                  <div style={{ fontSize:"12px", color:C.muted }}>{doneCount}/{items.length}</div>
                  <div style={{ fontSize:"13px", color:C.muted }}>{isExp ? "▲" : "▼"}</div>
                </div>
                {isExp && (
                  <div style={{ padding:"12px 16px", display:"flex", flexDirection:"column", gap:"10px" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:"10px", padding:"8px", background:`${C.blue}08`, borderRadius:"8px" }}>
                      <input type="checkbox" id={`cc_${tech.id}`} checked={!!tech.classroom_complete} onChange={e => sb(`techs?id=eq.${tech.id}`,{method:"PATCH",body:JSON.stringify({classroom_complete:e.target.checked}),prefer:"return=minimal"}).then(()=>refreshAll()).catch(e=>showToast("Error: "+e.message,false))} style={{ width:"16px", height:"16px", cursor:"pointer" }}/>
                      <label htmlFor={`cc_${tech.id}`} style={{ fontSize:"13px", color:C.black, cursor:"pointer" }}>Classroom training complete</label>
                    </div>
                    <Bar pct={items.length ? Math.round((doneCount/items.length)*100) : 0} color={doneCount===items.length&&items.length>0 ? C.green : C.blue} h={6}/>
                    {phases.map(phase => (
                      <div key={phase}>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"12px", color:C.blue, letterSpacing:"1px", marginBottom:"4px", marginTop:"8px" }}>{PHASE_LABELS[phase] || phase}</div>
                        {byPhase[phase].map(item => (
                          <div key={item.id} style={{ padding:"5px 0", borderBottom:`1px solid ${C.border}20` }}>
                            <div style={{ display:"flex", alignItems:"flex-start", gap:"10px" }}>
                              <input type="checkbox" checked={!!tSoffs[item.id]} onChange={() => toggleSignoff(tech.id, item.id)} style={{ width:"15px", height:"15px", marginTop:"2px", cursor:"pointer" }}/>
                              <div style={{ flex:1 }}>
                                <div style={{ fontSize:"12px", color:tSoffs[item.id] ? C.muted : C.black, textDecoration:tSoffs[item.id] ? "line-through" : "none" }}>
                                  <span style={{ color:C.muted, marginRight:"4px" }}>#{item.sort_order}</span>{item.description}
                                </div>
                                {item.has_script && (<>
                                  <button onClick={() => setExpandedScript(s => ({...s, [`${tech.id}_${item.id}`]: !s[`${tech.id}_${item.id}`]}))} style={{ background:"none", border:"none", color:C.blue, fontSize:"10px", cursor:"pointer", padding:"2px 0", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>
                                    {expandedScript[`${tech.id}_${item.id}`] ? "▲ Hide" : "▼ Script"}
                                  </button>
                                  {expandedScript[`${tech.id}_${item.id}`] && (
                                    <div style={{ background:C.blueXlt, border:`1px solid ${C.border}`, borderRadius:"6px", padding:"8px 10px", fontSize:"11px", color:C.black, marginTop:"4px", lineHeight:1.5 }}>{item.script_text}</div>
                                  )}
                                </>)}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ))}
                    <div style={{ display:"flex", gap:"8px", marginTop:"8px", flexWrap:"wrap" }}>
                      {canAdv && <button onClick={() => advanceStage(tech)} style={btnSm(C.green)}>Advance → {STAGE_CONFIG[stageOrder[stageIdx+1]]?.label}</button>}
                      <button onClick={() => sb(`techs?id=eq.${tech.id}`,{method:"PATCH",body:JSON.stringify({onboarding_stage:"hard_fail"}),prefer:"return=minimal"}).then(()=>{ refreshAll(); showToast(`${tech.name} → Hard Fail`); loadDevData(); }).catch(e=>showToast("Error: "+e.message,false))} style={btnSm(C.red)}>Mark Hard Fail</button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── B. PERFECT DAY CERT ── */}
      {devView==="cert" && (
        <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
          {lastCertResult && lastCertResult.overall==="fail" && (
            <div style={{ background:"#ef444410", border:"2px solid #ef4444", borderRadius:"12px", padding:"16px" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:C.red, marginBottom:"8px" }}>
                Study Sheet — {lastCertResult.techName} (Attempt {lastCertResult.attemptNumber})
              </div>
              <div style={{ fontSize:"12px", color:C.muted, marginBottom:"10px" }}>Review these before retesting:</div>
              {lastCertResult.failedItems.map(item => (
                <div key={item.id} style={{ padding:"8px 0", borderBottom:`1px solid ${C.border}40` }}>
                  <div style={{ fontSize:"13px", color:C.black, fontWeight:"600" }}>#{item.sort_order} {item.description}</div>
                  {item.has_script && item.script_text && (
                    <div style={{ background:C.blueXlt, border:`1px solid ${C.border}`, borderRadius:"6px", padding:"8px 10px", fontSize:"11px", color:C.black, marginTop:"4px", lineHeight:1.5 }}>{item.script_text}</div>
                  )}
                </div>
              ))}
              <button onClick={() => setLastCertResult(null)} style={{ ...btnSm(C.border), color:C.black, marginTop:"10px" }}>Dismiss</button>
            </div>
          )}
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px", display:"flex", flexDirection:"column", gap:"12px" }}>
            <Label color={C.blue}>New Perfect Day Cert</Label>
            <div style={{ display:"flex", gap:"10px", flexWrap:"wrap" }}>
              <div style={{ flex:1, minWidth:"150px" }}>
                <div style={{ fontSize:"11px", color:C.muted, marginBottom:"4px" }}>Tech</div>
                <select value={certTechSel} onChange={e => { setCertTechSel(e.target.value); setCertScores({}); setLastCertResult(null); }} style={sel(certTechSel)}>
                  <option value="">— Select Tech —</option>
                  {activeTechs.map(t => {
                    const att = certs.filter(c => c.tech_id === t.id).length;
                    return <option key={t.id} value={t.id} disabled={att>=3}>{t.name}{att>=3 ? " (3 attempts — blocked)" : ""}</option>;
                  })}
                </select>
              </div>
              <div style={{ flex:1, minWidth:"150px" }}>
                <div style={{ fontSize:"11px", color:C.muted, marginBottom:"4px" }}>Administered By</div>
                <select value={certAdminBy} onChange={e => setCertAdminBy(e.target.value)} style={sel(certAdminBy)}>
                  <option value="">— Select —</option>
                  {activeTechs.filter(t=>TRAINER_TITLES.includes(t.title)).map(t => <option key={t.id} value={t.id}>{t.name} — {TITLE_LABELS[t.title]}</option>)}
                </select>
              </div>
              <div style={{ flex:1, minWidth:"130px" }}>
                <div style={{ fontSize:"11px", color:C.muted, marginBottom:"4px" }}>Test Date</div>
                <input type="date" value={certDate} onChange={e => setCertDate(e.target.value)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"10px", borderRadius:"8px", fontSize:"13px", fontFamily:"'Barlow Condensed',sans-serif", width:"100%", boxSizing:"border-box" }}/>
              </div>
            </div>
            {certTechSel && certs.filter(c=>c.tech_id===certTechSel).length>=3 ? (
              <div style={{ background:"#ef444410", border:"1px solid #ef4444", borderRadius:"8px", padding:"12px", fontSize:"13px", color:C.red }}>
                ⚠ 3 attempts used. Recommend a fit conversation instead of another retest.
              </div>
            ) : certTechSel && rubricItems && rubricItems.length > 0 && (
              <>
                <div style={{ fontSize:"11px", color:C.muted }}>Score each item — any ❌ = overall fail.</div>
                {phases.map(phase => (
                  <div key={phase}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"12px", color:C.blue, letterSpacing:"1px", marginBottom:"4px", marginTop:"8px" }}>{PHASE_LABELS[phase]||phase}</div>
                    {byPhase[phase].map(item => (
                      <div key={item.id} style={{ display:"flex", alignItems:"center", gap:"8px", padding:"5px 0", borderBottom:`1px solid ${C.border}20` }}>
                        <div style={{ flex:1, fontSize:"12px", color:C.black }}><span style={{ color:C.muted, marginRight:"4px" }}>#{item.sort_order}</span>{item.description}</div>
                        <button onClick={() => setCertScores(s => ({...s, [item.id]: s[item.id]==="pass" ? null : "pass"}))} style={{ padding:"4px 10px", borderRadius:"6px", border:"none", cursor:"pointer", background:certScores[item.id]==="pass" ? C.green : C.cardLt, color:certScores[item.id]==="pass" ? C.white : C.black, fontSize:"13px" }}>✅</button>
                        <button onClick={() => setCertScores(s => ({...s, [item.id]: s[item.id]==="fail" ? null : "fail"}))} style={{ padding:"4px 10px", borderRadius:"6px", border:"none", cursor:"pointer", background:certScores[item.id]==="fail" ? C.red : C.cardLt, color:certScores[item.id]==="fail" ? C.white : C.black, fontSize:"13px" }}>❌</button>
                      </div>
                    ))}
                  </div>
                ))}
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:"4px" }}>
                  <div style={{ fontSize:"12px", color:C.muted }}>{Object.values(certScores).filter(Boolean).length}/{rubricItems.length} scored · {Object.values(certScores).filter(v=>v==="fail").length} fails</div>
                  <button onClick={submitCert} disabled={submittingCert} style={btnSm(C.blue)}>{submittingCert ? "Submitting..." : "Submit Cert"}</button>
                </div>
              </>
            )}
          </div>
          {certTechSel && certs.filter(c=>c.tech_id===certTechSel).length > 0 && (
            <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"13px", color:C.muted, letterSpacing:"1px" }}>PAST ATTEMPTS</div>
              {certs.filter(c=>c.tech_id===certTechSel).map(cert => (
                <div key={cert.id} style={{ background:C.card, border:`1px solid ${cert.overall_result==="pass" ? C.green : C.red}60`, borderRadius:"10px", padding:"10px 14px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:C.black }}>Attempt #{cert.attempt_number} — {cert.test_date}</div>
                    <div style={{ fontSize:"12px", color:cert.overall_result==="pass" ? C.green : C.red }}>{cert.overall_result==="pass" ? "✅ PASS" : "❌ FAIL"}</div>
                  </div>
                  <div style={{ fontSize:"11px", color:C.muted }}>{certResults.filter(r=>r.cert_id===cert.id&&r.result==="fail").length} fails</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── C. CHECK-INS ── */}
      {devView==="checkins" && (
        <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
          {selectedCheckin && (
            <div style={{ background:C.card, border:`2px solid ${C.blue}`, borderRadius:"12px", padding:"16px", display:"flex", flexDirection:"column", gap:"10px" }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:C.black }}>
                {techs.find(t=>t.id===selectedCheckin.tech_id)?.name} — {selectedCheckin.milestone.replace("_"," ")} ({selectedCheckin.scheduled_date})
              </div>
              {(() => {
                const t = techs.find(x => x.id === selectedCheckin.tech_id);
                if (!t) return null;
                const td = t.start_date ? Math.floor((Date.now() - new Date(t.start_date+"T12:00:00Z")) / 86400000) : null;
                const myRA = (rideAlongs||[]).filter(r=>r.tech_id===t.id).sort((a,b)=>b.date?.localeCompare(a.date)).slice(0,3);
                const raAvg = myRA.length ? Math.round(myRA.reduce((s,r)=>{ const cl=r.checklist?JSON.parse(r.checklist):{}; const v=Object.values(cl); return s+(v.length?v.filter(x=>x==="✅").length/v.length*100:0); },0)/myRA.length) : null;
                return (
                  <div style={{ background:C.cardLt, borderRadius:"8px", padding:"10px 12px", fontSize:"12px", color:C.muted, display:"flex", gap:"16px", flexWrap:"wrap" }}>
                    {td!==null && <span>Tenure: <strong style={{color:C.black}}>{td} days</strong></span>}
                    {raAvg!==null && <span>Last 3 ride-along avg: <strong style={{color:C.black}}>{raAvg}%</strong></span>}
                  </div>
                );
              })()}
              <textarea placeholder="Audit notes (specific missed items discussed)..." value={checkinForm.audit_notes||""} onChange={e=>setCheckinForm(f=>({...f,audit_notes:e.target.value}))} style={{ ...inp, minHeight:"60px", resize:"vertical" }}/>
              <input type="text" placeholder="Goal for next milestone..." value={checkinForm.goal_set||""} onChange={e=>setCheckinForm(f=>({...f,goal_set:e.target.value}))} style={inp}/>
              <div style={{ display:"flex", alignItems:"center", gap:"10px" }}>
                <input type="checkbox" id="happypay" checked={!!checkinForm.happy_with_pay} onChange={e=>setCheckinForm(f=>({...f,happy_with_pay:e.target.checked}))} style={{ width:"16px", height:"16px" }}/>
                <label htmlFor="happypay" style={{ fontSize:"13px", color:C.black }}>Happy with pay</label>
              </div>
              <textarea placeholder="Pay notes..." value={checkinForm.pay_notes||""} onChange={e=>setCheckinForm(f=>({...f,pay_notes:e.target.value}))} style={{ ...inp, minHeight:"50px", resize:"vertical" }}/>
              <textarea placeholder="Team feedback..." value={checkinForm.team_feedback||""} onChange={e=>setCheckinForm(f=>({...f,team_feedback:e.target.value}))} style={{ ...inp, minHeight:"50px", resize:"vertical" }}/>
              <textarea placeholder="QA notes..." value={checkinForm.qa_notes||""} onChange={e=>setCheckinForm(f=>({...f,qa_notes:e.target.value}))} style={{ ...inp, minHeight:"50px", resize:"vertical" }}/>
              <div style={{ display:"flex", gap:"8px" }}>
                <button onClick={saveCheckin} disabled={savingCheckin} style={btnSm(C.green)}>{savingCheckin ? "Saving..." : "Mark Complete & Save"}</button>
                <button onClick={() => { setSelectedCheckin(null); setCheckinForm({}); }} style={{ ...btnSm(C.cardLt), color:C.black, border:`1px solid ${C.border}` }}>Cancel</button>
              </div>
            </div>
          )}
          {activeTechs.map(tech => {
            const tci = checkins.filter(c=>c.tech_id===tech.id).sort((a,b)=>a.scheduled_date.localeCompare(b.scheduled_date));
            const today = new Date().toISOString().split("T")[0];
            return (
              <div key={tech.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden" }}>
                <div style={{ background:C.cardLt, padding:"10px 16px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"15px", color:C.black }}>
                  {tech.name}
                  {tech.start_date && <span style={{ fontSize:"11px", color:C.muted, fontWeight:"400", marginLeft:"8px" }}>started {tech.start_date}</span>}
                </div>
                {tci.length === 0 ? (
                  <div style={{ padding:"12px 16px", fontSize:"12px", color:C.muted }}>No check-ins scheduled. Set a start date to auto-schedule.</div>
                ) : (
                  <div style={{ display:"flex", flexWrap:"wrap", gap:"8px", padding:"12px 16px" }}>
                    {tci.map(ci => {
                      const done = ci.status==="completed";
                      const over = !done && ci.scheduled_date < today;
                      const clr = done ? C.green : over ? C.red : C.blue;
                      return (
                        <button key={ci.id} onClick={() => { setSelectedCheckin(ci); setCheckinForm({ audit_notes:ci.audit_notes||"", goal_set:ci.goal_set||"", happy_with_pay:ci.happy_with_pay, pay_notes:ci.pay_notes||"", team_feedback:ci.team_feedback||"", qa_notes:ci.qa_notes||"" }); }} style={{ background:`${clr}15`, border:`2px solid ${clr}`, borderRadius:"8px", padding:"8px 12px", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:"2px", minWidth:"90px" }}>
                          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:clr }}>{ci.milestone.replace("_"," ")}</div>
                          <div style={{ fontSize:"10px", color:C.muted }}>{ci.scheduled_date}</div>
                          <div style={{ fontSize:"11px", color:clr, fontWeight:"bold" }}>{done ? "✓ Done" : over ? "⚠ Overdue" : "Upcoming"}</div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── SPLIT JOBS ADMIN ─────────────────────────────────────────────────────────
function SplitJobsAdmin({ techs, pendingSplits, refreshAll, showToast }) {
  const techById = Object.fromEntries(techs.map(t => [t.id, t]));
  const [splitInputs, setSplitInputs] = useState({});
  const [upsellAttrib, setUpsellAttrib] = useState({});
  // Row-scoped save state — which single jobId is currently saving, not a
  // shared boolean, so one row's in-flight save doesn't disable/relabel
  // every other row's button.
  const [savingJobId, setSavingJobId] = useState(null);
  // Jobs saved successfully this session, hidden immediately rather than
  // waiting on the next refreshAll()/split_confirmed filter to catch up.
  const [dismissedJobIds, setDismissedJobIds] = useState(new Set());

  // Pre-load any existing upsell attributions for these split jobs
  useEffect(() => {
    if (!pendingSplits.length) return;
    const jobIds = [...new Set(pendingSplits.map(r => r.hcp_job_id))];
    const inList = jobIds.map(id => `"${id}"`).join(",");
    sb(`job_upsell_attribution?hcp_job_id=in.(${inList})&select=hcp_job_id,tech_id`)
      .then(rows => {
        const map = {};
        for (const row of (rows || [])) map[row.hcp_job_id] = row.tech_id;
        setUpsellAttrib(map);
      })
      .catch(() => {});
  }, [pendingSplits]);

  // Group pending rows by hcp_job_id
  const grouped = {};
  for (const row of pendingSplits) {
    if (!grouped[row.hcp_job_id]) grouped[row.hcp_job_id] = [];
    grouped[row.hcp_job_id].push(row);
  }
  const splitJobs = Object.entries(grouped).map(([jobId, rows]) => ({
    jobId,
    date:          rows[0]?.job_date,
    customerName:  rows.find(r => r.customer_name)?.customer_name || null,
    totalRevenue:  +(rows.reduce((s, r) => s + (r.revenue       || 0), 0)).toFixed(2),
    totalTips:     +(rows.reduce((s, r) => s + (r.tips          || 0), 0)).toFixed(2),
    totalUpsells:  +(rows.reduce((s, r) => s + (r.upsell_amount || 0), 0)).toFixed(2),
    rows,
  })).sort((a, b) => (b.date || "").localeCompare(a.date || ""));

  function getInput(jobId, techId, defaultPct) {
    return (splitInputs[jobId] || {})[techId] ?? String(defaultPct);
  }
  function setInput(jobId, techId, val) {
    setSplitInputs(prev => ({ ...prev, [jobId]: { ...(prev[jobId] || {}), [techId]: val } }));
  }

  async function saveSplit(sj) {
    const n = sj.rows.length;
    const defPct = Math.round(100 / n);
    const entries = sj.rows.map(r => ({
      tech_id: r.tech_id,
      pct: parseFloat(getInput(sj.jobId, r.tech_id, defPct) || "0"),
    }));
    const total = entries.reduce((s, e) => s + e.pct, 0);
    if (Math.abs(total - 100) > 0.5) {
      showToast(`Percentages must add up to 100 (got ${total.toFixed(1)}%)`, false);
      return;
    }
    setSavingJobId(sj.jobId);
    try {
      // 1. Write revenue split percentages
      for (const e of entries) {
        await sb(`job_splits?on_conflict=hcp_job_id,tech_id`, {
          method: "POST",
          prefer: "resolution=merge-duplicates,return=minimal",
          body: JSON.stringify({ hcp_job_id: sj.jobId, tech_id: e.tech_id, percentage: e.pct }),
        });
      }
      // 2. Write upsell attribution if set
      const selectedUpsellTechId = upsellAttrib[sj.jobId];
      if (selectedUpsellTechId && sj.totalUpsells > 0) {
        await sb(`job_upsell_attribution?on_conflict=hcp_job_id`, {
          method: "POST",
          prefer: "resolution=merge-duplicates,return=minimal",
          body: JSON.stringify({ hcp_job_id: sj.jobId, tech_id: selectedUpsellTechId }),
        });
      }
      // 3. Immediately recalculate by triggering repair for this job's date
      showToast("⏳ Split saved — applying changes...");
      const repairRes = await fetch("/.netlify/functions/hcp-upsell-repair", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ from: sj.date, to: sj.date }),
      });
      if (!repairRes.ok) throw new Error(`Repair failed (${repairRes.status})`);
      // Hide this row immediately — don't wait on refreshAll()'s
      // split_confirmed filter to catch up before it disappears.
      setDismissedJobIds(prev => new Set(prev).add(sj.jobId));
      await refreshAll();
      showToast("✅ Split confirmed and applied!");
    } catch(err) { showToast("⚠ " + err.message, false); }
    setSavingJobId(null);
  }

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      <div style={{ background:C.cardLt, borderRadius:"8px", padding:"12px 16px", fontSize:"12px", color:C.muted, lineHeight:"1.6" }}>
        These jobs have <strong style={{color:C.black}}>multiple techs</strong> with no confirmed revenue split on record — they are currently
        using <strong style={{color:"#f59e0b"}}>equal split</strong> as a placeholder. Enter the correct percentages below,
        hit <strong style={{color:C.black}}>Save Split</strong>, then re-run <strong style={{color:C.black}}>Repair Upsells</strong> for that date to apply.
      </div>
      {splitJobs.filter(sj => !dismissedJobIds.has(sj.jobId)).length === 0 ? (
        <div style={{ background:C.card, borderRadius:"12px", padding:"30px", textAlign:"center", color:C.muted, fontSize:"13px" }}>
          ✅ No unconfirmed split jobs — all good!
        </div>
      ) : splitJobs.filter(sj => !dismissedJobIds.has(sj.jobId)).map(sj => {
        const n = sj.rows.length;
        const defPct = Math.round(100 / n);
        const vals = sj.rows.map(r => parseFloat(getInput(sj.jobId, r.tech_id, defPct) || "0"));
        const total = vals.reduce((a, b) => a + b, 0);
        const ok = Math.abs(total - 100) <= 0.5;
        return (
          <div key={sj.jobId} style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid #f59e0b`, borderRadius:"12px", padding:"18px", display:"flex", flexDirection:"column", gap:"12px" }}>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
              <div>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"13px", color:C.muted, letterSpacing:"1px" }}>...{sj.jobId.slice(-12)}</div>
                {sj.customerName && (
                  <div style={{ fontWeight:"700", fontSize:"15px", color:C.black, marginTop:"1px" }}>{sj.customerName}</div>
                )}
                <div style={{ fontSize:"13px", color:C.muted, marginTop:"1px" }}>{sj.date}</div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:C.green }}>${(sj.totalRevenue + sj.totalTips).toFixed(2)}</div>
                <div style={{ fontSize:"11px", color:C.muted }}>${sj.totalRevenue.toFixed(2)} rev{sj.totalTips > 0 ? ` + $${sj.totalTips.toFixed(2)} tip` : ""}</div>
              </div>
            </div>
            <div style={{ fontSize:"11px", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", textTransform:"uppercase" }}>Revenue Split</div>
            {sj.rows.map((r, i) => {
              const tech = techById[r.tech_id];
              return (
                <div key={r.tech_id} style={{ display:"grid", gridTemplateColumns:"1fr 70px 16px", gap:"8px", alignItems:"center" }}>
                  <div style={{ fontSize:"13px", color:C.black, fontWeight:"600" }}>{tech?.name || r.tech_id.slice(0, 8)}</div>
                  <input
                    type="number" min="0" max="100" step="0.5"
                    value={getInput(sj.jobId, r.tech_id, defPct)}
                    onChange={e => setInput(sj.jobId, r.tech_id, e.target.value)}
                    style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"6px 8px", borderRadius:"8px", fontSize:"13px", textAlign:"center", width:"100%", boxSizing:"border-box" }}
                  />
                  <div style={{ fontSize:"12px", color:C.muted }}>%</div>
                </div>
              );
            })}
            {sj.totalUpsells > 0 && (
              <div style={{ borderTop:`1px solid ${C.border}`, paddingTop:"12px", display:"flex", flexDirection:"column", gap:"8px" }}>
                <div style={{ fontSize:"11px", color:"#f59e0b", fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", textTransform:"uppercase" }}>
                  Upsell Credit — ${(+sj.totalUpsells).toFixed(2)} total
                </div>
                <select
                  value={upsellAttrib[sj.jobId] || ""}
                  onChange={e => setUpsellAttrib(prev => ({...prev, [sj.jobId]: e.target.value}))}
                  style={{ background:C.cardLt, border:`1px solid #f59e0b`, color:C.black, padding:"8px 10px", borderRadius:"8px", fontSize:"13px", width:"100%", fontFamily:"'Barlow',sans-serif" }}
                >
                  <option value="">— Who sold this upsell? —</option>
                  {sj.rows.map(r => {
                    const t = techById[r.tech_id];
                    return <option key={r.tech_id} value={r.tech_id}>{t?.name || r.tech_id.slice(0,8)}</option>;
                  })}
                </select>
                {!upsellAttrib[sj.jobId] && (
                  <div style={{ fontSize:"11px", color:"#f59e0b" }}>⚠ Not set — will split by revenue % until confirmed</div>
                )}
              </div>
            )}
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <div style={{ fontSize:"12px", color: ok ? C.green : "#ef4444", fontWeight:"700" }}>
                Total: {total.toFixed(1)}% {ok ? "✓" : "— must equal 100%"}
              </div>
              {(() => {
                const rowSaving = savingJobId === sj.jobId;
                const rowDisabled = rowSaving || !ok;
                return (
                  <button
                    onClick={() => saveSplit(sj)}
                    disabled={rowDisabled}
                    style={{ background: rowDisabled ? "#333" : "#f59e0b", border:"none", color: rowDisabled ? "#666" : C.black, padding:"8px 20px", borderRadius:"10px", cursor: rowDisabled ? "not-allowed" : "pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"12px", letterSpacing:"1.5px", textTransform:"uppercase" }}
                  >{rowSaving ? "Applying..." : "Save & Apply"}</button>
                );
              })()}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── UPSELL AUDIT ─────────────────────────────────────────────────────────────
// Surfaces upsells.note (the raw HCP line-item text) so totals can be cross-checked
// against HCP's own "Additional Upgrades" report. Joins client-side against the
// already-loaded `jobs` prop by hcp_job_id — no extra fetch needed.
function UpsellAuditTab({ techs, upsells, jobs }) {
  const monthStart = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-01`; })();
  const today = new Date().toISOString().split("T")[0];
  const [dateFrom, setDateFrom] = useState(monthStart);
  const [dateTo, setDateTo] = useState(today);
  const [techFilter, setTechFilter] = useState("");
  const [sortKey, setSortKey] = useState("date");
  const [sortDir, setSortDir] = useState("desc");

  const techById = Object.fromEntries(techs.map(t => [t.id, t]));

  const jobByHcpId = {};
  jobs.forEach(j => { if (j.hcp_job_id && !jobByHcpId[j.hcp_job_id]) jobByHcpId[j.hcp_job_id] = j; });

  const rows = upsells.map(u => {
    const job = u.hcp_job_id ? jobByHcpId[u.hcp_job_id] : null;
    const noteText = (u.note || "").trim();
    return {
      id: u.id,
      techId: u.tech_id,
      hcpJobId: u.hcp_job_id || null,
      date: job?.job_date || u.week_key || null,
      customerName: job?.customer_name || null,
      amount: u.amount || 0,
      note: noteText,
      matched: !!job,
      flagged: !job || !noteText,
    };
  });

  const filtered = rows.filter(r => {
    if (techFilter && r.techId !== techFilter) return false;
    if (dateFrom && (!r.date || r.date < dateFrom)) return false;
    if (dateTo && (!r.date || r.date > dateTo)) return false;
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    let av, bv;
    if (sortKey === "tech") { av = techById[a.techId]?.name || ""; bv = techById[b.techId]?.name || ""; }
    else if (sortKey === "customer") { av = a.customerName || ""; bv = b.customerName || ""; }
    else if (sortKey === "amount") { av = a.amount; bv = b.amount; }
    else { av = a.date || ""; bv = b.date || ""; }
    if (av < bv) return sortDir === "asc" ? -1 : 1;
    if (av > bv) return sortDir === "asc" ? 1 : -1;
    return 0;
  });

  const total = filtered.reduce((s, r) => s + r.amount, 0);
  const flaggedCount = filtered.filter(r => r.flagged).length;

  function toggleSort(key) {
    if (sortKey === key) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortKey(key); setSortDir("desc"); }
  }

  const sel = (val) => ({ background:C.cardLt, border:`1px solid ${C.border}`, color:val?C.black:C.muted, padding:"8px 12px", borderRadius:"8px", fontSize:"13px", fontFamily:"'Barlow',sans-serif", cursor:"pointer" });
  const dateInp = { background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"8px 12px", borderRadius:"8px", fontSize:"13px", fontFamily:"'Barlow',sans-serif" };
  const SORT_COLS = [ { key:"date", label:"Date" }, { key:"tech", label:"Tech" }, { key:"customer", label:"Customer" }, { key:"amount", label:"Amount" } ];
  const thStyle = { padding:"8px 12px", textAlign:"left", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", whiteSpace:"nowrap", borderBottom:`1px solid ${C.border}` };
  const sortableTh = (c) => (
    <th key={c.key} onClick={()=>toggleSort(c.key)} style={{ ...thStyle, cursor:"pointer", userSelect:"none" }}>
      {c.label}{sortKey===c.key?(sortDir==="asc"?" ▲":" ▼"):""}
    </th>
  );

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.orange}`, borderRadius:"12px", padding:"16px 18px", display:"flex", flexDirection:"column", gap:"12px" }}>
        <Label color={C.orange}>🔍 Upsell Audit</Label>
        <div style={{ fontSize:"12px", color:C.muted }}>Cross-check upsell line items against HCP's "Additional Upgrades" report. Rows with a red border have no matching job or no line-item text — check those first for discrepancies.</div>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:"10px" }}>
          <input type="date" value={dateFrom} onChange={e=>setDateFrom(e.target.value)} style={dateInp}/>
          <input type="date" value={dateTo} onChange={e=>setDateTo(e.target.value)} style={dateInp}/>
          <select value={techFilter} onChange={e=>setTechFilter(e.target.value)} style={sel(techFilter)}>
            <option value="">— All Techs —</option>
            {techs.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>
      </div>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.green}`, borderRadius:"12px", padding:"16px 18px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div>
          <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>Total Upsells — Active Filters</div>
          <div style={{ fontSize:"11px", color:C.muted, marginTop:"2px" }}>{filtered.length} row{filtered.length===1?"":"s"}{flaggedCount>0?` · ${flaggedCount} flagged`:""}</div>
        </div>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"28px", color:C.green }}>${total.toFixed(2)}</div>
      </div>

      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden" }}>
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"12px", fontFamily:"'Barlow',sans-serif" }}>
            <thead>
              <tr style={{ background:C.cardLt }}>
                {sortableTh(SORT_COLS[0])}
                <th style={thStyle}>Job ID</th>
                {SORT_COLS.slice(1).map(sortableTh)}
                <th style={{ padding:"8px 12px", textAlign:"left", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", borderBottom:`1px solid ${C.border}` }}>Line Items</th>
              </tr>
            </thead>
            <tbody>
              {sorted.length===0&&(
                <tr><td colSpan={6} style={{ padding:"20px", textAlign:"center", color:C.muted }}>No upsells in this range.</td></tr>
              )}
              {sorted.map((r,i)=>(
                <tr key={r.id} style={{ background: r.flagged ? "#ef444414" : (i%2===0?C.cardLt:C.card) }}>
                  <td style={{ padding:"8px 12px", color:C.muted, whiteSpace:"nowrap", borderBottom:`1px solid ${C.border}`, borderLeft:`3px solid ${r.flagged?"#ef4444":"transparent"}` }}>{r.date||"—"}</td>
                  <td style={{ padding:"8px 12px", color:C.muted, whiteSpace:"nowrap", borderBottom:`1px solid ${C.border}`, fontFamily:"'SF Mono',Consolas,monospace", fontSize:"10px", userSelect:"text", cursor:"text" }}>{r.hcpJobId||"—"}</td>
                  <td style={{ padding:"8px 12px", color:C.black, whiteSpace:"nowrap", borderBottom:`1px solid ${C.border}` }}>{techById[r.techId]?.name||"Unknown"}{techById[r.techId]?.is_active===false&&<ArchivedTag/>}</td>
                  <td style={{ padding:"8px 12px", color: r.customerName?C.black:"#ef4444", whiteSpace:"nowrap", borderBottom:`1px solid ${C.border}` }}>{r.customerName||(r.matched?"—":"No job match")}</td>
                  <td style={{ padding:"8px 12px", color:C.green, fontWeight:"700", whiteSpace:"nowrap", borderBottom:`1px solid ${C.border}` }}>${r.amount.toFixed(2)}</td>
                  <td style={{ padding:"8px 12px", color: r.note?C.black:"#ef4444", borderBottom:`1px solid ${C.border}` }}>{r.note||"⚠ No line-item note"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── TECH MATCHING ────────────────────────────────────────────────────────────
// Reviews unmatched_hcp_employees (written daily by hcp-tech-match-check.js):
// HCP employee names with no exact match in the techs table, whose revenue/
// tips/upsells are silently being skipped by every hcp-*-sync function.
function TechMatchAdmin({ unmatchedTechs, refreshAll, showToast }) {
  const [busyName, setBusyName] = useState(null);

  async function ignoreName(hcpName) {
    setBusyName(hcpName);
    try {
      await sb("ignored_hcp_names", { method:"POST", body:JSON.stringify({ hcp_name:hcpName, note:"Ignored from Tech Matching admin panel" }) });
      await refreshAll();
      showToast(`"${hcpName}" won't be flagged again`);
    } catch (err) {
      showToast("⚠ " + err.message, false);
    } finally {
      setBusyName(null);
    }
  }

  function copyName(hcpName) {
    try {
      navigator.clipboard.writeText(hcpName);
      showToast(`Copied "${hcpName}" — paste it exactly into Add Tech`);
    } catch {
      showToast(hcpName);
    }
  }

  return (
    <div>
      <div style={{ fontSize:"13px", color:C.muted, marginBottom:"16px", lineHeight:"1.5" }}>
        These names showed up on an HCP job in the last ~2 weeks but don't exactly match any name in the tech roster — checked automatically every morning. Fix a typo in the matching tech's name, or add a new tech with this exact name (Copy Name, then Add Tech), and it'll clear itself off this list within a day. If a name will never be a paid tech in this app (an office account, a one-off contractor), use Ignore instead.
      </div>
      {unmatchedTechs.length === 0 && (
        <div style={{ padding:"32px 16px", textAlign:"center", color:C.muted, fontSize:"14px" }}>Nothing unmatched right now.</div>
      )}
      {unmatchedTechs.map(row => (
        <div key={row.hcp_name} style={{ background:"#fff", border:`1px solid ${C.border}`, borderRadius:"10px", padding:"12px 16px", marginBottom:"10px", display:"flex", justifyContent:"space-between", alignItems:"center", gap:"12px", flexWrap:"wrap" }}>
          <div>
            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"15px", color:C.black }}>{row.hcp_name}</div>
            <div style={{ fontSize:"12px", color:C.muted, marginTop:"2px" }}>
              {row.job_count} job{row.job_count!==1?"s":""} · {row.first_seen&&fmtShortDate(row.first_seen)}–{row.last_seen&&fmtShortDate(row.last_seen)}
            </div>
          </div>
          <div style={{ display:"flex", gap:"8px", flexShrink:0 }}>
            <button onClick={()=>copyName(row.hcp_name)} style={{ background:"#fff", border:`1px solid ${C.border}`, borderRadius:"8px", padding:"8px 14px", cursor:"pointer", fontSize:"12px", fontWeight:"700", color:C.black }}>Copy Name</button>
            <button disabled={busyName===row.hcp_name} onClick={()=>ignoreName(row.hcp_name)} style={{ background:"#f0f0f0", border:"none", borderRadius:"8px", padding:"8px 14px", cursor:"pointer", fontSize:"12px", fontWeight:"700", color:C.black, opacity:busyName===row.hcp_name?0.6:1 }}>
              {busyName===row.hcp_name ? "..." : "Ignore"}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── ADMIN PANEL ──────────────────────────────────────────────────────────────
function AdminPanel({ techs, upsells, switchovers, reviews, callbacks, rideAlongs, schedules, quota, setQuota, jobs, timeEntries=[], tipEntries=[], pendingSplits=[], unmatchedTechs=[], onLogout, refreshAll }) {
  // Live-standings views (Leaderboard, Journey Map) should only show active
  // techs, matching what the tech-facing app already does — archived techs
  // stay fully visible in Reports/Payroll/Upsell Audit where historical
  // accuracy matters instead. Same reasoning excludes owner/admin accounts
  // (title:"owner") from these standings views -- they're tracked for
  // revenue completeness (Reports/Repair Revenue/Upsell Totals all still use
  // the raw `techs` prop, unaffected by this filter) but shouldn't appear in
  // gamified rankings.
  const activeTechs = techs.filter(t => t.is_active !== false && t.title !== "owner");
  const [tab, setTab] = useState("upsells");
  const [menuOpen, setMenuOpen] = useState(false);
  const [awardForm, setAwardForm] = useState({techId:"",badgeId:""});
  const [addForm, setAddForm] = useState({name:"",pin:"",avatar:"",start_date:"",commission_rate:27});
  const [swForm, setSwForm] = useState({techId:"",planId:""});
  const [editingSwId, setEditingSwId] = useState(null);
  const [editSwForm, setEditSwForm] = useState({date:"",planId:""});
  const [swRangePreset, setSwRangePreset] = useState("wtd");
  const [swCStart, setSwCStart] = useState("");
  const [swCEnd, setSwCEnd] = useState("");
  const [reviewForm, setReviewForm] = useState({});
  const [cbForm, setCbForm] = useState({techId:"",reason:""});
  const [toast, setToast] = useState(null);
  const [saving, setSaving] = useState(false);

  const showToast=(msg,ok=true)=>{ setToast({msg,ok}); setTimeout(()=>setToast(null),3000); };
  async function saveQuota(newQuota) {
    setSaving(true);
    try {
      const existing = await sb("settings?key=eq.quota&select=id").catch(()=>[]);
      if (existing&&existing.length>0) {
        await sb(`settings?id=eq.${existing[0].id}`,{method:"PATCH",body:JSON.stringify({value:JSON.stringify(newQuota)}),prefer:"return=minimal"});
      } else {
        await sb("settings",{method:"POST",body:JSON.stringify({key:"quota",value:JSON.stringify(newQuota)})});
      }
      setQuota(newQuota);
      showToast("✅ Quota saved — all devices updated!");
    } catch(e) { showToast("Error saving quota: "+e.message,false); }
    setSaving(false);
  }

  async function awardBadge() {
    if (!awardForm.techId||!awardForm.badgeId) return showToast("Select a tech and badge",false);
    const tech=techs.find(t=>t.id===awardForm.techId);
    if (tech.badges.includes(awardForm.badgeId)) return showToast(`${tech.name} already has this badge`,false);
    setSaving(true);
    try { await sb(`techs?id=eq.${tech.id}`,{method:"PATCH",body:JSON.stringify({badges:[...tech.badges,awardForm.badgeId]}),prefer:"return=minimal"}); await refreshAll(); showToast(`✅ Badge awarded to ${tech.name}!`); setAwardForm({techId:"",badgeId:""}); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function revokeBadge(techId,badgeId) {
    const tech=techs.find(t=>t.id===techId); setSaving(true);
    try { await sb(`techs?id=eq.${techId}`,{method:"PATCH",body:JSON.stringify({badges:tech.badges.filter(b=>b!==badgeId)}),prefer:"return=minimal"}); await refreshAll(); showToast("Badge removed"); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function addTech() {
    if (!addForm.name||!addForm.pin||addForm.pin.length!==4) return showToast("Name + 4-digit PIN required",false);
    if (techs.find(t=>t.pin===addForm.pin)) return showToast("PIN already in use",false);
    setSaving(true);
    try { const avatar=addForm.avatar||addForm.name.split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,2); const res=await sb("techs",{method:"POST",body:JSON.stringify({name:addForm.name,pin:addForm.pin,avatar,badges:["day_one"],start_date:addForm.start_date||null,commission_rate:parseInt(addForm.commission_rate)||27,title:addForm.title||"detail_apprentice"})}); if(res&&res[0]&&addForm.start_date)await scheduleCheckins(res[0].id,addForm.start_date).catch(()=>{}); await refreshAll(); showToast(`✅ ${addForm.name} added!`); setAddForm({name:"",pin:"",avatar:"",start_date:"",commission_rate:27,title:"detail_apprentice"}); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function updateStartDate(techId,date) {
    try { await sb(`techs?id=eq.${techId}`,{method:"PATCH",body:JSON.stringify({start_date:date||null}),prefer:"return=minimal"}); if(date)await scheduleCheckins(techId,date).catch(()=>{}); await refreshAll(); showToast("✅ Start date saved!"); }
    catch(e){ showToast("Error: "+e.message,false); }
  }
  async function archiveTech(tech) {
    const confirmed = window.confirm(`Archive ${tech.name}?\n\nThey'll be removed from the leaderboard but their revenue and job history stay in the system. You can reactivate them anytime.`);
    if (!confirmed) return;
    setSaving(true);
    try {
      await sb(`techs?id=eq.${tech.id}`,{method:"PATCH",body:JSON.stringify({is_active:false}),prefer:"return=minimal"});
      await refreshAll();
      showToast(`${tech.name} archived`);
    } catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function reactivateTech(tech) {
    setSaving(true);
    try {
      await sb(`techs?id=eq.${tech.id}`,{method:"PATCH",body:JSON.stringify({is_active:true}),prefer:"return=minimal"});
      await refreshAll();
      showToast(`✅ ${tech.name} reactivated`);
    } catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function logSwitchover() {
    if (!swForm.techId||!swForm.planId) return showToast("Select a tech and plan",false);
    setSaving(true);
    try { await sb("switchovers",{method:"POST",body:JSON.stringify({tech_id:swForm.techId,week_key:getWeekKey(),plan_id:swForm.planId})}); await refreshAll(); showToast(`✅ Switchover logged!`); setSwForm({techId:"",planId:""}); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  function startEditSwitchover(s) {
    setEditingSwId(s.id);
    setEditSwForm({ date: s.week_key, planId: s.plan_id });
  }
  async function saveEditSwitchover() {
    if (!editSwForm.date) return showToast("Pick a date",false);
    setSaving(true);
    try {
      const body = { week_key: dateToWeekKey(editSwForm.date), plan_id: editSwForm.planId };
      await sb(`switchovers?id=eq.${editingSwId}`,{method:"PATCH",body:JSON.stringify(body),prefer:"return=minimal"});
      await refreshAll();
      setEditingSwId(null);
      showToast("✅ Switchover updated");
    } catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function deleteSwitchoverEntry(id) {
    if (!window.confirm("Delete this switchover?")) return;
    setSaving(true);
    try { await sb(`switchovers?id=eq.${id}`,{method:"DELETE",prefer:"return=minimal"}); await refreshAll(); setEditingSwId(null); showToast("Switchover deleted"); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function logCallback() {
    if (!cbForm.techId) return showToast("Select a tech",false);
    const tech = techs.find(t=>t.id===cbForm.techId);
    setSaving(true);
    try {
      await sb("callbacks",{method:"POST",body:JSON.stringify({tech_id:cbForm.techId,reason:cbForm.reason||""})});
      await refreshAll();
      showToast(`📞 Callback logged for ${tech?.name} — ${Math.abs(CALLBACK_PTS)} pts deducted`);
      setCbForm({techId:"",reason:""});
    } catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function deleteCallback(id) {
    setSaving(true);
    try { await sb(`callbacks?id=eq.${id}`,{method:"DELETE",prefer:"return=minimal"}); await refreshAll(); showToast("Callback removed"); }
    catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function toggleTeamLead(tech) {
    setSaving(true);
    try {
      const newVal = !tech.is_lead;
      await sb(`techs?id=eq.${tech.id}`,{method:"PATCH",body:JSON.stringify({is_lead:newVal}),prefer:"return=minimal"});
      // If removing lead status, unassign all their team members
      if (!newVal) {
        const members = techs.filter(t=>t.team_lead_id===tech.id);
        await Promise.all(members.map(m=>sb(`techs?id=eq.${m.id}`,{method:"PATCH",body:JSON.stringify({team_lead_id:null}),prefer:"return=minimal"})));
      }
      await refreshAll();
      showToast(newVal?`✅ ${tech.name} is now a Team Lead`:`${tech.name} removed as Team Lead`);
    } catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function assignTeamMember(member, leadId) {
    setSaving(true);
    try {
      await sb(`techs?id=eq.${member.id}`,{method:"PATCH",body:JSON.stringify({team_lead_id:leadId||null}),prefer:"return=minimal"});
      await refreshAll();
      showToast(leadId?`✅ ${member.name} added to team`:`${member.name} removed from team`);
    } catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }
  async function saveReviews() {
    const mk=getMonthKey(); setSaving(true);
    try {
      for (const t of techs) { const val=parseInt(reviewForm[t.id]); if(isNaN(val)||val<=0)continue; const existing=await sb(`reviews?tech_id=eq.${t.id}&month_key=eq.${mk}&select=id`); if(existing&&existing.length>0)await sb(`reviews?id=eq.${existing[0].id}`,{method:"PATCH",body:JSON.stringify({count:val}),prefer:"return=minimal"}); else await sb("reviews",{method:"POST",body:JSON.stringify({tech_id:t.id,month_key:mk,count:val})}); }
      await refreshAll(); showToast("✅ Reviews saved!"); setReviewForm({});
    } catch(e){ showToast("Error: "+e.message,false); }
    setSaving(false);
  }

  const wk=getWeekKey(), mk=getMonthKey();
  const wkUp={}; upsells.filter(u=>u.week_key===wk).forEach(u=>{wkUp[u.tech_id]=u.amount;});
  const mkRev={}; reviews.filter(r=>r.month_key===mk).forEach(r=>{mkRev[r.tech_id]=r.count;});

  const inp={ background:C.white, border:`1px solid ${C.border}`, color:C.black, padding:"10px 14px", borderRadius:"8px", fontSize:"14px", fontFamily:"'Barlow',sans-serif", width:"100%", boxSizing:"border-box" };
  const sel=(val)=>({...inp, color:val?C.black:C.muted});
  const btn=(color)=>({ background:saving?C.border:color||C.blue, border:"none", color:C.black, padding:"13px", borderRadius:"24px", cursor:saving?"not-allowed":"pointer", fontSize:"13px", fontWeight:"900", fontStyle:"italic", letterSpacing:"2px", fontFamily:"'Barlow Condensed',sans-serif", width:"100%", textTransform:"uppercase" });

  const adminNavSections = [
    { label:"Analytics", items:[
      ["reports","📊","Reports"],
      ["leaderboard","🏆","Leaderboard"],
      ["payroll","💵","Payroll"],
      ["operations","📈","Operations Progress"],
    ]},
    { label:"Team Activity", items:[
      ["upsells","💰","Upsells"],
      ["reviews","⭐","Reviews"],
      ["switchovers","🔄","Switchovers"],
      ["timesheet","🕒","Time Sheet"],
      ["tips","💵","Log Tips"],
      ["callbacks","📞","Callbacks"],
      ["ridealong","🚗","Ride-Alongs"],
    ]},
    { label:"Journey", items:[
      ["journey","🗺️","Journey Map"],
      ["incentive","🎁","Rewards"],
      ["award","🥇","Award Badge"],
    ]},
    { label:"HCP Sync", items:[
      ["splits","✂️", pendingSplits.length > 0 ? `Split Jobs (${new Set(pendingSplits.map(r=>r.hcp_job_id)).size})` : "Split Jobs"],
      ["upsellaudit","🔍","Upsell Audit"],
      ["techmatch","🔗", unmatchedTechs.length > 0 ? `Tech Matching (${unmatchedTechs.length})` : "Tech Matching"],
    ]},
    { label:"Development", items:[
      ["development","📋","Development"],
    ]},
    { label:"Management", items:[
      ["add","➕","Add Tech"],
      ["manage","✏️","Manage"],
      ["teams","👥","Teams"],
      ["quota","📋","Quota"],
      ["delete","🗑️","Delete Tech"],
    ]},
  ];

  const adminTabLabel = adminNavSections.flatMap(s=>s.items).find(([id])=>id===tab)?.[2] || "Dashboard";

  return (
    <div style={{ minHeight:"100vh", background:"#f0f8ff" }}>
      <style>{GS}</style>
      <SideNav sections={adminNavSections} active={tab} setActive={setTab} open={menuOpen} onClose={()=>setMenuOpen(false)} name="Admin Panel" role="Skylo Standard Board"/>
      <Header left={<HamburgerBtn onClick={()=>setMenuOpen(true)}/>} title={adminTabLabel} right={<LogoutBtn onLogout={onLogout}/>}/>
      <div style={{ padding:"20px", maxWidth:"700px", margin:"0 auto" }}>

        {pendingSplits.length > 0 && tab !== "splits" && (()=>{
          const count = new Set(pendingSplits.map(r => r.hcp_job_id)).size;
          return (
            <div style={{ background:"rgba(245,158,11,0.1)", border:"1px solid #f59e0b", borderRadius:"10px", padding:"12px 16px", marginBottom:"16px", display:"flex", justifyContent:"space-between", alignItems:"center", gap:"12px" }}>
              <div>
                <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:"#f59e0b", letterSpacing:"0.5px" }}>
                  ⚠ {count} job{count !== 1 ? "s" : ""} need split confirmation
                </div>
                <div style={{ fontSize:"12px", color:C.muted, marginTop:"2px" }}>
                  Revenue and upsell splits may be incorrect until reviewed.
                </div>
              </div>
              <button
                onClick={() => setTab("splits")}
                style={{ background:"#f59e0b", border:"none", color:C.black, padding:"8px 18px", borderRadius:"8px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"12px", letterSpacing:"1.5px", textTransform:"uppercase", whiteSpace:"nowrap", flexShrink:0 }}
              >Review Now</button>
            </div>
          );
        })()}

        {unmatchedTechs.length > 0 && tab !== "techmatch" && (
          <div style={{ background:"rgba(239,68,68,0.08)", border:"1px solid #ef4444", borderRadius:"10px", padding:"12px 16px", marginBottom:"16px", display:"flex", justifyContent:"space-between", alignItems:"center", gap:"12px" }}>
            <div>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:"#ef4444", letterSpacing:"0.5px" }}>
                ⚠ {unmatchedTechs.length} HCP name{unmatchedTechs.length !== 1 ? "s" : ""} not matched to a tech
              </div>
              <div style={{ fontSize:"12px", color:C.muted, marginTop:"2px" }}>
                Their revenue, tips, and upsells are being silently skipped until this is fixed.
              </div>
            </div>
            <button
              onClick={() => setTab("techmatch")}
              style={{ background:"#ef4444", border:"none", color:"#fff", padding:"8px 18px", borderRadius:"8px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"12px", letterSpacing:"1.5px", textTransform:"uppercase", whiteSpace:"nowrap", flexShrink:0 }}
            >Review Now</button>
          </div>
        )}

        {tab==="splits"&&(
          <SplitJobsAdmin techs={techs} pendingSplits={pendingSplits} refreshAll={refreshAll} showToast={showToast}/>
        )}

        {tab==="upsellaudit"&&(
          <UpsellAuditTab techs={techs} upsells={upsells} jobs={jobs}/>
        )}

        {tab==="techmatch"&&(
          <TechMatchAdmin unmatchedTechs={unmatchedTechs} refreshAll={refreshAll} showToast={showToast}/>
        )}

        {tab==="development"&&(
          <DevelopmentTab techs={techs} rideAlongs={rideAlongs||[]} refreshAll={refreshAll} showToast={showToast}/>
        )}

        {tab==="upsells"&&(
          <AdminUpsellEntry techs={techs} refreshAll={refreshAll} showToast={showToast} upsells={upsells} jobs={jobs||[]}/>
        )}

        {tab==="reviews"&&(
          <AdminReviewEntry techs={techs} reviews={reviews} saving={saving} setSaving={setSaving} refreshAll={refreshAll} showToast={showToast}/>
        )}
        {tab==="switchovers"&&(
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"12px" }}>
            <Label color={C.purple}>Log a Switchover · {formatWeekLabel(wk)}</Label>
            <div style={{ background:C.cardLt, borderRadius:"8px", padding:"8px 12px", fontSize:"12px", color:C.muted }}>
              {formatLastEntered(mostRecentTimestamp(switchovers)) ? (
                <>Last entered: <strong style={{ color:C.black }}>{formatLastEntered(mostRecentTimestamp(switchovers))}</strong> — everything before that is already logged.</>
              ) : "No switchovers logged yet."}
            </div>
            <select value={swForm.techId} onChange={e=>setSwForm(f=>({...f,techId:e.target.value}))} style={sel(swForm.techId)}>
              <option value="">— Select Tech —</option>
              {techs.filter(t=>t.is_active!==false).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            <select value={swForm.planId} onChange={e=>setSwForm(f=>({...f,planId:e.target.value}))} style={sel(swForm.planId)}>
              <option value="">— Select Plan —</option>
              {SERVICE_PLANS.map(p=><option key={p.id} value={p.id}>{p.label} ({p.freq}) · +{p.pts}pts · ${p.ltv.toLocaleString()}/yr LTV</option>)}
            </select>
            <button onClick={logSwitchover} disabled={saving} style={btn(C.purple)}>{saving?"Saving...":"Log Switchover"}</button>
          </div>
        )}
        {tab==="switchovers"&&(() => {
          const { start: swStart, end: swEnd } = getDateRangeBounds(swRangePreset, swCStart, swCEnd);
          const swFromWk = dateToWeekKey(swStart);
          const swInRange = switchovers.filter(s => s.week_key >= swFromWk && s.week_key <= swEnd);
          const swByTech = {};
          swInRange.forEach(s => {
            if (!swByTech[s.tech_id]) swByTech[s.tech_id] = { total: 0, byPlan: {} };
            swByTech[s.tech_id].total++;
            swByTech[s.tech_id].byPlan[s.plan_id] = (swByTech[s.tech_id].byPlan[s.plan_id] || 0) + 1;
          });
          const swRanked = techs
            .map(t => ({ ...t, total: swByTech[t.id]?.total || 0, byPlan: swByTech[t.id]?.byPlan || {} }))
            .filter(t => t.total > 0)
            .sort((a, b) => b.total - a.total);
          return (
            <>
              <div style={{ marginTop:"16px" }}>
                <DateRangePicker label="📅 Date Range" color={C.purple} preset={swRangePreset} setPreset={setSwRangePreset} customStart={swCStart} setCustomStart={setSwCStart} customEnd={swCEnd} setCustomEnd={setSwCEnd}>
                  <div style={{ fontSize:"11px", color:C.purple, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", marginTop:"8px" }}>
                    {swStart} → {swEnd} · matched by week (switchovers are logged by week, not exact day)
                  </div>
                </DateRangePicker>
              </div>

              <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.purple}`, borderRadius:"12px", overflow:"hidden", marginTop:"16px" }}>
                <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
                  <Label color={C.purple}>🔄 Switchovers by Plan Type · {swStart} → {swEnd}</Label>
                </div>
                <div style={{ overflowX:"auto" }}>
                  <table style={{ width:"100%", borderCollapse:"collapse", fontSize:"13px" }}>
                    <thead>
                      <tr>
                        <th style={{ padding:"8px 18px", textAlign:"left", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"11px", borderBottom:`1px solid ${C.border}`, whiteSpace:"nowrap" }}>TECH</th>
                        <th style={{ padding:"8px 18px", textAlign:"left", color:C.muted, fontWeight:"700", letterSpacing:"1px", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"11px", borderBottom:`1px solid ${C.border}` }}>BREAKDOWN</th>
                      </tr>
                    </thead>
                    <tbody>
                      {swRanked.length===0 && (
                        <tr><td colSpan={2} style={{ padding:"16px 18px", color:C.muted, textAlign:"center" }}>No switchovers logged in this range.</td></tr>
                      )}
                      {swRanked.map((t,i)=>{
                        const breakdown = Object.entries(t.byPlan).sort((a,b)=>b[1]-a[1]).map(([planId,count])=>`${count} ${PLAN_MAP[planId]?.label||planId}`).join(", ");
                        return (
                          <tr key={t.id} style={{ borderBottom:`1px solid ${C.border}` }}>
                            <td style={{ padding:"10px 18px", color:C.black, fontWeight:"700", fontFamily:"'Barlow Condensed',sans-serif", whiteSpace:"nowrap" }}>{medal(i)} {t.name}</td>
                            <td style={{ padding:"10px 18px", color:C.black }}>{breakdown} <span style={{ color:C.muted, fontSize:"11px" }}>({t.total} total)</span></td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              <div style={{ background:C.card, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.purple}`, borderRadius:"12px", overflow:"hidden", marginTop:"16px" }}>
                <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
                  <Label color={C.purple}>Individual Entries · {swStart} → {swEnd}</Label>
                </div>
                <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"6px" }}>
                  {swInRange.length===0 && <div style={{ fontSize:"13px", color:C.muted }}>No switchover entries in this range.</div>}
                  {[...swInRange].sort((a,b)=>b.week_key.localeCompare(a.week_key)).map(s=>{
                    const tech=techs.find(t=>t.id===s.tech_id);
                    const plan=PLAN_MAP[s.plan_id];
                    const pc=PLAN_COLORS[s.plan_id]||C.muted;
                    return (
                      <div key={s.id} style={{ background:C.cardLt, borderRadius:"8px", padding:"10px 12px" }}>
                        {editingSwId===s.id ? (
                          <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
                            <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"14px", color:C.black }}>{tech?.name}</div>
                            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"8px" }}>
                              <div>
                                <div style={{ fontSize:"10px", color:C.muted, marginBottom:"4px" }}>Week (pick any day in it)</div>
                                <input type="date" value={editSwForm.date} onChange={e=>setEditSwForm(f=>({...f,date:e.target.value}))} style={{ background:C.card, border:`1px solid ${C.border}`, color:C.black, padding:"8px", borderRadius:"8px", fontSize:"13px", width:"100%", boxSizing:"border-box" }}/>
                              </div>
                              <div>
                                <div style={{ fontSize:"10px", color:C.muted, marginBottom:"4px" }}>Plan</div>
                                <select value={editSwForm.planId} onChange={e=>setEditSwForm(f=>({...f,planId:e.target.value}))} style={{ background:C.card, border:`1px solid ${C.border}`, color:C.black, padding:"8px", borderRadius:"8px", fontSize:"13px", width:"100%", boxSizing:"border-box" }}>
                                  {SERVICE_PLANS.map(p=><option key={p.id} value={p.id}>{p.label}</option>)}
                                </select>
                              </div>
                            </div>
                            <div style={{ fontSize:"11px", color:C.muted }}>Will be attributed to the week of {formatWeekLabel(dateToWeekKey(editSwForm.date||s.week_key))}</div>
                            <div style={{ display:"flex", gap:"8px" }}>
                              <button onClick={saveEditSwitchover} disabled={saving} style={{ flex:1, background:C.purple, border:"none", color:C.white, padding:"8px", borderRadius:"8px", cursor:"pointer", fontWeight:"700", fontSize:"12px" }}>Save</button>
                              <button onClick={()=>setEditingSwId(null)} style={{ background:"none", border:`1px solid ${C.border}`, color:C.muted, padding:"8px 14px", borderRadius:"8px", cursor:"pointer", fontSize:"12px" }}>Cancel</button>
                              <button onClick={()=>deleteSwitchoverEntry(s.id)} style={{ background:"none", border:"1px solid #ef4444", color:"#ef4444", padding:"8px 14px", borderRadius:"8px", cursor:"pointer", fontSize:"12px" }}>Delete</button>
                            </div>
                          </div>
                        ) : (
                          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:"12px" }}>
                            <div>
                              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"15px", color:C.black }}>{tech?.name}</div>
                              <div style={{ fontSize:"12px", color:C.muted }}>{formatWeekLabel(s.week_key)} · <span style={{ color:pc, fontWeight:"700" }}>{plan?.label||s.plan_id} · +{plan?.pts||0}pts</span></div>
                            </div>
                            <button onClick={()=>startEditSwitchover(s)} style={{ background:"none", border:`1px solid ${C.border}`, color:C.purple, padding:"4px 10px", borderRadius:"4px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px", flexShrink:0 }}>Edit</button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </>
          );
        })()}

        {tab==="timesheet"&&(
          <AdminTimeSheetTab techs={techs} timeEntries={timeEntries} refreshAll={refreshAll} showToast={showToast}/>
        )}

        {tab==="tips"&&(
          <AdminTipEntry techs={techs} tipEntries={tipEntries} refreshAll={refreshAll} showToast={showToast}/>
        )}

        {tab==="callbacks"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
            {/* Log a callback */}
            <div style={{ background:C.white, border:`2px solid #ef444444`, borderTop:`3px solid #ef4444`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"12px", boxShadow:"0 2px 8px rgba(239,68,68,0.08)" }}>
              <div>
                <Label color="#ef4444">📞 Log a Callback</Label>
                <div style={{ fontSize:"12px", color:C.muted, marginBottom:"4px" }}>Each callback deducts <strong style={{ color:"#ef4444" }}>{Math.abs(CALLBACK_PTS)} points</strong> — nearly a full week of work. Quality matters.</div>
              </div>
              <select value={cbForm.techId||""} onChange={e=>setCbForm(f=>({...f,techId:e.target.value}))} style={sel(cbForm?.techId)}>
                <option value="">— Select Tech —</option>
                {techs.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
              <input placeholder="Reason / job description (optional)" value={cbForm.reason||""} onChange={e=>setCbForm(f=>({...f,reason:e.target.value}))} style={inp}/>
              <button onClick={logCallback} disabled={saving} style={{ ...btn("#ef4444"), color:C.white }}>{saving?"Saving...":"Log Callback — Deduct Points"}</button>
            </div>

            {/* Callback history */}
            <div style={{ background:C.white, border:`1px solid ${C.border}`, borderRadius:"12px", overflow:"hidden", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
              <div style={{ padding:"14px 18px", borderBottom:`1px solid ${C.border}`, background:C.cardLt }}>
                <Label color="#ef4444">📋 Callback History</Label>
              </div>
              <div style={{ padding:"14px 18px", display:"flex", flexDirection:"column", gap:"8px" }}>
                {callbacks.length===0&&<div style={{ fontSize:"13px", color:C.muted }}>No callbacks logged yet. Keep it that way! 💪</div>}
                {callbacks.map(cb=>{
                  const tech = techs.find(t=>t.id===cb.tech_id);
                  return (
                    <div key={cb.id} style={{ background:`#ef444410`, border:`1px solid #ef444433`, borderLeft:`3px solid #ef4444`, borderRadius:"8px", padding:"12px 14px", display:"flex", justifyContent:"space-between", alignItems:"center", gap:"12px" }}>
                      <div>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"15px", color:C.black }}>{tech?.name||"Unknown"}</div>
                        <div style={{ fontSize:"11px", color:C.muted, marginTop:"2px" }}>{cb.reason||"No reason provided"} · {new Date(cb.created_at).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</div>
                      </div>
                      <div style={{ display:"flex", alignItems:"center", gap:"10px", flexShrink:0 }}>
                        <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"16px", color:"#ef4444" }}>{CALLBACK_PTS} pts</span>
                        <button onClick={()=>deleteCallback(cb.id)} disabled={saving} style={{ background:"none", border:`1px solid #ef4444`, color:"#ef4444", padding:"4px 10px", borderRadius:"6px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px" }}>DELETE</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Per-tech callback summary */}
            {callbacks.length>0&&(
              <div style={{ background:C.white, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px 18px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
                <Label color="#ef4444">📊 All-Time Callback Count</Label>
                <div style={{ display:"flex", flexDirection:"column", gap:"6px" }}>
                  {techs.map(t=>{
                    const count = callbacks.filter(c=>c.tech_id===t.id).length;
                    if (!count) return null;
                    return (
                      <div key={t.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                        <span style={{ fontSize:"13px", color:C.black, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{t.name}</span>
                        <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontSize:"14px", color:"#ef4444" }}>{count} callback{count>1?"s":""} · {count*Math.abs(CALLBACK_PTS)} pts lost</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}

        {tab==="award"&&(
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"12px" }}>
            <Label color={C.blue}>Award a Badge</Label>
            <select value={awardForm.techId} onChange={e=>setAwardForm(f=>({...f,techId:e.target.value}))} style={sel(awardForm.techId)}>
              <option value="">— Select Tech —</option>
              {techs.filter(t=>t.is_active!==false).map(t=><option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
            <select value={awardForm.badgeId} onChange={e=>setAwardForm(f=>({...f,badgeId:e.target.value}))} style={sel(awardForm.badgeId)}>
              <option value="">— Select Badge —</option>
              {ALL_BADGE_DEFS.map(b=><option key={b.id} value={b.id}>{b.icon} {b.name} ({b.pts>0?`+${b.pts} pts`:"Trophy"})</option>)}
            </select>
            <button onClick={awardBadge} disabled={saving} style={btn(C.blue)}>{saving?"Saving...":"Award Badge"}</button>
          </div>
        )}

        {tab==="add"&&(
          <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"20px", display:"flex", flexDirection:"column", gap:"12px" }}>
            <Label color={C.green}>Add New Tech</Label>
            <input placeholder="Full Name" value={addForm.name} onChange={e=>setAddForm(f=>({...f,name:e.target.value}))} style={inp}/>
            <input placeholder="4-Digit PIN" value={addForm.pin} maxLength={4} onChange={e=>setAddForm(f=>({...f,pin:e.target.value.replace(/\D/g,"")}))} style={inp}/>
            <input placeholder="Initials (optional)" value={addForm.avatar} maxLength={2} onChange={e=>setAddForm(f=>({...f,avatar:e.target.value.toUpperCase()}))} style={inp}/>
            <div>
              <div style={{ fontSize:"12px", color:C.muted, marginBottom:"6px" }}>Start Date</div>
              <input type="date" value={addForm.start_date} onChange={e=>setAddForm(f=>({...f,start_date:e.target.value}))} style={inp}/>
            </div>
            <div>
              <div style={{ fontSize:"12px", color:C.muted, marginBottom:"6px" }}>Title</div>
              <select value={addForm.title||"detail_apprentice"} onChange={e=>setAddForm(f=>({...f,title:e.target.value}))} style={inp}>
                {Object.entries(TITLE_LABELS).map(([val,label])=><option key={val} value={val}>{label}</option>)}
              </select>
            </div>
            <div>
              <div style={{ fontSize:"12px", color:C.muted, marginBottom:"6px" }}>Commission Rate</div>
              <select value={addForm.commission_rate} onChange={e=>setAddForm(f=>({...f,commission_rate:e.target.value}))} style={inp}>
                {[27,28,29,30,31,32].map(p=><option key={p} value={p}>{p}%</option>)}
              </select>
            </div>
            <button onClick={addTech} disabled={saving} style={btn(C.green)}>{saving?"Saving...":"Add Tech"}</button>
          </div>
        )}

        {tab==="manage"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:"10px" }}>
            {techs.filter(t=>t.is_active!==false).map(t=>(
              <div key={t.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:"12px", padding:"16px 18px" }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"10px" }}>
                  <div style={{ display:"flex", flexDirection:"column", gap:"2px" }}>
                    <input
                      defaultValue={t.name}
                      onBlur={async e=>{
                        const val = e.target.value.trim();
                        if (!val || val===t.name) return;
                        await sb(`techs?id=eq.${t.id}`,{method:"PATCH",body:JSON.stringify({name:val}),prefer:"return=minimal"});
                        await refreshAll();
                        showToast(`✅ Name updated to ${val}`);
                      }}
                      style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"17px", color:C.black, background:"transparent", border:"none", borderBottom:`1px dashed ${C.border}`, padding:"2px 4px", width:"200px", cursor:"text" }}
                    />
                    <span style={{ fontSize:"11px", color:C.purple, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", paddingLeft:"4px" }}>{TITLE_LABELS[t.title] || "Detail Apprentice"}</span>
                  </div>
                  <span style={{ fontSize:"12px", color:C.muted, fontFamily:"'Barlow Condensed',sans-serif" }}>PIN: {t.pin}</span>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"10px" }}>
                  <span style={{ fontSize:"12px", color:C.muted }}>Start date:</span>
                  <input type="date" defaultValue={t.start_date||""} onBlur={e=>updateStartDate(t.id,e.target.value)} style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"4px 8px", borderRadius:"4px", fontSize:"12px", fontFamily:"'Barlow Condensed',sans-serif" }}/>
                  {t.start_date&&<span style={{ fontSize:"12px", color:C.blue, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{formatTenure(t.start_date)}</span>}
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"10px" }}>
                  <span style={{ fontSize:"12px", color:C.muted }}>Title:</span>
                  <select defaultValue={t.title||"detail_apprentice"}
                    onChange={async e=>{
                      await sb(`techs?id=eq.${t.id}`,{method:"PATCH",body:JSON.stringify({title:e.target.value}),prefer:"return=minimal"});
                      await refreshAll(); showToast(`✅ Title saved for ${t.name}`);
                    }}
                    style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.purple, padding:"4px 8px", borderRadius:"4px", fontSize:"13px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", cursor:"pointer" }}>
                    {Object.entries(TITLE_LABELS).map(([val,label])=><option key={val} value={val}>{label}</option>)}
                  </select>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:"10px", marginBottom:"10px" }}>
                  <span style={{ fontSize:"12px", color:C.muted }}>Commission rate:</span>
                  <select defaultValue={t.commission_rate||27}
                    onChange={async e=>{
                      const val=parseInt(e.target.value);
                      await sb(`techs?id=eq.${t.id}`,{method:"PATCH",body:JSON.stringify({commission_rate:val}),prefer:"return=minimal"});
                      await refreshAll(); showToast(`✅ Rate saved for ${t.name}`);
                    }}
                    style={{ background:C.cardLt, border:`1px solid ${C.border}`, color:C.black, padding:"4px 8px", borderRadius:"4px", fontSize:"14px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", cursor:"pointer" }}>
                    {[27,28,29,30,31,32].map(p=><option key={p} value={p}>{p}%</option>)}
                  </select>
                </div>
                <div style={{ display:"flex", flexWrap:"wrap", gap:"5px" }}>
                  {t.badges.map(bid=>{ const b=BADGE_MAP[bid]; return b?(
                    <span key={bid} style={{ background:`${C.blue}18`, border:`1px solid ${C.blue}44`, borderRadius:"3px", padding:"3px 8px", fontSize:"12px", display:"inline-flex", alignItems:"center", gap:"4px" }}>
                      <span>{b.icon}</span><span style={{ color:C.black, fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>{b.name}</span>
                      <button onClick={()=>revokeBadge(t.id,bid)} style={{ background:"none", border:"none", color:"#ff4444", cursor:"pointer", fontSize:"13px", lineHeight:1, padding:"0 0 0 2px" }}>×</button>
                    </span>
                  ):null; })}
                </div>
                <div style={{ marginTop:"12px", paddingTop:"12px", borderTop:`1px solid ${C.border}` }}>
                  <button onClick={()=>archiveTech(t)} disabled={saving} style={{ background:"none", border:"1px solid #f59e0b", color:"#f59e0b", padding:"7px 16px", borderRadius:"8px", cursor:saving?"not-allowed":"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"12px", letterSpacing:"1px", textTransform:"uppercase" }}>
                    📦 Archive {t.name}
                  </button>
                </div>
              </div>
            ))}
            {/* Archived techs */}
            {techs.filter(t=>t.is_active===false).length>0&&(
              <div style={{ background:"#fff8e6", border:"1px solid #f59e0b44", borderTop:"3px solid #f59e0b", borderRadius:"12px", padding:"16px 18px" }}>
                <div style={{ fontSize:"11px", color:"#f59e0b", letterSpacing:"2px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", marginBottom:"12px" }}>📦 Archived Techs — Revenue still counted in totals</div>
                <div style={{ display:"flex", flexDirection:"column", gap:"8px" }}>
                  {techs.filter(t=>t.is_active===false).map(t=>(
                    <div key={t.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", background:"#fff", border:"1px solid #f59e0b33", borderRadius:"8px", padding:"10px 14px" }}>
                      <div>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"15px", color:C.muted }}>{t.name}</div>
                        <div style={{ fontSize:"10px", color:C.muted, letterSpacing:"1px" }}>ARCHIVED · NOT ON LEADERBOARD</div>
                      </div>
                      <button onClick={()=>reactivateTech(t)} disabled={saving} style={{ background:"none", border:"1px solid #00c853", color:"#00c853", padding:"6px 14px", borderRadius:"8px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"11px", letterSpacing:"1px" }}>
                        REACTIVATE
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}


        {tab==="teams"&&(
          <div style={{ display:"flex", flexDirection:"column", gap:"16px" }}>
            <div style={{ background:C.white, border:`1px solid ${C.border}`, borderTop:`3px solid ${C.gold}`, borderRadius:"12px", padding:"20px", boxShadow:"0 2px 8px rgba(43,156,240,0.08)" }}>
              <Label color={C.gold}>👥 Team Lead Assignments</Label>
              <div style={{ fontSize:"13px", color:C.muted, marginBottom:"16px" }}>Mark techs as team leads and assign members to their team. Teams can be changed anytime.</div>
              <div style={{ display:"flex", flexDirection:"column", gap:"12px" }}>
                {techs.map(t=>(
                  <div key={t.id} style={{ background:C.cardLt, border:`1px solid ${t.is_lead?C.gold:C.border}`, borderLeft:`3px solid ${t.is_lead?C.gold:C.border}`, borderRadius:"10px", padding:"12px 14px" }}>
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:"8px" }}>
                      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"16px", color:C.black }}>
                        {t.name}
                        {t.is_lead&&<span style={{ marginLeft:"8px", background:C.gold, color:C.white, fontSize:"9px", padding:"2px 8px", borderRadius:"8px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", verticalAlign:"middle" }}>TEAM LEAD</span>}
                      </div>
                      <button onClick={()=>toggleTeamLead(t)} disabled={saving}
                        style={{ background:t.is_lead?"#ef444422":"transparent", border:`1px solid ${t.is_lead?"#ef4444":C.gold}`, color:t.is_lead?"#ef4444":C.gold, padding:"5px 14px", borderRadius:"20px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"800", fontSize:"11px", letterSpacing:"1px" }}>
                        {t.is_lead?"Remove Lead":"Make Lead"}
                      </button>
                    </div>
                    {t.is_lead&&(
                      <div>
                        <div style={{ fontSize:"11px", color:C.muted, marginBottom:"6px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>TEAM NAME</div>
                        <div style={{ display:"flex", gap:"8px", marginBottom:"10px" }}>
                          <input
                            placeholder="e.g. Team Maverick"
                            defaultValue={t.team_name||""}
                            onBlur={async e=>{
                              const val = e.target.value.trim();
                              if (val === (t.team_name||"")) return;
                              await sb(`techs?id=eq.${t.id}`,{method:"PATCH",body:JSON.stringify({team_name:val||null}),prefer:"return=minimal"});
                              await refreshAll();
                              showToast(`✅ Team name saved!`);
                            }}
                            style={{ flex:1, background:C.white, border:`1px solid ${C.border}`, color:C.black, padding:"8px 12px", borderRadius:"8px", fontSize:"14px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}
                          />
                        </div>
                        <div style={{ fontSize:"11px", color:C.muted, marginBottom:"6px", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700" }}>TEAM MEMBERS</div>
                        <div style={{ display:"flex", flexWrap:"wrap", gap:"6px" }}>
                          {techs.filter(m=>m.id!==t.id).map(m=>{
                            const onTeam = m.team_lead_id===t.id;
                            const onOtherTeam = m.team_lead_id && m.team_lead_id!==t.id;
                            const otherLead = techs.find(x=>x.id===m.team_lead_id);
                            return (
                              <button key={m.id} onClick={()=>assignTeamMember(m,onTeam?null:t.id)} disabled={saving||m.is_lead}
                                style={{ background:onTeam?`${C.gold}20`:"transparent", border:`1px solid ${onTeam?C.gold:C.border}`, color:onTeam?C.gold:C.muted, padding:"4px 12px", borderRadius:"16px", cursor:m.is_lead?"not-allowed":"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"700", fontSize:"11px", opacity:m.is_lead?0.4:1 }}>
                                {onTeam?"✓ ":""}{m.name}{onOtherTeam?` (${otherLead?.name}'s team)`:""}
                              </button>
                            );
                          })}
                        </div>
                        <div style={{ fontSize:"10px", color:C.muted, marginTop:"6px" }}>Tap to add/remove. Can't add other leads.</div>
                      </div>
                    )}
                    {!t.is_lead&&t.team_lead_id&&(
                      <div style={{ fontSize:"11px", color:C.muted }}>
                        On {techs.find(x=>x.id===t.team_lead_id)?.name}'s team
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab==="delete"&&(
          <DeleteTab techs={techs} upsells={upsells} switchovers={switchovers} reviews={reviews} saving={saving} setSaving={setSaving} refreshAll={refreshAll} showToast={showToast}/>
        )}
        {tab==="journey"&&(
          <div>
            <div style={{ fontSize:"13px", color:C.muted, marginBottom:"16px" }}>Tap any card to expand full breakdown.</div>
            <JourneyBoard techs={activeTechs} upsells={upsells} switchovers={switchovers} reviews={reviews} quota={quota} callbacks={callbacks||[]} jobs={jobs}/>
          </div>
        )}
        {tab==="operations"&&(
          <OperationsProgressTab techs={techs} upsells={upsells} switchovers={switchovers} reviews={reviews} quota={quota} callbacks={callbacks||[]} jobs={jobs||[]} timeEntries={timeEntries} rideAlongs={rideAlongs||[]}/>
        )}
        {tab==="quota"&&(
          <QuotaSettings quota={quota} onSave={saveQuota} saving={saving}/>
        )}
        {tab==="incentive"&&(
          <div>
            <div style={{ fontSize:"13px", color:C.muted, marginBottom:"16px" }}>Team rewards overview — all tiers and prizes.</div>
            <IncentiveBoard techs={techs} upsells={upsells} switchovers={switchovers} reviews={reviews} callbacks={callbacks||[]} currentId={null} jobs={jobs}/>
          </div>
        )}

        {tab==="reports"&&(
          <ReportsTab techs={techs} jobs={jobs||[]} upsells={upsells||[]} timeEntries={timeEntries} tipEntries={tipEntries} techId={null} refreshAll={refreshAll} showToast={showToast}/>
        )}
        {tab==="leaderboard"&&(
          <Leaderboard techs={activeTechs} jobs={jobs||[]} upsells={upsells} reviews={reviews} callbacks={callbacks||[]} switchovers={switchovers} timeEntries={timeEntries}/>
        )}
        {tab==="payroll"&&(
          <PayrollTab techs={techs} jobs={jobs||[]} upsells={upsells} tipEntries={tipEntries}/>
        )}

        {tab==="ridealong"&&(
          <RideAlongTab
            techs={techs}
            rideAlongs={rideAlongs||[]}
            schedules={schedules||[]}
            saving={saving}
            onSave={async(data)=>{
              setSaving(true);
              try { await sb("ride_alongs",{method:"POST",body:JSON.stringify(data)}); await refreshAll(); showToast("✅ Ride-along saved!"); }
              catch(e){ showToast("Error: "+e.message,false); }
              setSaving(false);
            }}
            onSaveSchedule={async(date,techId)=>{
              try {
                const existing = await sb(`ride_along_schedule?date=eq.${date}&select=id`);
                if(existing&&existing.length>0) await sb(`ride_along_schedule?id=eq.${existing[0].id}`,{method:"PATCH",body:JSON.stringify({tech_id:techId||null}),prefer:"return=minimal"});
                else if(techId) await sb("ride_along_schedule",{method:"POST",body:JSON.stringify({date,tech_id:techId})});
                await refreshAll();
              } catch(e){ showToast("Error saving schedule: "+e.message,false); }
            }}
          />
        )}

      </div>
      {toast&&(
        <div style={{ position:"fixed", bottom:"24px", left:"50%", transform:"translateX(-50%)", background:toast.ok?C.green:"#ef4444", color:C.white, padding:"12px 28px", borderRadius:"24px", fontSize:"14px", fontWeight:"900", zIndex:999, whiteSpace:"nowrap", fontFamily:"'Barlow Condensed',sans-serif", letterSpacing:"1px", fontStyle:"italic", boxShadow:"0 4px 20px rgba(0,0,0,0.15)" }}>
          {toast.msg}
        </div>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [techs, setTechs] = useState([]);
  const [upsells, setUpsells] = useState([]);
  const [switchovers, setSwitchovers] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [callbacks, setCallbacks] = useState([]);
  const [rideAlongs, setRideAlongs] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [timeEntries, setTimeEntries] = useState([]);
  const [tipEntries, setTipEntries] = useState([]);
  const [pendingSplits, setPendingSplits] = useState([]);
  const [unmatchedTechs, setUnmatchedTechs] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dbError, setDbError] = useState(null);

  const [quota, setQuota] = useState(DEFAULT_QUOTA);

  const loadAll = useCallback(async () => {
    try {
      const [t,u,s,r,ra,sch,settings,cb,jb,te,tp,ps,ut] = await Promise.all([
        sb("techs?select=*&order=name"),
        sb("upsells?select=*"),
        sb("switchovers?select=*"),
        sb("reviews?select=*"),
        sb("ride_alongs?select=*&order=date.desc").catch(()=>[]),
        sb("ride_along_schedule?select=*").catch(()=>[]),
        sb("settings?key=eq.quota&select=*").catch(()=>[]),
        sb("callbacks?select=*&order=created_at.desc").catch(()=>[]),
        sbAll("jobs?select=*&order=job_date.desc,id.asc").catch(()=>[]),
        sbAll("time_entries?select=*&order=work_date.desc,id.asc").catch(()=>[]),
        sbAll("tip_entries?select=*&order=work_date.desc,id.asc").catch(()=>[]),
        sb("jobs?split_confirmed=eq.false&select=hcp_job_id,tech_id,job_date,revenue,tips,upsell_amount,customer_name&order=job_date.desc").catch(()=>[]),
        sb("unmatched_hcp_employees?select=*&order=hcp_name").catch(()=>[]),
      ]);
      setTechs(t||[]); setUpsells(u||[]); setSwitchovers(s||[]); setReviews(r||[]);
      setRideAlongs(ra||[]); setSchedules(sch||[]); setCallbacks(cb||[]); setJobs(jb||[]); setTimeEntries(te||[]); setTipEntries(tp||[]);
      setPendingSplits(ps||[]); setUnmatchedTechs(ut||[]);
      if (settings&&settings.length>0) {
        try { setQuota(JSON.parse(settings[0].value)); } catch {}
      }
      return true;
    } catch(e) { setDbError(e.message); return false; }
  }, []);

  useEffect(() => {
    (async()=>{ const ok=await loadAll(); setLoading(false); if(!ok)return; })();
    const interval = setInterval(() => { loadAll(); }, 60_000);
    return () => clearInterval(interval);
  }, [loadAll]);

  function handlePin(pin) {
    if (pin===ADMIN_PIN) { setUser({type:"admin"}); return true; }
    const tech=techs?.find(t=>t.pin===pin);
    if (tech) { setUser({type:"tech",techId:tech.id}); return true; }
    return false;
  }
  // Feeds TechDashboard's entire `techs` prop -- excluding owner/admin
  // accounts (title:"owner") here means every gamification view a tech sees
  // (Leaderboard, Total Score, Switchovers, Upsells, Reviews, Journey Map,
  // Rewards, Team Rank denominator) never counts them, without needing a
  // separate filter in each of those components.
  const activeTechs = (techs || []).filter(t => t.is_active !== false && t.title !== "owner");
  const currentTech = user?.type==="tech" ? techs?.find(t=>t.id===user.techId) : null;

  if (loading) return (
    <div style={{ minHeight:"100vh", background:"#f0f8ff", display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:"16px" }}>
      <style>{GS}</style>
      <Logo h={70}/>
      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontStyle:"italic", color:C.blue, letterSpacing:"4px", fontSize:"14px", fontWeight:"800" }}>LOADING...</div>
    </div>
  );

  if (dbError) return (
    <div style={{ minHeight:"100vh", background:"#f0f8ff", display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:"16px", padding:"24px", textAlign:"center" }}>
      <style>{GS}</style>
      <Logo h={70}/>
      <div style={{ color:"#ef4444", fontSize:"13px", maxWidth:"560px" }}>
        <strong>Database setup needed.</strong> Run this SQL in Supabase → SQL Editor:<br/><br/>
        <code style={{ background:C.white, border:`1px solid ${C.border}`, padding:"12px", borderRadius:"10px", fontSize:"11px", display:"block", textAlign:"left", whiteSpace:"pre", color:C.black }}>
{`alter table techs add column if not exists start_date date;
alter table techs add column if not exists is_lead boolean default false;
alter table techs add column if not exists team_lead_id uuid references techs(id);
alter table techs add column if not exists hourly_rate numeric default 0;
alter table techs add column if not exists commission_rate integer default 27;

create table if not exists reviews (
  id uuid primary key default gen_random_uuid(),
  tech_id uuid references techs(id),
  month_key text, count integer default 0,
  created_at timestamptz default now()
);
alter table reviews enable row level security;
drop policy if exists "public access" on reviews;
create policy "public access" on reviews for all using (true) with check (true);

create table if not exists settings (
  id uuid primary key default gen_random_uuid(),
  key text unique not null,
  value text not null,
  created_at timestamptz default now()
);
alter table settings enable row level security;
drop policy if exists "public access" on settings;
create policy "public access" on settings for all using (true) with check (true);

create table if not exists callbacks (
  id uuid primary key default gen_random_uuid(),
  tech_id uuid references techs(id),
  reason text default '',
  created_at timestamptz default now()
);
alter table callbacks enable row level security;
drop policy if exists "public access" on callbacks;
create policy "public access" on callbacks for all using (true) with check (true);

create table if not exists jobs (
  id uuid primary key default gen_random_uuid(),
  hcp_job_id text not null,
  tech_id uuid references techs(id),
  job_date date not null,
  revenue numeric default 0,
  upsell_amount numeric default 0,
  hours numeric default 0,
  week_key text,
  created_at timestamptz default now()
);
alter table jobs enable row level security;
drop policy if exists "public access" on jobs;
create policy "public access" on jobs for all using (true) with check (true);
create unique index if not exists jobs_hcp_job_id_key on jobs(hcp_job_id);
alter table jobs add column if not exists tips numeric default 0;`}
        </code><br/>
        <button onClick={()=>{setDbError(null);setLoading(true);loadAll().then(()=>setLoading(false));}} style={{ background:C.blue, border:"none", color:C.black, padding:"12px 28px", borderRadius:"24px", cursor:"pointer", fontFamily:"'Barlow Condensed',sans-serif", fontSize:"14px", fontWeight:"900", fontStyle:"italic", letterSpacing:"2px" }}>RETRY</button>
      </div>
    </div>
  );

  if (!user) return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(160deg, #e8f4ff 0%, #f0f8ff 50%, #e0f0ff 100%)", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", gap:"48px" }}>
      <style>{GS}</style>
      <div style={{ textAlign:"center" }}>
        <Logo h={90}/>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"48px", color:C.black, letterSpacing:"2px", marginTop:"20px", lineHeight:1 }}>THE STANDARD</div>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"900", fontStyle:"italic", fontSize:"48px", color:C.blue, letterSpacing:"2px", lineHeight:1 }}>BOARD</div>
        <div style={{ fontSize:"13px", color:C.muted, letterSpacing:"3px", marginTop:"12px", textTransform:"uppercase", fontFamily:"'Barlow Condensed',sans-serif", fontWeight:"600" }}>Enter your PIN</div>
      </div>
      <PinPad onSubmit={handlePin}/>
    </div>
  );

  if (user.type==="admin") return (
    <AdminPanel techs={techs} setTechs={setTechs} upsells={upsells} setUpsells={setUpsells}
      switchovers={switchovers} setSwitchovers={setSwitchovers} reviews={reviews} setReviews={setReviews}
      callbacks={callbacks} rideAlongs={rideAlongs} schedules={schedules} quota={quota} setQuota={setQuota}
      jobs={jobs} timeEntries={timeEntries} tipEntries={tipEntries} pendingSplits={pendingSplits} unmatchedTechs={unmatchedTechs} onLogout={()=>setUser(null)} refreshAll={loadAll}/>
  );
  if (user.type==="tech"&&currentTech) return (
    <TechDashboard tech={currentTech} techs={activeTechs} upsells={upsells} switchovers={switchovers}
      reviews={reviews} callbacks={callbacks} quota={quota} jobs={jobs} timeEntries={timeEntries} tipEntries={tipEntries} refreshAll={loadAll} rideAlongs={rideAlongs} onLogout={()=>setUser(null)}/>
  );
  return null;
}
