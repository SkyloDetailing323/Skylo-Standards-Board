// netlify/functions/hcp-upsell-sync.js
// Scheduled every 5 min. Fetches today's completed HCP jobs and syncs revenue, upsells.
// Split jobs: revenue/upsells divided by confirmed split % (job_splits table),
// falling back to equal split with split_confirmed=false.

const { matchTechName } = require('./lib/matchTech');
const { fetchJobSplits, resolveSplits, fetchUpsellAttributions, distributeAmount, cleanupReassignedTechs } = require('./lib/splitHelper');

function getMT() {
  const mt = new Date(Date.now() - 6 * 60 * 60 * 1000);
  const y = mt.getUTCFullYear();
  const m = String(mt.getUTCMonth() + 1).padStart(2, "0");
  const d = String(mt.getUTCDate()).padStart(2, "0");
  return { y, m, d, str: `${y}-${m}-${d}` };
}

function getWeekKey(dateStr) {
  const d = new Date((dateStr || getMT().str) + "T12:00:00Z");
  const day = d.getUTCDay();
  const daysBack = day === 0 ? 6 : day - 1;
  const monday = new Date(d);
  monday.setUTCDate(d.getUTCDate() - daysBack);
  return monday.toISOString().split("T")[0];
}

async function sbFetch(path, options = {}) {
  const res = await fetch(`${process.env.SUPABASE_URL}/rest/v1/${path}`, {
    method: options.method || "GET",
    body: options.body,
    headers: {
      "Content-Type": "application/json",
      "apikey": process.env.SUPABASE_KEY,
      "Authorization": `Bearer ${process.env.SUPABASE_KEY}`,
      "Prefer": options.prefer || "return=representation",
    },
  });
  if (res.status === 204) return null;
  const text = await res.text();
  if (!text) return null;
  const data = JSON.parse(text);
  // PostgREST returns an error object (not an array) on failure — surface it as a
  // thrown error instead of letting callers treat it as data (`rows || []` won't
  // catch a truthy object, which used to crash downstream iteration).
  const isPostgrestError = !res.ok || (data && typeof data === "object" && !Array.isArray(data) && (data.code || data.message));
  if (isPostgrestError) {
    throw new Error(`Supabase error on ${path} (HTTP ${res.status}): ${(data && (data.message || data.code)) || text}`);
  }
  return data;
}

async function hcpGet(path) {
  const res = await fetch(`https://api.housecallpro.com/${path}`, {
    headers: { "Authorization": `Token ${process.env.HCP_API_KEY}`, "Content-Type": "application/json" },
  });
  if (!res.ok) { console.error("HCP error", res.status, path); return null; }
  const text = await res.text();
  if (!text) return null;
  return JSON.parse(text);
}

function parseInvoice(inv) {
  const lineItemsCents = (inv.items || []).reduce((s, item) => s + (item.amount || 0), 0);
  const discountCents  = (inv.discounts || []).reduce((s, d) => s + Math.abs(d.amount || 0), 0);
  const serviceCents   = Math.max(0, lineItemsCents - discountCents);
  const revenue        = serviceCents / 100;

  // Tips are no longer computed here — manual entry (tip_entries table) is
  // the only source now. Revenue/upsell math above is unchanged.

  let upsellCents = 0;
  const upsellItems = [];
  for (const item of (inv.items || [])) {
    const name = (item.name || "").trim();
    if (name.toLowerCase().startsWith("additional upgrade")) {
      upsellCents += (item.amount || 0);
      upsellItems.push({ name, amount: (item.amount || 0) / 100 });
    }
  }

  return { revenue, upsellTotal: upsellCents / 100, upsellItems };
}

exports.handler = async () => {
  const { str: todayStr } = getMT();
  console.log(`Syncing ${todayStr}`);

  // HCP's /jobs endpoint has no completed_at_min/max filter — confirmed live
  // (passing one is silently ignored and returns every completed job ever).
  // The only server-side date filter it supports is scheduled_start. Since
  // actual completion can lag the scheduled date by several days
  // (rescheduling, delayed close-out), we fetch a padded window by
  // scheduled_start and then bucket + filter by each job's real completion
  // date ourselves — same fix already proven in hcp-revenue-sync.js.
  const PAD_DAYS = 5;
  function addDays(dateStr, days) {
    const d = new Date(dateStr + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() + days);
    return d.toISOString().split("T")[0];
  }
  const fetchFrom = addDays(todayStr, -PAD_DAYS);
  const fetchTo   = addDays(todayStr, PAD_DAYS);
  const start = `${fetchFrom}T00:00:00-06:00`;
  const end   = `${fetchTo}T23:59:59-06:00`;

  // Mountain Time calendar date for a UTC timestamp — same fixed -6h
  // convention as getMT() above.
  function toMTDateStr(isoTimestamp) {
    return new Date(new Date(isoTimestamp).getTime() - 6 * 60 * 60 * 1000).toISOString().split("T")[0];
  }

  // Fetch all completed jobs in the padded scheduled-date window
  const allJobs = [];
  let page = 1;
  while (true) {
    const qs = `work_status[]=completed&scheduled_start_min=${encodeURIComponent(start)}&scheduled_start_max=${encodeURIComponent(end)}&page=${page}&page_size=100`;
    const data = await hcpGet(`jobs?${qs}`);
    if (!data) break;
    const batch = data.jobs || [];
    allJobs.push(...batch);
    if (batch.length < 100 || allJobs.length >= (data.total_items || 0)) break;
    page++;
  }
  console.log(`${allJobs.length} completed jobs`);

  // Fetch techs — deterministic order, and prefer the active record if a
  // duplicate name ever slips back in (instead of silently keeping whichever
  // row Postgres happens to return last). Fetched before job matching below
  // since matching is now a live lookup against this map, not a static file.
  const allTechs = await sbFetch("techs?select=id,name,is_active&order=id");
  const techByName = {};
  for (const t of allTechs || []) {
    // .trim() guards against a stray leading/trailing space in a tech's
    // stored name silently breaking the exact-name match (found: "Trey
    // Sanchez " had a trailing space in Supabase).
    const key = (t.name || "").trim();
    const existing = techByName[key];
    if (!existing || (t.is_active && !existing.is_active)) techByName[key] = t;
  }

  // Build job meta — store ALL matched employees. Bucket by actual completion
  // date (not scheduled date), then keep only jobs that actually completed
  // today — everything else was only fetched because of the padding.
  const jobMeta = {};
  for (const job of allJobs) {
    const matchedEmployees = (job.assigned_employees || []).map(e => {
      const hcpName   = `${e.first_name || ""} ${e.last_name || ""}`.trim();
      const skyloName = matchTechName(hcpName, techByName);
      return skyloName ? { skyloName } : null;
    }).filter(Boolean);
    if (matchedEmployees.length === 0) continue;
    const completedAt = job.work_timestamps?.completed_at;
    const schedStart   = job.schedule?.scheduled_start;
    const jobDate = completedAt ? toMTDateStr(completedAt) : (schedStart ? schedStart.split("T")[0] : todayStr);
    if (jobDate !== todayStr) continue;
    jobMeta[String(job.id)] = {
      employees:    matchedEmployees,
      jobDate,
      totalAmount:  job.total_amount || 0,
      customerName: [job.customer?.first_name, job.customer?.last_name].filter(Boolean).join(" ") || null,
    };
  }

  // Fetch today's invoices in bulk
  const jobIds = new Set(Object.keys(jobMeta));
  const invoiceData = {};
  for (let p = 1; p <= 3; p++) {
    const data = await hcpGet(`invoices?created_at_min=${encodeURIComponent(todayStr + "T00:00:00Z")}&page=${p}&page_size=100`);
    if (!data) break;
    const invoices = data.invoices || [];
    for (const inv of invoices) {
      const jid = String(inv.job_id || "");
      if (!jobIds.has(jid) || invoiceData[jid]) continue;
      invoiceData[jid] = parseInvoice(inv);
    }
    if (invoices.length < 100 || Object.keys(invoiceData).length >= jobIds.size) break;
  }
  console.log(`Fetched invoices for ${Object.keys(invoiceData).length}/${Object.keys(jobMeta).length} jobs (bulk)`);

  // Per-job fallback
  const unmatched = [...jobIds].filter(jid => !invoiceData[jid]);
  if (unmatched.length > 0) {
    const BATCH = 5;
    for (let i = 0; i < unmatched.length; i += BATCH) {
      await Promise.all(unmatched.slice(i, i + BATCH).map(async (jobId) => {
        const invData = await hcpGet(`jobs/${jobId}/invoices`);
        const invoices = invData?.invoices || [];
        if (invoices.length > 0) invoiceData[jobId] = parseInvoice(invoices[0]);
      }));
    }
    console.log(`After fallback: ${Object.keys(invoiceData).length}/${Object.keys(jobMeta).length} matched`);
  }

  // Fetch confirmed splits and upsell attribution for multi-employee jobs
  const multiIds = Object.entries(jobMeta).filter(([, m]) => m.employees.length > 1).map(([id]) => id);
  const splitMap        = await fetchJobSplits(multiIds, sbFetch);
  const upsellAttribMap = await fetchUpsellAttributions(multiIds, sbFetch);

  let synced = 0;
  for (const [jobId, meta] of Object.entries(jobMeta)) {
    const jobDate  = meta.jobDate;
    const weekKey  = getWeekKey(jobDate);
    const inv      = invoiceData[jobId];

    const totalRev    = inv ? inv.revenue : 0;
    const totalUps    = inv ? inv.upsellTotal : 0;

    const splits = resolveSplits(jobId, meta.employees, splitMap, techByName);

    // Remove any leftover row for a tech who's no longer on this job (e.g. a
    // callback reassigned to someone else) before writing the current splits.
    const currentTechIds = splits.map(s => techByName[s.skyloName]).filter(Boolean).map(t => t.id);
    await cleanupReassignedTechs(jobId, currentTechIds, sbFetch);

    // Upsell credit uses its own effective percentages -- if manually
    // attributed, 100% goes to one tech and 0% to the rest, which can differ
    // from the revenue split's percentages -- so it needs its own
    // distributeAmount() pass rather than reusing the revenue split's shares.
    const attribId = upsellAttribMap[jobId];
    const upsellSplits = splits.map(s => {
      const tech = techByName[s.skyloName];
      const upsellPct = attribId ? (tech && attribId === tech.id ? 1.0 : 0) : s.pct;
      return { ...s, pct: upsellPct };
    });

    const revenueAmounts = distributeAmount(totalRev, splits);
    const upsellAmounts  = distributeAmount(totalUps, upsellSplits);

    for (let i = 0; i < splits.length; i++) {
      const split = splits[i];
      const tech = techByName[split.skyloName];
      if (!tech) { console.log("Tech not in Supabase:", split.skyloName); continue; }

      const revenue   = revenueAmounts[i];
      const upsellPct = upsellSplits[i].pct;
      const upsells   = upsellAmounts[i];

      await sbFetch("jobs?on_conflict=hcp_job_id,tech_id", {
        method: "POST",
        prefer: "resolution=merge-duplicates,return=minimal",
        body: JSON.stringify({
          hcp_job_id:      jobId,
          tech_id:         tech.id,
          job_date:        jobDate,
          revenue,
          upsell_amount:   upsells,
          hours:           0,
          week_key:        weekKey,
          split_confirmed: split.confirmed,
          customer_name:   meta.customerName || null,
        }),
      });

      try {
        if (upsells > 0 && inv) {
          const note = inv.upsellItems.map(i => `${i.name} ($${(i.amount * upsellPct).toFixed(2)})`).join(", ");
          await sbFetch("upsells?on_conflict=hcp_job_id,tech_id", {
            method: "POST",
            prefer: "resolution=merge-duplicates,return=minimal",
            body: JSON.stringify({ tech_id: tech.id, week_key: weekKey, amount: upsells, hcp_job_id: jobId, note }),
          });
          console.log(`UPSELL: ${split.skyloName} | ${note}`);
        }
      } catch (err) {
        console.log(`Failed to write upsell for job ${jobId} tech ${tech.id}:`, err.message);
      }

      const pctTag = splits.length > 1 ? ` (${Math.round(split.pct * 100)}%${split.confirmed ? "" : " unconfirmed"})` : "";
      console.log(`Synced: ${split.skyloName}${pctTag} | rev=$${revenue} ups=$${upsells} hrs=0`);
      synced++;
    }
  }

  console.log(`Done. ${synced} synced.`);
  return { statusCode: 200, body: JSON.stringify({ ok: true, synced }) };
};
