// netlify/functions/hcp-revenue-sync.js
// Scheduled every 5 min. Syncs revenue for today's completed HCP jobs
// (no upsell handling). Split jobs: revenue divided by confirmed split %,
// or equal split if unconfirmed.
//
// Scheduled-only — Netlify blocks direct HTTP invocation of any function that
// has a `schedule` configured, so this never accepts a custom date range. For
// on-demand repairs over an arbitrary range, see hcp-revenue-repair.js (same
// split as hcp-upsell-sync.js vs hcp-upsell-repair.js).

const { matchTechName } = require('./lib/matchTech');
const { fetchJobSplits, resolveSplits, distributeAmount, cleanupReassignedTechs } = require('./lib/splitHelper');

function getMT() {
  const mt = new Date(Date.now() - 6 * 60 * 60 * 1000);
  const y = mt.getUTCFullYear();
  const m = String(mt.getUTCMonth() + 1).padStart(2, "0");
  const d = String(mt.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

const FETCH_TIMEOUT_MS = 10000;

async function fetchWithTimeout(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

function getWeekKey(dateStr) {
  const d = new Date(dateStr + "T12:00:00Z");
  const day = d.getUTCDay();
  const back = day === 0 ? 6 : day - 1;
  d.setUTCDate(d.getUTCDate() - back);
  return d.toISOString().split("T")[0];
}

async function sbFetch(path, options = {}) {
  const res = await fetchWithTimeout(`${process.env.SUPABASE_URL}/rest/v1/${path}`, {
    method: options.method || "GET",
    body: options.body,
    headers: {
      "Content-Type": "application/json",
      "apikey": process.env.SUPABASE_KEY,
      "Authorization": `Bearer ${process.env.SUPABASE_KEY}`,
      "Prefer": options.prefer || "return=representation",
    },
  });
  if (res.status === 204) return null;
  const text = await res.text();
  if (!text) return null;
  const data = JSON.parse(text);
  // PostgREST returns an error object (not an array) on failure — surface it as a
  // thrown error instead of letting callers treat it as data (`rows || []` won't
  // catch a truthy object, which used to crash downstream iteration).
  const isPostgrestError = !res.ok || (data && typeof data === "object" && !Array.isArray(data) && (data.code || data.message));
  if (isPostgrestError) {
    throw new Error(`Supabase error on ${path} (HTTP ${res.status}): ${(data && (data.message || data.code)) || text}`);
  }
  return data;
}

async function hcpGet(path) {
  let res;
  try {
    res = await fetchWithTimeout(`https://api.housecallpro.com/${path}`, {
      headers: { "Authorization": `Token ${process.env.HCP_API_KEY}`, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("HCP fetch failed", path, err.message);
    return null;
  }
  if (!res.ok) { console.error("HCP error", res.status, path); return null; }
  const text = await res.text();
  if (!text) return null;
  return JSON.parse(text);
}

exports.handler = async () => {
  const todayStr = getMT();

  // HCP's /jobs endpoint has no completed_at_min/max filter — confirmed live:
  // passing one is silently ignored and returns every completed job ever
  // (total_items in the thousands). The only server-side date filter it
  // supports is scheduled_start. Since actual completion can lag the
  // scheduled date by several days (rescheduling, delayed close-out), we
  // fetch a padded window by scheduled_start and then bucket + filter by each
  // job's real completion date ourselves — matching hcp-revenue-repair.js so
  // the two can't drift out of sync with each other.
  const PAD_DAYS = 5;
  function addDays(dateStr, days) {
    const d = new Date(dateStr + "T12:00:00Z");
    d.setUTCDate(d.getUTCDate() + days);
    return d.toISOString().split("T")[0];
  }
  const fetchFrom = addDays(todayStr, -PAD_DAYS);
  const fetchTo   = addDays(todayStr, PAD_DAYS);
  const start = `${fetchFrom}T00:00:00-06:00`;
  const end   = `${fetchTo}T23:59:59-06:00`;

  // Mountain Time calendar date for a UTC timestamp — same fixed -6h
  // convention as getMT() above, so a job completed just after midnight UTC
  // still lands on the correct MT day.
  function toMTDateStr(isoTimestamp) {
    return new Date(new Date(isoTimestamp).getTime() - 6 * 60 * 60 * 1000).toISOString().split("T")[0];
  }

  // Deterministic order, and prefer the active record if a duplicate name
  // ever slips back in (instead of silently keeping whichever row Postgres
  // happens to return last).
  const allTechs = await sbFetch("techs?select=id,name,is_active&order=id");
  if (!allTechs) return { statusCode: 500, body: JSON.stringify({ ok: false, error: "Could not load techs" }) };
  const techByName = {};
  for (const t of allTechs) {
    // .trim() guards against a stray leading/trailing space in a tech's
    // stored name silently breaking the exact-name match (found: "Trey
    // Sanchez " had a trailing space in Supabase).
    const key = (t.name || "").trim();
    const existing = techByName[key];
    if (!existing || (t.is_active && !existing.is_active)) techByName[key] = t;
  }

  // Fetch all completed jobs in the padded scheduled-date window
  const allJobs = [];
  let page = 1;
  while (true) {
    const qs = [
      `work_status[]=completed`,
      `scheduled_start_min=${encodeURIComponent(start)}`,
      `scheduled_start_max=${encodeURIComponent(end)}`,
      `page=${page}`,
      `page_size=100`,
    ].join("&");
    const data = await hcpGet(`jobs?${qs}`);
    if (!data) break;
    const jobs = data.jobs || [];
    allJobs.push(...jobs);
    if (jobs.length < 100) break;
    page++;
  }

  // Build job meta — store ALL matched employees. Bucket by actual completion
  // date (not scheduled date), then keep only jobs that actually completed
  // today — everything else was only fetched because of the padding.
  const jobMeta = {};
  for (const job of allJobs) {
    const matchedEmployees = (job.assigned_employees || []).map(e => {
      const hcpName   = `${e.first_name || ""} ${e.last_name || ""}`.trim();
      const skyloName = matchTechName(hcpName, techByName);
      return skyloName ? { skyloName } : null;
    }).filter(Boolean);
    if (matchedEmployees.length === 0) continue;
    const completedAt = job.work_timestamps?.completed_at;
    const schedStart   = job.schedule?.scheduled_start;
    const jobDate = completedAt ? toMTDateStr(completedAt) : (schedStart ? schedStart.split("T")[0] : todayStr);
    if (jobDate !== todayStr) continue;
    jobMeta[String(job.id)] = {
      employees:    matchedEmployees,
      jobDate,
      totalAmount:  job.total_amount || 0,
      tipAmount:    job.tip_amount   || 0,
      customerName: [job.customer?.first_name, job.customer?.last_name].filter(Boolean).join(" ") || null,
    };
  }

  // Fetch confirmed splits for multi-employee jobs
  const multiIds = Object.entries(jobMeta).filter(([, m]) => m.employees.length > 1).map(([id]) => id);
  const splitMap = await fetchJobSplits(multiIds, sbFetch);

  // Per-job invoice fetch, then write one row per tech per job
  const batch = [];
  for (const [jobId, meta] of Object.entries(jobMeta)) {
    const invData  = await hcpGet(`jobs/${jobId}/invoices`);
    const invoices = invData?.invoices || [];

    // Tips are no longer computed/written here — manual entry (tip_entries
    // table) is the only source now. meta.tipAmount (job.tip_amount) is kept
    // only for the no-invoice revenue fallback below ("total collected minus
    // tip"); revenue math is otherwise unchanged from before.
    let totalRev;
    if (invoices.length > 0) {
      const inv            = invoices[0];
      const lineItemsCents = (inv.items || []).reduce((s, item) => s + (item.amount || 0), 0);
      const discountCents  = (inv.discounts || []).reduce((s, d) => s + Math.abs(d.amount || 0), 0);
      const serviceCents   = Math.max(0, lineItemsCents - discountCents);
      totalRev             = serviceCents / 100;
    } else {
      totalRev = Math.max(0, (meta.totalAmount - meta.tipAmount)) / 100;
    }

    const splits  = resolveSplits(jobId, meta.employees, splitMap, techByName);

    // Remove any leftover row for a tech who's no longer on this job (e.g. a
    // callback reassigned to someone else) before writing the current splits.
    const currentTechIds = splits.map(s => techByName[s.skyloName]).filter(Boolean).map(t => t.id);
    await cleanupReassignedTechs(jobId, currentTechIds, sbFetch);

    const amounts = distributeAmount(totalRev, splits);
    for (let i = 0; i < splits.length; i++) {
      const split = splits[i];
      const tech = techByName[split.skyloName];
      if (!tech) continue;
      batch.push({
        hcp_job_id:      jobId,
        tech_id:         tech.id,
        job_date:        meta.jobDate,
        week_key:        getWeekKey(meta.jobDate),
        hours:           0,
        revenue:         amounts[i],
        split_confirmed: split.confirmed,
        customer_name:   meta.customerName || null,
      });
    }
  }

  if (batch.length > 0) {
    await sbFetch("jobs?on_conflict=hcp_job_id,tech_id", {
      method: "POST",
      prefer: "resolution=merge-duplicates,return=minimal",
      body: JSON.stringify(batch),
    });
  }

  console.log(`Revenue sync: ${batch.length} rows written for ${todayStr}`);
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ok: true, jobsSynced: batch.length }),
  };
};
