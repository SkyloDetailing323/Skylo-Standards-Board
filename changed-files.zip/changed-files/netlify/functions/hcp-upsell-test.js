// netlify/functions/hcp-upsell-test.js
// Dry-run test: simulates a completed HCP job and traces every step without writing to Supabase

const UPSELL_SERVICES = [
  "Seat Steam and Shampoo",
  "Engine Bay Cleaning",
  "Carpet Steam and Shampoo",
  "Heavy Pet Hair Removal Service",
  "Full Interior Detail",
  "Full Exterior Detail",
];

// Matching is now a live lookup against the techs table (see lib/matchTech.js)
// instead of the old hand-maintained TECH_MAP whitelist.
const { matchTechName } = require('./lib/matchTech');

function getWeekKey() {
  const mt = new Date(Date.now() - 6 * 60 * 60 * 1000);
  const day = mt.getDay();
  const daysBack = day === 0 ? 6 : day - 1;
  const monday = new Date(mt);
  monday.setDate(mt.getDate() - daysBack);
  const y = monday.getFullYear();
  const m = String(monday.getMonth() + 1).padStart(2, "0");
  const d = String(monday.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

async function sbFetch(path, options = {}) {
  const { prefer, method, body } = options;
  const res = await fetch(`${process.env.SUPABASE_URL}/rest/v1/${path}`, {
    method: method || "GET",
    body,
    headers: {
      "Content-Type": "application/json",
      "apikey": process.env.SUPABASE_KEY,
      "Authorization": `Bearer ${process.env.SUPABASE_KEY}`,
      "Prefer": prefer || "return=representation",
    },
  });
  if (res.status === 204) return null;
  const data = await res.json();
  // PostgREST returns an error object (not an array) on failure — surface it as a
  // thrown error instead of letting callers treat it as data (`rows || []` won't
  // catch a truthy object, which used to crash downstream iteration).
  const isPostgrestError = !res.ok || (data && typeof data === "object" && !Array.isArray(data) && (data.code || data.message));
  if (isPostgrestError) {
    throw new Error(`Supabase error on ${path} (HTTP ${res.status}): ${(data && (data.message || data.code)) || res.status}`);
  }
  return data;
}

exports.handler = async () => {
  const steps = [];
  const log = (label, data, status = "ok") => {
    steps.push({ step: steps.length + 1, status, label, data });
  };

  // --- Simulated job payload ---
  const MOCK_JOB = {
    id: "TEST-JOB-001",
    assigned_employees: [{ first_name: "Kade", last_name: "Andrew" }],
    line_items: [
      { name: "Seat Steam and Shampoo", quantity: 1, unit_price: "50.00" },
    ],
  };

  log("Mock job payload", MOCK_JOB);

  // Step: extract employee
  const employee = (MOCK_JOB.assigned_employees || [])[0];
  if (!employee) {
    log("Extract employee", null, "fail");
    return respond(steps, false, "No employee on job");
  }
  const hcpName = `${employee.first_name} ${employee.last_name}`.trim();
  log("Extract employee", { hcpName });

  // Step: check env vars
  const envCheck = {
    SUPABASE_URL: process.env.SUPABASE_URL ? "set" : "MISSING",
    SUPABASE_KEY: process.env.SUPABASE_KEY ? "set" : "MISSING",
    HCP_API_KEY:  process.env.HCP_API_KEY  ? "set" : "MISSING",
  };
  const missingEnv = Object.entries(envCheck).filter(([, v]) => v === "MISSING").map(([k]) => k);
  log("Environment variables", envCheck, missingEnv.length ? "warn" : "ok");

  // Step: line item scan
  const lineItems = MOCK_JOB.line_items || [];
  log("Line items from job", lineItems);

  let upsellTotal = 0;
  const upsellItems = [];
  for (const item of lineItems) {
    const name = (item.name || item.description || "").trim();
    const matched = UPSELL_SERVICES.some(s => s.toLowerCase() === name.toLowerCase());
    if (matched) {
      const qty = item.quantity || 1;
      const price = parseFloat(item.unit_price || item.price || 0);
      const total = qty * price;
      upsellTotal += total;
      upsellItems.push({ name, qty, unit_price: price, total });
    }
    log(`Line item "${name}"`, { matched, qty: item.quantity, unit_price: item.unit_price });
  }

  if (upsellTotal === 0) {
    log("Upsell total", { upsellTotal }, "fail");
    return respond(steps, false, "No upsell items found — nothing to write");
  }
  log("Upsell total", { upsellItems, upsellTotal });

  // Step: Supabase tech lookup (real read — safe, no writes). This IS the
  // match now -- an exact `techs.name` hit is what matchTechName checks too.
  // Fetches every tech and matches client-side (same as the real sync
  // functions) rather than an `eq.` filter, so a stray whitespace difference
  // in a stored name behaves identically here as it would in production
  // (see the .trim() note below -- found "Trey Sanchez " with a trailing
  // space in Supabase, which an exact server-side `eq.` filter would miss).
  let tech = null;
  let skyloName = null;
  try {
    const techs = await sbFetch(`techs?select=id,name,is_active`);
    const techByName = {};
    for (const t of techs || []) techByName[(t.name || "").trim()] = t;
    skyloName = matchTechName(hcpName, techByName);
    if (!skyloName) {
      log("Supabase tech lookup", { query: `name=eq.${hcpName}`, result: "not found" }, "fail");
      return respond(steps, false, `No tech named "${hcpName}" found in Supabase techs table`);
    }
    tech = techByName[skyloName];
    log("Supabase tech lookup", { query: `name=eq.${hcpName}`, result: tech });
  } catch (err) {
    log("Supabase tech lookup", { error: err.message }, "fail");
    return respond(steps, false, `Supabase read failed: ${err.message}`);
  }

  // Step: check for existing upsell row (real read — safe, no writes)
  let existingRow = null;
  try {
    const existing = await sbFetch(`upsells?hcp_job_id=eq.${MOCK_JOB.id}&select=id,hcp_job_id,amount`);
    existingRow = existing && existing.length > 0 ? existing[0] : null;
    log("Supabase duplicate check", {
      query: `hcp_job_id=eq.${MOCK_JOB.id}`,
      existing: existingRow || "none — would INSERT",
    });
  } catch (err) {
    log("Supabase duplicate check", { error: err.message }, "warn");
  }

  // Step: dry-run upsert payload
  const weekKey = getWeekKey();
  const note = upsellItems.map(i => `${i.name} ($${i.total})`).join(", ");
  const upsertPayload = {
    tech_id:     tech.id,
    week_key:    weekKey,
    amount:      upsellTotal,
    hcp_job_id:  MOCK_JOB.id,
    note,
  };
  log("DRY RUN — upsert payload (not written)", {
    endpoint: "POST /upsells?on_conflict=hcp_job_id",
    prefer:   "resolution=merge-duplicates,return=minimal",
    body:     upsertPayload,
    action:   existingRow ? "would UPDATE existing row" : "would INSERT new row",
  });

  return respond(steps, true, "Dry run complete — all steps passed, nothing written to Supabase");
};

function respond(steps, ok, summary) {
  const failCount  = steps.filter(s => s.status === "fail").length;
  const warnCount  = steps.filter(s => s.status === "warn").length;
  return {
    statusCode: 200,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ok, summary, failCount, warnCount, steps }, null, 2),
  };
}
